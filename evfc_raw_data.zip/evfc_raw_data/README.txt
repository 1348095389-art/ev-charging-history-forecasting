Raw EV charging session data used in the study (copies of the public files as downloaded for the study)

boulder_ev_sessions.csv.gz
  City of Boulder Open Data, "Electric Vehicle Charging Station Data", ArcGIS Hub dataset 95992b3938be4622b07f0b05eba95d4c_0
  Licence: CC0 1.0. CSV export, gzip-compressed. 148,136 rows.
paloalto_ev_sessions.csv
  City of Palo Alto Open Data, dataset 194693 "Electric Vehicle Charging Station Usage (July 2011 - Dec 2020)"
  Licence: ODC PDDL (as marked on the portal). 259,415 rows.

Both licences permit redistribution. Place both files in evfc_code_package/data/raw/ ; step 01 then skips the download.

SHA-256
7106adfcc6a26d6513482f48a1676f6b5442c81436f30459da34b6a6b911f2c8  boulder_ev_sessions.csv.gz
e65f5f5d3861cdd6bf3da2de97aabe590d7708e001db1532202eec52081ba82c  paloalto_ev_sessions.csv
