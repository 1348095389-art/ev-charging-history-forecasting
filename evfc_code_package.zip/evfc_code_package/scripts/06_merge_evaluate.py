"""Step 06: merge Chronos-2 outputs, build the quantile-mean forecast, apply the empty-context fallback, and
write every evaluation table (tables/*.csv) plus tables/numbers.txt.  Also writes results/<city>_<kind>.pkl
(merged result frames used by the figures)."""
import os
import pickle
import sys
import time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
os.chdir(ROOT)

import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402

from evfc import evaluate as EV  # noqa: E402
from evfc import exp as E  # noqa: E402
from evfc import pipeline as PL  # noqa: E402

PS_MODELS = ["gbdt", "chronos_qmean", "chronos", "sn", "peer", "zero", "gbdt_nok", "gbdt_nonorm", "gbdt_nopeer"]
ABL = ["gbdt", "gbdt_nok", "gbdt_nonorm", "gbdt_nopeer"]
BOOT_MODELS = ["gbdt", "chronos_qmean", "chronos", "peer", "sn", "zero"]


def numbers_sheet(PT):
    KLAB, KORD = EV.KLAB, PL.KORD

    def g(c, m, k, v="RMSE"):
        x = PT[(PT.city == c) & (PT.model == m) & (PT.k == k)][v]; return float(x.iloc[0]) if len(x) else np.nan
    lines = []
    for c in ["Boulder", "Palo Alto"]:
        for m in ["gbdt", "chronos_qmean", "peer", "sn", "zero"]:
            lines.append(f"{c} {m} RMSE " + " ".join(f"{KLAB[k]}:{g(c, m, k):.3f}" for k in KORD if not np.isnan(g(c, m, k))))
        for m in ["gbdt", "chronos_qmean", "sn", "peer"]:
            lines.append(f"{c} {m} dWAPE " + " ".join(f"{KLAB[k]}:{g(c, m, k, 'dWAPE'):.3f}" for k in KORD
                                                     if not np.isnan(g(c, m, k, "dWAPE"))))
        gmin = min(g(c, "gbdt", k) for k in KORD); cmin = np.nanmin([g(c, "chronos_qmean", k) for k in KORD])
        lines.append(f"{c} GBDT min {gmin:.3f} days-to-par(2%) " + str([KLAB[k] for k in KORD if g(c, "gbdt", k) <= 1.02 * gmin][0]))
        lines.append(f"{c} Chronos min {cmin:.3f} days-to-par(2%) " + str([KLAB[k] for k in KORD if g(c, "chronos_qmean", k) <= 1.02 * cmin][0]))
        lines.append(f"{c} RMSE reduction gbdt vs sn at k7 {100 * (1 - g(c, 'gbdt', 7) / g(c, 'sn', 7)):.1f}%  vs peer k7 "
                     f"{100 * (1 - g(c, 'gbdt', 7) / g(c, 'peer', 7)):.1f}%  gbdt k0->k7 {100 * (1 - g(c, 'gbdt', 7) / g(c, 'gbdt', 0)):.1f}%  "
                     f"dWAPE k0->k7 {g(c, 'gbdt', 0, 'dWAPE'):.3f}->{g(c, 'gbdt', 7, 'dWAPE'):.3f}")
    # days-to-par sensitivity: smallest k (order 0,1,3,7,14,28,full) whose RMSE <= (1 + thr) * minimum over k
    for c in ["Boulder", "Palo Alto"]:
        for thr in (0.01, 0.02, 0.05, 0.10):
            par = {}
            for m in ["gbdt", "chronos_qmean"]:
                r = [g(c, m, k) for k in KORD]; mn = np.nanmin(r)
                par[m] = [KLAB[k] for k, v in zip(KORD, r) if not np.isnan(v) and v <= (1 + thr) * mn][0]
            lines.append(f"{c} days-to-par({thr * 100:.0f}%) GBDT {par['gbdt']} Chronos {par['chronos_qmean']}")
    return lines


def fallback_sensitivity(pairs):
    """Chronos-2 empty-context fallback: share of affected rows and RMSE with / without them (k != 0, observed y)."""
    rows = []
    for nm, D in pairs:
        g0 = D[(D.k != 0) & D.y.notna()]
        for k, g in g0.groupby("k"):
            nf = g[~g.ctx_fallback.astype(bool)]
            rows.append(dict(city=nm, k=k, n_rows=len(g), fb_share=float(g.ctx_fallback.mean()),
                             rmse_gbdt_all=E.rmse(g.y.values, g.gbdt.values),
                             rmse_chronos_qmean_all=E.rmse(g.y.values, g.chronos_qmean.values),
                             rmse_gbdt_nofb=E.rmse(nf.y.values, nf.gbdt.values),
                             rmse_chronos_qmean_nofb=E.rmse(nf.y.values, nf.chronos_qmean.values)))
    return pd.DataFrame(rows)


if __name__ == "__main__":
    t0 = time.time()
    os.makedirs("tables", exist_ok=True)
    ctx = PL.load_context()
    with open("chronos_in/meta.pkl", "rb") as f:
        meta = pickle.load(f)
    R = {}
    for name in ("boulder", "paloalto"):
        for kind in ("pseudo", "new"):
            D = pd.read_pickle(f"results/{name}_{kind}_models.pkl")
            D = PL.merge_ch(D, meta, ctx, name, kind)
            D = PL.add_qmean(D, meta, ctx, name, kind)
            D = PL.apply_fallback(D, PL.city_of(ctx, name))
            D["zero"] = 0.0
            D.to_pickle(f"results/{name}_{kind}.pkl")
            R[(name, kind)] = D
            print(name, kind, "rows", len(D), "fallback share", round(D.ctx_fallback.mean(), 4), flush=True)
    DB, DP, NB, NPA = R[("boulder", "pseudo")], R[("paloalto", "pseudo")], R[("boulder", "new")], R[("paloalto", "new")]
    pairs = [("Boulder", DB), ("Palo Alto", DP)]

    # ---- simulated limited history (pseudo-new): point, interval, per-station, tests, ablation, bootstrap
    PT, IT = [], []
    for nm, D in pairs:
        p = EV.point_table(D); p["city"] = nm; PT.append(p)
        it = EV.interval_table(D); it["city"] = nm; IT.append(it)
    PT = pd.concat(PT); IT = pd.concat(IT)
    PS = pd.concat([EV.per_station_rmse(D, PS_MODELS).assign(city=nm) for nm, D in pairs])
    T = EV.tests(PS)
    TA = EV.tests(PS, ref="gbdt", comps=("gbdt_nok", "gbdt_nonorm", "gbdt_nopeer"))
    AB = pd.DataFrame([dict(city=nm, k=k, **{m: E.rmse(g.y.values, g[m].values) for m in ABL}) for nm, D in pairs
                       for k, g in D.groupby("k")])
    BR = pd.concat([PL.boot_rmse(DB, BOOT_MODELS).assign(city="Boulder"), PL.boot_rmse(DP, BOOT_MODELS).assign(city="Palo Alto")])
    PT.to_csv("tables/point_metrics_pseudo.csv", index=False)
    IT.to_csv("tables/interval_metrics_pseudo.csv", index=False)
    PS.to_csv("tables/per_station_rmse_pseudo.csv", index=False)
    T.to_csv("tables/tests_pseudo.csv", index=False)
    TA.to_csv("tables/tests_ablation.csv", index=False)
    AB.to_csv("tables/ablation_pseudo.csv", index=False)
    BR.to_csv("tables/rmse_bootstrap_pseudo.csv", index=False)
    FB = fallback_sensitivity(pairs)
    FB.to_csv("tables/chronos_fallback_sensitivity.csv", index=False)
    print(FB.round(4).to_string(index=False))

    # ---- genuinely new stations
    NEW = pd.concat([NB.assign(city="Boulder"), NPA.assign(city="Palo Alto")], ignore_index=True); NEW["zero"] = 0.0
    NEW["dbin"] = NEW.days_in_service.map(PL.dbin)
    NPT, NIT = [], []
    for c, g0 in NEW.groupby("city"):
        p = EV.point_table(g0, group="dbin"); p["city"] = c; NPT.append(p)
        it = EV.interval_table(g0, group="dbin"); it["city"] = c; NIT.append(it)
    NPT = pd.concat(NPT); NIT = pd.concat(NIT)
    NPT.to_csv("tables/point_metrics_new.csv", index=False); NIT.to_csv("tables/interval_metrics_new.csv", index=False)
    rb = NEW.dropna(subset=["y"]).groupby(["city", "dbin"]).apply(
        lambda g: pd.Series({"obs_mean": g.y.mean(), "peer_mean": g.peer.mean(), "gbdt_mean": g.gbdt.mean(),
                             "chronos_qmean_mean": g.chronos_qmean.mean(), "ratio_obs_to_peer": g.y.mean() / g.peer.mean(),
                             "bias_gbdt": (g.gbdt - g.y).mean()}), include_groups=False)
    rb.to_csv("tables/rampup_new.csv")
    print("new stations", NEW.groupby("city").station.nunique().to_dict(),
          "batches", NEW.groupby("city").batch_onset.nunique().to_dict())

    # ---- data summary and key numbers
    S1 = PL.data_summary(ctx)
    S1.to_csv("tables/data_summary.csv", index=False)
    lines = numbers_sheet(PT)
    open("tables/numbers.txt", "w").write("\n".join(lines))
    print("\n".join(lines))
    print(f"06_merge_evaluate done in {time.time() - t0:.1f} s")
