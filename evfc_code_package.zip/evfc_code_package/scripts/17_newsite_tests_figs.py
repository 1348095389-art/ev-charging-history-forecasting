"""Step 17 (round 3): paired station-level tests on genuinely new stations by days in service, and Figures 4 and 5
with TimesFM 3.0 + peer covariates. Usage: python scripts/17_newsite_tests_figs.py [results_dir] [tables_dir] [manuscript_dir]"""
import os, sys
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__))); sys.path.insert(0, ROOT); os.chdir(ROOT)
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Patch
import numpy as np, pandas as pd
from scipy.stats import wilcoxon
from evfc import _compat, pipeline as PL, evaluate_r2 as E2, report_r2 as RR, exp as E
from evfc.figstyle import apply_figure_style, panel_letter
RES = sys.argv[1] if len(sys.argv) > 1 else "results"; TAB = sys.argv[2] if len(sys.argv) > 2 else "tables"
MS = sys.argv[3] if len(sys.argv) > 3 else "manuscript"; TD = os.path.join(MS, "tables") + os.sep; FD = os.path.join(MS, "figs")
os.makedirs(TD, exist_ok=True); os.makedirs(FD, exist_ok=True)
CITIES = RR.CITIES; KO = RR.KO; KL = RR.KL
BANDS = ["1-2", "3-6", "7-13", "14-27", "28-55"]; ORDER = ["0"] + BANDS
COMPS = ["chronos_qmean", "tfm3_qmean", "tfm3c_qmean", "peer", "zero"]
NAMES = {"chronos_qmean": "Chronos-2", "tfm3_qmean": "TimesFM 3.0", "tfm3c_qmean": "TimesFM 3.0 + peer cov.", "peer": "Peer profile", "zero": "Zero forecast"}
COLR = {"gbdt": "#1f4e9c", "sn": "#8c6bb1", "peer": "#5a9e6f", "chronos": "#d9822b", "chronos_qmean": "#d9822b", "tfm3": "#e41a1c",
        "tfm3c": "#99000d", "tfm3c_qmean": "#99000d"}
ILAB = {"gbdt": "Pooled GBDT + conformal", "sn": "Seasonal naive + conformal", "peer": "Peer profile + conformal",
        "chronos": "Chronos-2 native quantiles", "tfm3": "TimesFM 3.0 native quantiles", "tfm3c": "TimesFM 3.0 + peer cov. native quantiles"}
def dbin(dd):
    for a, b in [(0, 0), (1, 2), (3, 6), (7, 13), (14, 27), (28, 55)]:
        if a <= dd <= b:
            return f"{a}-{b}" if a != b else "0"
_compat.ensure_thread_pool(); ctx = PL.load_context()
CAP = {"Boulder": E2.train_cap(ctx["cityB"], ctx["cfgB"]["train_end"]), "Palo Alto": E2.train_cap(ctx["cityP"], ctx["cfgP"]["train_end"])}
NEW, PSE = {}, {}
for cn, nm in [("Boulder", "boulder"), ("Palo Alto", "paloalto")]:
    N = pd.read_pickle(f"{RES}/{nm}_new_r2.pkl"); N["zero"] = 0.0; N = E2.apply_cap(N, CAP[cn]); N["dbin"] = N.days_in_service.map(dbin); NEW[cn] = N
    D = pd.read_pickle(f"{RES}/{nm}_pseudo_r2.pkl"); PSE[cn] = E2.apply_cap(D[D.k == 7].copy(), CAP[cn])
# 1) paired tests on new stations
rng = np.random.default_rng(0); rows = []
for cn in CITIES:
    N = NEW[cn]
    for b in BANDS:
        g = N[(N.dbin == b) & N.y.notna()]
        for m in COMPS:
            s = g.groupby("station").apply(lambda h: pd.Series({"r": E.rmse(h.y.values, h.gbdt.values), "c": E.rmse(h.y.values, h[m].values)}), include_groups=False).dropna()
            diff = (s.r - s.c).to_numpy(); p = wilcoxon(s.r, s.c).pvalue if np.any(diff != 0) else 1.0
            bs = [s.r.to_numpy()[i].mean() / s.c.to_numpy()[i].mean() for i in (rng.integers(0, len(s), len(s)) for _ in range(2000))]
            rows.append(dict(city=cn, band=b, comparator=m, n_stations=len(s), ratio=s.r.mean() / s.c.mean(), ratio_lo=np.percentile(bs, 2.5),
                             ratio_hi=np.percentile(bs, 97.5), share_ref_better=float((s.r < s.c).mean()), p=p))
T = pd.DataFrame(rows); T["p_holm"] = E2.holm(T.p.to_numpy()); T.to_csv(f"{TAB}/r2_new_tests.csv", index=False)
L = [r"\begin{table}[H]", r"\begin{adjustwidth}{-\extralength}{0cm}",
     r"\caption{Paired station-level comparison of the pooled GBDT with other methods on genuinely new stations, by days in service: ratio of mean station RMSE (below 1 favours the GBDT) with a 95\% station bootstrap interval, and Holm-adjusted Wilcoxon $p$ over all comparisons in this table (Boulder: 8 stations; Palo Alto: 25).\label{tab:newtests}}",
     r"\small", r"\begin{tabularx}{\fulllength}{llCcCc}", r"\toprule",
     r" & & \multicolumn{2}{c}{\textbf{Boulder}} & \multicolumn{2}{c}{\textbf{Palo Alto}}\\", r"\cmidrule(lr){3-4}\cmidrule(lr){5-6}",
     r"\textbf{GBDT vs.} & \textbf{Days} & \textbf{Ratio [95\% CI]} & \textbf{$p$} & \textbf{Ratio [95\% CI]} & \textbf{$p$}\\", r"\midrule"]
for mi, m in enumerate(COMPS):
    for bi, b in enumerate(BANDS):
        cells = []
        for cn in CITIES:
            r_ = T[(T.city == cn) & (T.comparator == m) & (T.band == b)].iloc[0]
            pp = "$<$0.001" if r_.p_holm < 0.001 else f"{r_.p_holm:.3f}"
            cells.append(f"{r_.ratio:.3f} [{r_.ratio_lo:.3f}, {r_.ratio_hi:.3f}] & {pp}")
        L.append((NAMES[m] if bi == 0 else "") + f" & {b} & " + " & ".join(cells) + r"\\")
    if mi < len(COMPS) - 1:
        L.append(r"\midrule")
L += [r"\bottomrule", r"\end{tabularx}", r"\end{adjustwidth}", r"\end{table}"]
open(TD + "tab_new_tests.tex", "w", encoding="utf-8").write("\n".join(L))
# 2) Figure 4
apply_figure_style(sizes=(8, 7, 6))
IT = pd.read_csv(f"{TAB}/r2_interval_capped.csv")
def st_cov(D, m, lv=80):
    g = D[D.y.notna() & D[f"{m}_lo{lv}"].notna()]
    return g.assign(h=((g.y >= g[f"{m}_lo{lv}"]) & (g.y <= g[f"{m}_hi{lv}"])).astype(float)).groupby("station").h.mean()
fig, axes = plt.subplots(2, 3, figsize=(7.2, 4.8), gridspec_kw=dict(width_ratios=[1, 1, 1.1], hspace=0.45, wspace=0.32))
mk = {"gbdt": "o", "sn": "^", "peer": "v", "chronos": "s", "tfm3": "P", "tfm3c": "D"}
for i, cn in enumerate(CITIES):
    it = IT[IT.city == cn]
    for j, lv in enumerate((80, 90)):
        ax = axes[i, j]; ax.axhspan(lv / 100 - 0.05, lv / 100 + 0.05, color="#eeeeee", lw=0); ax.axhline(lv / 100, color="#777777", lw=0.8, ls="--")
        for m in (["gbdt", "sn", "peer", "chronos", "tfm3", "tfm3c"] if lv == 80 else ["gbdt", "sn", "peer", "chronos"]):
            im = it[(it.model == m) & (it.level == lv)].set_index("k").reindex(KO)
            ax.plot(np.arange(7), im["cov"], color=COLR[m], label=ILAB[m], lw=2.0 if m == "gbdt" else 1.1, marker=mk[m], ms=3.5,
                    ls="--" if m == "tfm3" else "-")
        ax.set_xticks(range(7)); ax.set_xticklabels([KL[k] for k in KO]); ax.set_ylim(lv / 100 - 0.14, lv / 100 + 0.14)
        ax.set_title(f"{cn}: {lv}% intervals", loc="left"); ax.set_ylabel("Empirical coverage")
        if i == 1:
            ax.set_xlabel("Days of history")
    ax = axes[i, 2]
    for xi, m in enumerate(["gbdt", "sn", "chronos", "tfm3c"]):
        v = st_cov(PSE[cn], m).values; jit = np.random.default_rng(0).uniform(-0.15, 0.15, len(v))
        ax.scatter(np.full(len(v), xi) + jit, v, s=8, color=COLR[m], alpha=0.8, lw=0)
        ax.plot([xi - 0.25, xi + 0.25], [np.median(v)] * 2, color="black", lw=1.2)
    ax.axhspan(0.75, 0.85, color="#eeeeee", lw=0, zorder=0); ax.axhline(0.8, color="#777777", lw=0.8, ls="--")
    ax.set_xticks(range(4)); ax.set_xticklabels(["GBDT", "Naive", "Chronos-2", "TimesFM\n+ cov."], fontsize=6)
    ax.set_title(f"{cn}: per station, 80%, 7 days", loc="left"); ax.set_ylabel("Station coverage")
h, l = axes[0, 0].get_legend_handles_labels()
fig.legend(h + [Patch(color="#eeeeee")], l + ["Nominal \u00b1 5 points"], loc="lower center", ncol=4, frameon=False, fontsize=6, bbox_to_anchor=(0.5, -0.07))
for a, lt in zip(axes.flat, "abcdef"):
    panel_letter(a, lt)
fig.savefig(os.path.join(FD, "fig4_coverage.png"), dpi=300, bbox_inches="tight"); fig.savefig(os.path.join(FD, "fig4_coverage.pdf"), bbox_inches="tight"); plt.close(fig)
# 3) Figure 5
NPT = pd.read_csv(f"{TAB}/r2_new_point.csv", dtype={"dbin": str}); NIT = pd.read_csv(f"{TAB}/r2_new_interval.csv", dtype={"dbin": str})
rb = pd.read_csv("tables/rampup_new.csv", dtype={"dbin": str}).set_index(["city", "dbin"])
xb = np.arange(len(ORDER)); XL = [o.replace("-", "\u2013") for o in ORDER]
fig, axes = plt.subplots(2, 3, figsize=(7.2, 4.8), gridspec_kw=dict(hspace=0.5, wspace=0.36))
for i, cn in enumerate(CITIES):
    r = rb.loc[cn].reindex(ORDER); ax = axes[i, 0]
    ax.axhline(1.0, color="#777777", lw=0.8, ls="--"); ax.plot(xb, r.ratio_obs_to_peer, color="#333333", marker="o", ms=3.5, lw=1.4)
    ax.set_ylim(0, 1.15); ax.set_title(f"{cn}: ramp-up", loc="left"); ax.set_ylabel("Observed / peer demand")
    ax.text(0.03, 0.05, f"n = {NEW[cn].station.nunique()} new stations", transform=ax.transAxes, fontsize=6)
    ax = axes[i, 1]; p = NPT[NPT.city == cn]
    for m, mm in [("gbdt", "o"), ("chronos_qmean", "s"), ("tfm3c_qmean", "D"), ("peer", "v")]:
        pm = p[p.model == m].set_index("dbin").reindex(ORDER)
        ax.plot(xb, pm.dWAPE, color=COLR[m], marker=mm, ms=3.5, lw=2.0 if m == "gbdt" else 1.1)
    ax.set_title(f"{cn}: daily energy error", loc="left"); ax.set_ylabel("Daily WAPE (lower is better)")
    ax = axes[i, 2]; it = NIT[(NIT.city == cn) & (NIT.level == 80)]
    ax.axhspan(0.75, 0.85, color="#eeeeee", lw=0); ax.axhline(0.8, color="#777777", lw=0.8, ls="--")
    for m, mm in [("gbdt", "o"), ("chronos", "s"), ("tfm3c", "D")]:
        im = it[it.model == m].set_index("dbin").reindex(ORDER)
        if m != "gbdt":
            im.loc["0", "cov"] = np.nan
        ax.plot(xb, im["cov"], color=COLR[m], marker=mm, ms=3.5, lw=2.0 if m == "gbdt" else 1.1)
    ax.set_ylim(0.55, 1.0); ax.set_title(f"{cn}: 80% coverage", loc="left"); ax.set_ylabel("Empirical coverage")
    for a in axes[i]:
        a.set_xticks(xb); a.set_xticklabels(XL, fontsize=6)
        if i == 1:
            a.set_xlabel("Days in service")
from matplotlib.lines import Line2D
hs = [Line2D([], [], color=COLR[m], marker=mm, ms=3.5, lw=2.0 if m == "gbdt" else 1.1) for m, mm in [("gbdt", "o"), ("chronos_qmean", "s"), ("tfm3c_qmean", "D"), ("peer", "v")]]
ls_ = ["Pooled GBDT (conformal intervals)", "Chronos-2 (mean; native quantiles)", "TimesFM 3.0 + peer cov. (mean; native quantiles)", "Peer profile"]
fig.legend(hs + [Patch(color="#eeeeee")], ls_ + ["Nominal \u00b1 5 points"], loc="lower center", ncol=3, frameon=False, fontsize=6, bbox_to_anchor=(0.5, -0.07))
for a, lt in zip(axes.flat, "abcdef"):
    panel_letter(a, lt)
fig.savefig(os.path.join(FD, "fig5_newstations.png"), dpi=300, bbox_inches="tight"); fig.savefig(os.path.join(FD, "fig5_newstations.pdf"), bbox_inches="tight"); plt.close(fig)
print("new-station tests and Figures 4 and 5 written", flush=True)
