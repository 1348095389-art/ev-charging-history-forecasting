"""Step 03: station-disjoint cross-fitted experiment (main GBDT, ablations, baselines, conformal intervals)
and the genuinely-new-station experiment.  Writes results/*_models.pkl and results/*_info.pkl."""
import os
import sys
import time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
os.chdir(ROOT)

import argparse  # noqa: E402
import pickle  # noqa: E402

from evfc import _compat  # noqa: E402
from evfc import newsite as NS  # noqa: E402
from evfc import pipeline as PL  # noqa: E402
from evfc import run as RN  # noqa: E402

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--n-jobs", type=int, default=8, help="parallel model fits (thread pool)")
    ap.add_argument("--part", choices=["all", "pseudo", "new"], default="all")
    ap.add_argument("--cities", default="boulder,paloalto")
    a = ap.parse_args()
    if _compat.ensure_thread_pool():
        print("note: multiprocessing ThreadPool unavailable (pipe creation denied); using concurrent.futures pool for joblib threading")
    os.makedirs("results", exist_ok=True)
    ctx = PL.load_context()
    times = {}
    for name in a.cities.split(","):
        city = PL.city_of(ctx, name); cfg = ctx["cfgB"] if name == "boulder" else ctx["cfgP"]
        if a.part in ("all", "pseudo"):
            t = time.time(); logs = []
            # model fits run in a thread pool (HistGradientBoosting releases the GIL); results do not depend on n_jobs
            D, info = RN.run_city(city, cfg, seed=0, n_jobs=a.n_jobs, log=logs.append)
            D.to_pickle(f"results/{name}_pseudo_models.pkl")
            with open(f"results/{name}_info.pkl", "wb") as f:
                pickle.dump(info, f)
            times[f"{name}_pseudo"] = time.time() - t
            print("\n".join(logs)); print(name, "pseudo", D.shape, f"{times[name + '_pseudo']:.1f} s", flush=True)
        if a.part in ("all", "new"):
            t = time.time(); lg = []
            N = NS.run_city_new(city, ctx["newcand"][name], PL.NEW_CFG[name], seed=0, log=lg.append)
            N.to_pickle(f"results/{name}_new_models.pkl")
            times[f"{name}_new"] = time.time() - t
            print("\n".join(lg)); print(name, "new", N.shape, f"{times[name + '_new']:.1f} s", flush=True)
    print("timings_s", {k: round(v, 1) for k, v in times.items()})
