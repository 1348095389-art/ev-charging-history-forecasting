"""Step 13 (round 2): evaluation with the physical-plausibility cap, Winkler scores and station-level tests
-> tables/r2_point_capped.csv, r2_point_uncapped.csv, r2_interval_capped.csv, r2_tests.csv, r2_new_point.csv,
r2_new_interval.csv. Usage: python scripts/13_evaluate_r2.py [results_dir] [tables_dir]"""
import os, sys
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__))); sys.path.insert(0, ROOT); os.chdir(ROOT)
import time
import numpy as np, pandas as pd
from evfc import _compat, pipeline as PL, evaluate_r2 as E2
RES = sys.argv[1] if len(sys.argv) > 1 else "results"; TAB = sys.argv[2] if len(sys.argv) > 2 else "tables"
os.makedirs(TAB, exist_ok=True)
_compat.ensure_thread_pool()
ctx = PL.load_context()
t0=time.time()
CAP={'Boulder':E2.train_cap(ctx['cityB'],ctx['cfgB']['train_end']),'Palo Alto':E2.train_cap(ctx['cityP'],ctx['cfgP']['train_end'])}
FR={}
for cn,nm,city in [('Boulder','boulder',ctx['cityB']),('Palo Alto','paloalto',ctx['cityP'])]:
    D=pd.read_pickle(f'{RES}/{nm}_pseudo_r2.pkl'); N=pd.read_pickle(f'{RES}/{nm}_new_r2.pkl')
    d=np.load(f'gpu/inputs/{nm}.npz')
    D=E2.add_scaled_peer(D,d['series'],d['peer_groups'],list(city.stations))
    D['zero']=0.0; N=N.copy(); N['zero']=0.0
    FR[cn]=dict(pseudo_raw=D,pseudo=E2.apply_cap(D,CAP[cn]),new_raw=N,new=E2.apply_cap(N,CAP[cn]))
PTc,ITc,PTu,TS=[],[],[],[]
comps=['chronos_qmean','ccov_qmean','tfm3_qmean','tfm3c_qmean','lstm','speer','peer','sn']
for cn in FR:
    Dc=FR[cn]['pseudo']; Du=FR[cn]['pseudo_raw']
    p=E2.point_table(Dc); p['city']=cn; PTc.append(p)
    p=E2.point_table(Du); p['city']=cn; PTu.append(p)
    i=E2.interval_table(Dc); i['city']=cn; ITc.append(i)
    TS.append(E2.station_tests(Dc,comps,city=cn,metric='rmse'))
    TS.append(E2.station_tests(Dc,['chronos','ccov','tfm3','tfm3c','sn','peer'],city=cn,metric='winkler'))
PTc=pd.concat(PTc); PTu=pd.concat(PTu); ITc=pd.concat(ITc); TS=pd.concat(TS,ignore_index=True)
TS['p_holm']=np.nan
for met in ['rmse','winkler']:
    m_=TS.metric==met; TS.loc[m_,'p_holm']=E2.holm(TS.loc[m_,'p'].to_numpy())
PTc.to_csv(f'{TAB}/r2_point_capped.csv',index=False); PTu.to_csv(f'{TAB}/r2_point_uncapped.csv',index=False)
ITc.to_csv(f'{TAB}/r2_interval_capped.csv',index=False); TS.to_csv(f'{TAB}/r2_tests.csv',index=False)
# new stations
def dbin(dd):
    for a,b in [(0,0),(1,2),(3,6),(7,13),(14,27),(28,55)]:
        if a<=dd<=b: return f'{a}-{b}' if a!=b else '0'
NP,NI=[],[]
for cn in FR:
    N=FR[cn]['new']; N['dbin']=N.days_in_service.map(dbin)
    p=E2.point_table(N,group='dbin'); p['city']=cn; NP.append(p)
    i=E2.interval_table(N,group='dbin'); i['city']=cn; NI.append(i)
NP=pd.concat(NP); NI=pd.concat(NI); NP.to_csv(f'{TAB}/r2_new_point.csv',index=False); NI.to_csv(f'{TAB}/r2_new_interval.csv',index=False)
print('done',round(time.time()-t0),'s', CAP)