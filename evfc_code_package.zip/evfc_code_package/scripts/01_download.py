"""Step 01: download the two public session datasets into data/raw/ (skip if the files are already present).

Boulder: City of Boulder Open Data, 'Electric Vehicle Charging Station Data' (CC0 1.0), ArcGIS Hub dataset
95992b3938be4622b07f0b05eba95d4c_0.  Palo Alto: City of Palo Alto Open Data dataset 194693, 'Electric Vehicle
Charging Station Usage (July 2011 - Dec 2020)' (portal licence: ODC PDDL).  Portal URLs can change; if a download
fails, fetch the CSV manually and save it under the file name given in evfc/download.py.
"""
import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
os.chdir(ROOT)

from evfc import download as DL  # noqa: E402

if __name__ == "__main__":
    force = "--force" in sys.argv
    for name, url in DL.SOURCES.items():
        dst = os.path.join("data", "raw", name)
        if os.path.exists(dst) and not force:
            print("present:", dst, os.path.getsize(dst), "bytes")
            continue
        try:
            DL.fetch(name, url)
        except Exception as e:  # report and continue
            print("ERR", name, type(e).__name__, str(e)[:300])
