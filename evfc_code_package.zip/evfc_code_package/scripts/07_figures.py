"""Step 07: paper figures figs/fig1_protocol ... figs/fig5_newstations (.png at 300 dpi and .pdf)."""
import os
import sys
import time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
os.chdir(ROOT)

import matplotlib  # noqa: E402

matplotlib.use("Agg")
import matplotlib.dates as mdates  # noqa: E402
import matplotlib.patches as mp  # noqa: E402
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402
from matplotlib.lines import Line2D  # noqa: E402
from matplotlib.patches import Patch  # noqa: E402

from evfc import evaluate as EV  # noqa: E402
from evfc import pipeline as PL  # noqa: E402
from evfc.figstyle import COL, ICOL, ILAB, LAB, STY, apply_figure_style, panel_letter  # noqa: E402

KORD, KLB, ORDER = PL.KORD, PL.KLB, PL.NEW_ORDER


def save(fig, stem):
    fig.savefig(f"figs/{stem}.png", dpi=300, bbox_inches="tight")
    fig.savefig(f"figs/{stem}.pdf", bbox_inches="tight")
    plt.close(fig)


def fig1():
    fig, ax = plt.subplots(figsize=(7.2, 3.3)); ax.set_xlim(0, 100); ax.set_ylim(0, 48); ax.axis("off")

    def box(x, y, w, h, fc, txt, fs=7, ec="none"):
        ax.add_patch(mp.FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.3,rounding_size=0.8", fc=fc, ec=ec, lw=0.8))
        ax.text(x + w / 2, y + h / 2, txt, ha="center", va="center", fontsize=fs)
    ax.text(0, 46, "a  Temporal split (per city)", fontsize=8, fontweight="bold", va="top")
    box(2, 35, 52, 6, "#dde5f2", "Training period\nBoulder 2018-01 to 2022-08; Palo Alto 2011-07 to 2018-09", 6)
    box(55, 35, 13, 6, "#f2d7a6", "Validation\n3 months", 6)
    box(69, 35, 29, 6, "#c9d8ef", "Test: 12 months\ndaily origins at 00:00, hours 1 to 24", 6)
    ax.text(0, 30, "b  Station-disjoint cross-fitting (5 folds)", fontsize=8, fontweight="bold", va="top")
    for f in range(5):
        for g in range(5):
            ax.add_patch(mp.Rectangle((2 + g * 4.2, 21 - f * 2.6), 3.8, 2.2, fc="#1f4e9c" if g == f else "#cfcfcf", lw=0))
    ax.text(24, 16.5, "Test fold (dark) never contributes\nto training, tuning, calibration\nor peer statistics", fontsize=6, va="center")
    ax.text(52, 30, "c  Simulated limited history at each origin", fontsize=8, fontweight="bold", va="top")
    ax.add_patch(mp.Rectangle((54, 19), 40, 3, fc="#eeeeee", lw=0)); ax.text(54, 23.2, "Station record before the origin", fontsize=6)
    for k, (x0, lab) in enumerate([(90, "k = 1"), (86, "k = 7"), (76, "k = 28")]):
        ax.add_patch(mp.Rectangle((x0, 15.5 - k * 3), 94 - x0, 2.2, fc=COL["gbdt"], alpha=0.35 + 0.2 * k, lw=0))
        ax.text(x0 - 0.8, 16.6 - k * 3, lab, fontsize=6, ha="right", va="center")
    ax.plot([94, 94], [9, 23], color="black", lw=0.8); ax.text(94.8, 10, "origin", fontsize=6, va="center")
    ax.add_patch(mp.Rectangle((94.2, 19), 4, 3, fc="#f4c27a", lw=0)); ax.text(96.2, 24.2, "next 24 h", fontsize=6, ha="center")
    ax.text(0, 1, "Genuinely new stations: models are trained only on stations in service before each commissioning batch and "
            "only on data before its first day;\nthe new stations are then forecast for their first 56 days with the history "
            "actually available (k = days in service).", fontsize=6, va="bottom")
    save(fig, "fig1_protocol")


def fig2(ctx):
    spans = {"Boulder": (ctx["cfgB"], ctx["cityB"], ctx["newcand"]["boulder"], ctx["Hb"]),
             "Palo Alto": (ctx["cfgP"], ctx["cityP"], ctx["newcand"]["paloalto"], ctx["HPc"])}
    fig, axes = plt.subplots(2, 2, figsize=(7.2, 5.2), gridspec_kw=dict(height_ratios=[1.3, 1], hspace=0.5, wspace=0.3))
    for j, (nm, (cf, city, nc, Hm)) in enumerate(spans.items()):
        ax = axes[0, j]; sts = sorted(city.stations, key=lambda s: city.first[s]); d = city.days
        for i, s in enumerate(sts):
            on = np.flatnonzero(np.isfinite(city.Y[s]).any(1))
            for sg in np.split(on, np.flatnonzero(np.diff(on) > 1) + 1):
                ax.plot([d[sg[0]], d[sg[-1]]], [i, i], color=COL["gbdt"] if s in nc else "#b0b0b0",
                        lw=1.5 if s in nc else 0.9, solid_capstyle="butt")
        ax.set_yticks([]); ax.set_ylabel("Station (by commissioning date)")
        ax.set_title(f"{nm}: {len(sts)} stations, {len(nc)} genuinely new", loc="left")
        ax.xaxis.set_major_locator(mdates.YearLocator(2)); ax.xaxis.set_major_formatter(mdates.DateFormatter("%Y"))
        ax.margins(x=0.01, y=0.03)
        ax2 = axes[1, j]; dd = Hm.sum(axis=1, min_count=1).resample("D").sum(); wk = dd.resample("W").agg(["sum", "count"])
        daily = (wk["sum"] / wk["count"])[wk["count"] == 7]
        ax2.axvspan(pd.Timestamp(cf["val_start"]), pd.Timestamp(cf["val_end"]), color="#f2d7a6", lw=0)
        ax2.axvspan(pd.Timestamp(cf["test_start"]), pd.Timestamp(cf["test_end"]), color="#c9d8ef", lw=0)
        ax2.plot(daily.index, daily.values, color="#333333", lw=0.8)
        ax2.set_ylabel("Energy (kWh/day)"); ax2.set_ylim(0, daily.max() * 1.1)
        ax2.xaxis.set_major_locator(mdates.YearLocator(2)); ax2.xaxis.set_major_formatter(mdates.DateFormatter("%Y"))
        ax2.set_title(f"{nm}: network energy, weekly mean", loc="left")
    fig.legend(handles=[Line2D([], [], color=COL["gbdt"], lw=1.5, label="Genuinely new station (first 56 days evaluated)"),
                        Line2D([], [], color="#b0b0b0", lw=0.9, label="Other station"),
                        Patch(color="#f2d7a6", label="Validation period"), Patch(color="#c9d8ef", label="Test period")],
               loc="lower center", ncol=4, frameon=False, fontsize=6, bbox_to_anchor=(0.5, -0.02))
    for a, lt in zip(axes.flat, "abcd"):
        panel_letter(a, lt)
    save(fig, "fig2_data")


def fig3(BR, PT):
    models3 = ["gbdt", "chronos_qmean", "chronos", "peer", "sn", "zero"]
    fig, axes = plt.subplots(2, 2, figsize=(7.2, 5.0), sharex=True, gridspec_kw=dict(hspace=0.25, wspace=0.24))
    for j, nm in enumerate(["Boulder", "Palo Alto"]):
        ax = axes[0, j]; b = BR[BR.city == nm]; p = PT[PT.city == nm]
        for m in models3:
            bm = b[b.model == m].set_index("k").reindex(KORD); ax.plot(np.arange(7), bm.rmse, color=COL[m], label=LAB[m], **STY[m])
        ax.set_title(f"{nm}: hourly RMSE vs days of history", loc="left"); ax.set_ylabel("RMSE, kWh (lower is better)")
        ax2 = axes[1, j]
        for m in models3:
            if m == "zero":
                continue
            pm = p[p.model == m].set_index("k").reindex(KORD); ax2.plot(np.arange(7), pm.dWAPE, color=COL[m], label=LAB[m], **STY[m])
        ax2.set_title(f"{nm}: station-day energy error", loc="left"); ax2.set_ylabel("Daily WAPE (lower is better)")
        ax2.set_xticks(range(7)); ax2.set_xticklabels(KLB); ax2.set_xlabel("Days of station history available")
        for a in (ax, ax2):
            a.margins(x=0.04, y=0.06)
    h, l = axes[0, 0].get_legend_handles_labels()
    fig.legend(h, l, loc="lower center", ncol=6, frameon=False, fontsize=6, bbox_to_anchor=(0.5, -0.03))
    for a, lt in zip(axes.flat, "abcd"):
        panel_letter(a, lt)
    save(fig, "fig3_history")


def st_cov(D, m, lv, k):
    g = D[D.k == k]
    return g.groupby("station").apply(lambda h: EV.coverage(h, m, lv)[0], include_groups=False)


def fig4(IT, DB, DP):
    fig, axes = plt.subplots(2, 3, figsize=(7.2, 4.8), gridspec_kw=dict(width_ratios=[1, 1, 0.9], hspace=0.45, wspace=0.32))
    for i, nm in enumerate(["Boulder", "Palo Alto"]):
        it = IT[IT.city == nm]; D = DB if nm == "Boulder" else DP
        for j, lv in enumerate((80, 90)):
            ax = axes[i, j]; ax.axhspan(lv / 100 - 0.05, lv / 100 + 0.05, color="#eeeeee", lw=0)
            ax.axhline(lv / 100, color="#777777", lw=0.8, ls="--")
            for m, mk in [("gbdt", "o"), ("sn", "^"), ("peer", "v"), ("chronos", "s")]:
                im = it[it.model == m].set_index("k").reindex(KORD)
                ax.plot(np.arange(7), im[f"cov{lv}"], color=ICOL[m], label=ILAB[m], lw=2.0 if m == "gbdt" else 1.1, marker=mk, ms=3.5)
            ax.set_xticks(range(7)); ax.set_xticklabels(KLB); ax.set_ylim(lv / 100 - 0.12, lv / 100 + 0.12)
            ax.set_title(f"{nm}: {lv}% intervals", loc="left"); ax.set_ylabel("Empirical coverage")
            if i == 1:
                ax.set_xlabel("Days of history")
        ax = axes[i, 2]
        for xi, m in enumerate(["gbdt", "sn", "chronos"]):
            v = st_cov(D, m, 80, 7).values; jit = np.random.default_rng(0).uniform(-0.15, 0.15, len(v))
            ax.scatter(np.full(len(v), xi) + jit, v, s=8, color=ICOL[m], alpha=0.8, lw=0)
            ax.plot([xi - 0.25, xi + 0.25], [np.median(v)] * 2, color="black", lw=1.2)
        ax.axhspan(0.75, 0.85, color="#eeeeee", lw=0, zorder=0); ax.axhline(0.8, color="#777777", lw=0.8, ls="--")
        ax.set_xticks(range(3)); ax.set_xticklabels(["GBDT", "Naive", "Chronos-2"])
        ax.set_title(f"{nm}: per station, 80%, 7 days", loc="left"); ax.set_ylabel("Station coverage")
    h, l = axes[0, 0].get_legend_handles_labels()
    fig.legend(h + [Patch(color="#eeeeee")], l + ["Nominal \u00b1 5 points"], loc="lower center", ncol=5, frameon=False,
               fontsize=6, bbox_to_anchor=(0.5, -0.04))
    for a, lt in zip(axes.flat, "abcdef"):
        panel_letter(a, lt)
    save(fig, "fig4_coverage")


def fig5(rb, NPT, NIT, nst):
    xb = np.arange(len(ORDER))
    fig, axes = plt.subplots(2, 3, figsize=(7.2, 4.8), gridspec_kw=dict(hspace=0.5, wspace=0.36))
    for i, nm in enumerate(["Boulder", "Palo Alto"]):
        r = rb.loc[nm].reindex(ORDER); ax = axes[i, 0]
        ax.axhline(1.0, color="#777777", lw=0.8, ls="--"); ax.plot(xb, r.ratio_obs_to_peer, color="#333333", marker="o", ms=3.5, lw=1.4)
        ax.set_ylim(0, 1.15); ax.set_title(f"{nm}: ramp-up", loc="left"); ax.set_ylabel("Observed / peer demand")
        ax.text(0.03, 0.05, f"n = {nst[nm]} new stations", transform=ax.transAxes, fontsize=6)
        ax = axes[i, 1]; p = NPT[NPT.city == nm]
        for m, mk in [("gbdt", "o"), ("chronos_qmean", "s"), ("peer", "v"), ("sn", "^")]:
            pm = p[p.model == m].set_index("dbin").reindex(ORDER)
            ax.plot(xb, pm.dWAPE, color=COL[m], label=LAB[m], marker=mk, ms=3.5, lw=2.0 if m == "gbdt" else 1.1)
        ax.set_title(f"{nm}: daily energy error", loc="left"); ax.set_ylabel("Daily WAPE (lower is better)")
        ax = axes[i, 2]; it = NIT[NIT.city == nm]
        ax.axhspan(0.75, 0.85, color="#eeeeee", lw=0); ax.axhline(0.8, color="#777777", lw=0.8, ls="--")
        for m, mk in [("gbdt", "o"), ("chronos", "s")]:
            im = it[it.model == m].set_index("dbin").reindex(ORDER)
            ax.plot(xb, im.cov80, color=ICOL[m], marker=mk, ms=3.5, lw=2.0 if m == "gbdt" else 1.1)
        ax.set_ylim(0.55, 1.0); ax.set_title(f"{nm}: 80% coverage", loc="left"); ax.set_ylabel("Empirical coverage")
        for a in axes[i]:
            a.set_xticks(xb); a.set_xticklabels(ORDER, fontsize=6)
            if i == 1:
                a.set_xlabel("Days in service")
    h1, _ = axes[0, 1].get_legend_handles_labels()
    l1 = ["Pooled GBDT (conformal intervals)", "Chronos-2 (mean; native quantiles)", "Peer profile", "Seasonal naive"]
    fig.legend(h1 + [Patch(color="#eeeeee")], l1 + ["Nominal \u00b1 5 points"], loc="lower center", ncol=5, frameon=False,
               fontsize=6, bbox_to_anchor=(0.5, -0.04))
    for a, lt in zip(axes.flat, "abcdef"):
        panel_letter(a, lt)
    save(fig, "fig5_newstations")


if __name__ == "__main__":
    t0 = time.time()
    os.makedirs("figs", exist_ok=True)
    apply_figure_style(sizes=(8, 7, 6))
    ctx = PL.load_context()
    PT = pd.read_csv("tables/point_metrics_pseudo.csv"); IT = pd.read_csv("tables/interval_metrics_pseudo.csv")
    BR = pd.read_csv("tables/rmse_bootstrap_pseudo.csv")
    NPT = pd.read_csv("tables/point_metrics_new.csv", dtype={"dbin": str})
    NIT = pd.read_csv("tables/interval_metrics_new.csv", dtype={"dbin": str})
    rb = pd.read_csv("tables/rampup_new.csv", dtype={"dbin": str}).set_index(["city", "dbin"])
    DB = pd.read_pickle("results/boulder_pseudo.pkl"); DP = pd.read_pickle("results/paloalto_pseudo.pkl")
    nst = {"Boulder": pd.read_pickle("results/boulder_new.pkl").station.nunique(),
           "Palo Alto": pd.read_pickle("results/paloalto_new.pkl").station.nunique()}
    fig1(); fig2(ctx); fig3(BR, PT); fig4(IT, DB, DP); fig5(rb, NPT, NIT, nst)
    print(sorted(os.listdir("figs")))
    print(f"07_figures done in {time.time() - t0:.1f} s")
