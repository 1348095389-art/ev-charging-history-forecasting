"""Step 12 (round 2): merge the GPU outputs (Chronos-2 with peer covariates, TimesFM 3.0 with and without peer
covariates, global LSTM) into the result frames -> results/{city}_pseudo_r2.pkl, results/{city}_new_r2.pkl.
Usage: python scripts/12_merge_gpu.py <directory with the 14 .npz files produced by gpu/run_all.sh>"""
import os, sys
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__))); sys.path.insert(0, ROOT); os.chdir(ROOT)
import numpy as np, pandas as pd
WCH = np.array([.075, .1, .2, .25, .2, .1, .075])  # Chronos-2 quantile-mean weights (7 levels)
WTF = np.array([.15] + [.1] * 7 + [.15])  # TimesFM 3.0 quantile-mean weights (9 levels)

def merge_fm(D, path, prefix, keys_df, kind):
    z=np.load(path); M_=z['mean']; Q=z['q']; ql=list(np.round(z['ql'],2)); W_=WCH if len(ql)==7 else WTF
    R=keys_df.copy(); R['row']=np.arange(len(R)); on=['station','t','k'] if kind=='pseudo' else ['station','t']
    m=D[on+['hour']].merge(R[on+['row']],on=on,how='left'); r=m.row.to_numpy(); h=m.hour.to_numpy(); ok=~np.isnan(r); ri=np.where(ok,r,0).astype(int)
    take=lambda A: np.where(ok,A[ri,h],np.nan).astype(float)
    D[prefix]=take(M_); D[prefix+'_qmean']=take((Q*W_).sum(-1))
    D[prefix+'_lo80']=take(Q[...,ql.index(0.1)]); D[prefix+'_hi80']=take(Q[...,ql.index(0.9)])
    if 0.05 in ql: D[prefix+'_lo90']=take(Q[...,ql.index(0.05)]); D[prefix+'_hi90']=take(Q[...,ql.index(0.95)])
    fb=(D[prefix].isna()&(D.k_eff>0)&ok).to_numpy()
    # same rule as univariate Chronos-2: an own-history window without any observed value gets the peer forecast
    if 'nvalid' in D:
        fb=fb|((D.nvalid==0)&(D.k_eff>0)&ok).to_numpy()
    for c_ in [prefix,prefix+'_qmean']: D.loc[fb,c_]=D.loc[fb,'peer']
    for lv in ([80,90] if 0.05 in ql else [80]):
        for s_ in ['lo','hi']: D.loc[fb,f'{prefix}_{s_}{lv}']=D.loc[fb,f'peer_{s_}{lv}']
    D[prefix+'_fb']=fb
    # no forecast is reported at zero own history (target entirely missing), as for the univariate models
    cols=[c for c in D.columns if c==prefix or c.startswith(prefix+'_')]
    D.loc[(D.k_eff==0).to_numpy(), [c for c in cols if c!=prefix+'_fb']]=np.nan
    return D

if __name__ == "__main__":
    OUT = sys.argv[1]; RES = sys.argv[2] if len(sys.argv) > 2 else "results"
    RK = pd.read_pickle("gpu/row_keys.pkl")
    for nm in ["boulder", "paloalto"]:
        D = pd.read_pickle(f"results/{nm}_pseudo.pkl"); N = pd.read_pickle(f"results/{nm}_new.pkl")
        for kind, X in [("pseudo", D), ("new", N)]:
            keys = RK[nm][0] if kind == "pseudo" else RK[nm][1]
            for job, pre in [("chronos_cov", "ccov"), ("timesfm3", "tfm3"), ("timesfm3_cov", "tfm3c")]:
                merge_fm(X, f"{OUT}/{job}_{nm}_{kind}.npz", pre, keys, kind)
        z = np.load(f"{OUT}/lstm_{nm}.npz"); P = z["pred"]; keys = RK[nm][0].copy(); keys["row"] = np.arange(len(keys))
        m = D[["station", "t", "k", "hour"]].merge(keys[["station", "t", "k", "row"]], on=["station", "t", "k"], how="left")
        ri = m.row.to_numpy().astype(int); h = m.hour.to_numpy()
        D["lstm"] = P.mean(0)[ri, h].astype(float)
        for s_ in range(P.shape[0]):
            D[f"lstm_s{s_}"] = P[s_][ri, h].astype(float)
        os.makedirs(RES, exist_ok=True)
        D.to_pickle(f"{RES}/{nm}_pseudo_r2.pkl"); N.to_pickle(f"{RES}/{nm}_new_r2.pkl")
        print(nm, "merged", D.shape, N.shape, flush=True)
