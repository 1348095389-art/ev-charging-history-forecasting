"""Step 04: write the Chronos-2 inference inputs chronos_in/{boulder,paloalto}_{pseudo,new}.npz and meta.pkl.

Each npz holds `series` (n_stations x n_hours float32, NaN = missing) and `spec` (n x 3 int32:
station index, forecast-origin day, k_eff = days of context).  The row order of `spec` defines the row order of
the Chronos output arrays, so this step must run on the results of step 03.
"""
import os
import sys
import time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
os.chdir(ROOT)

import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402

from evfc import pipeline as PL  # noqa: E402

if __name__ == "__main__":
    t = time.time()
    ctx = PL.load_context()
    D = {n: pd.read_pickle(f"results/{n}_pseudo_models.pkl") for n in ("boulder", "paloalto")}
    PL.chronos_inputs(ctx, D)
    for f in sorted(os.listdir("chronos_in")):
        if f.endswith(".npz"):
            z = np.load(os.path.join("chronos_in", f))
            msg = f"{f}: series {z['series'].shape}, spec {z['spec'].shape}"
            out = os.path.join("chronos_out", "chronos_" + f)
            if os.path.exists(out):
                nq = np.load(out)["q"].shape[0]
                msg += f"; chronos_out rows {nq} -> {'OK' if nq == len(z['spec']) else 'MISMATCH'}"
            print(msg)
    print(f"04_chronos_inputs done in {time.time() - t:.1f} s")
