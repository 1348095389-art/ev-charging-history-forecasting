"""Step 16 (round 3): cap shares, a priori 19.2 kWh cap sensitivity, new-minus-control coverage gap bootstrap and
the extra appendix tables (tab_capshare, tab_cov90, tab_winkler_tests_full, tab_gap, tab_nomask).
Usage: python scripts/16_revision_extras.py [results_dir] [tables_dir] [manuscript_dir]"""
import os, sys
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__))); sys.path.insert(0, ROOT); os.chdir(ROOT)
import numpy as np, pandas as pd
from evfc import _compat, pipeline as PL, evaluate_r2 as E2, report_r2 as RR
RES = sys.argv[1] if len(sys.argv) > 1 else "results"; TAB = sys.argv[2] if len(sys.argv) > 2 else "tables"
MS = sys.argv[3] if len(sys.argv) > 3 else "manuscript"; TD = os.path.join(MS, "tables") + os.sep; os.makedirs(TD, exist_ok=True)
W = lambda f, s: open(TD + f, "w", encoding="utf-8").write(s)
KO = RR.KO; KL = RR.KL; CITIES = RR.CITIES; A_PRIORI_CAP = 38.4  # kWh: two connectors at the SAE J1772 Level 2 maximum (80 A x 240 V) for one hour
_compat.ensure_thread_pool(); ctx = PL.load_context()
CAP = {"Boulder": E2.train_cap(ctx["cityB"], ctx["cfgB"]["train_end"]), "Palo Alto": E2.train_cap(ctx["cityP"], ctx["cfgP"]["train_end"])}
RAW = {}
for cn, nm, city in [("Boulder", "boulder", ctx["cityB"]), ("Palo Alto", "paloalto", ctx["cityP"])]:
    D = pd.read_pickle(f"{RES}/{nm}_pseudo_r2.pkl"); d = np.load(f"gpu/inputs/{nm}.npz")
    D = E2.add_scaled_peer(D, d["series"], d["peer_groups"], list(city.stations)); D["zero"] = 0.0
    N = pd.read_pickle(f"{RES}/{nm}_new_r2.pkl"); RAW[cn] = (D, N, nm)
# 1) share of forecasts changed by the training-maximum cap
rows = []
for cn, (D, N, nm) in RAW.items():
    for k in KO:
        g = D[(D.k == k) & D.y.notna()]; r = dict(city=cn, k=k)
        for m in ["gbdt", "lstm", "chronos", "chronos_qmean", "ccov", "ccov_qmean", "tfm3", "tfm3_qmean", "tfm3c", "tfm3c_qmean", "peer", "sn"]:
            if g[m].notna().any():
                r[m + "_shcap"] = float((g[m] > CAP[cn]).mean())
        rows.append(r)
CP = pd.DataFrame(rows); CP.to_csv(f"{TAB}/r2_cap_shares.csv", index=False)
CS = pd.DataFrame([dict(city=r.city, k=r.k, model=m, share=100 * r.get(m + "_shcap") if pd.notna(r.get(m + "_shcap")) else np.nan)
                   for _, r in CP.iterrows() for m in ["gbdt", "lstm", "chronos_qmean", "ccov_qmean", "tfm3_qmean", "tfm3c_qmean"]])
W("tab_capshare.tex", RR.table_by_k(CS, ["gbdt", "lstm", "chronos_qmean", "ccov_qmean", "tfm3_qmean", "tfm3c_qmean"], "share", "Share of forecasts (\\%) changed by the cap at the largest training-period hourly energy, by days of history.", "tab:capshare", RR.PNAME, fmt="{:.2f}"))
# 2) a priori cap sensitivity
PTc = pd.read_csv(f"{TAB}/r2_point_capped.csv"); P19 = []
for cn, (D, N, nm) in RAW.items():
    p = E2.point_table(E2.apply_cap(D, A_PRIORI_CAP)); p["city"] = cn; P19.append(p)
X = pd.concat(P19).merge(PTc[["city", "k", "model", "RMSE"]], on=["city", "k", "model"], suffixes=("_19", "_c"))
X["d"] = X.RMSE_19 - X.RMSE_c; X.to_csv(f"{TAB}/r2_cap192_sensitivity.csv", index=False)
# 3) new-minus-control coverage gap with station and batch bootstrap
def dbin(dd):
    for a, b in [(0, 0), (1, 2), (3, 6), (7, 13), (14, 27), (28, 55)]:
        if a <= dd <= b:
            return f"{a}-{b}" if a != b else "0"
rng = np.random.default_rng(0); rowsG = []
for cn, (D, N, nm) in RAW.items():
    Nn = N.copy(); Cc = pd.read_pickle(f"results/{nm}_control.pkl")
    for X_ in (Nn, Cc):
        X_["dbin"] = X_.days_in_service.map(dbin); X_["hit"] = ((X_.y >= X_.gbdt_lo80) & (X_.y <= X_.gbdt_hi80)).astype(float)
        X_.loc[X_.y.isna(), "hit"] = np.nan
    for band in ["1-2", "3-6", "7-13", "14-27", "28-55", "1-55"]:
        sel = (lambda X_: X_[X_.dbin != "0"]) if band == "1-55" else (lambda X_: X_[X_.dbin == band])
        a = sel(Nn).dropna(subset=["hit"]); b = sel(Cc).dropna(subset=["hit"])
        sa = a.groupby("station").hit.agg(["sum", "count"]); sb = b.groupby("station").hit.agg(["sum", "count"])
        ba = a.groupby("batch_onset").hit.agg(["sum", "count"]); bb = b.groupby("batch_onset").hit.agg(["sum", "count"])
        def boot(A, Bq, n=4000):
            ia = rng.integers(0, len(A), (n, len(A))); ib = rng.integers(0, len(Bq), (n, len(Bq)))
            ga = A["sum"].to_numpy()[ia].sum(1) / A["count"].to_numpy()[ia].sum(1); gb = Bq["sum"].to_numpy()[ib].sum(1) / Bq["count"].to_numpy()[ib].sum(1)
            return np.percentile(ga - gb, [2.5, 97.5])
        cs = boot(sa, sb); cb = boot(ba, bb)
        rowsG.append(dict(city=cn, band=band, cov_new=a.hit.mean(), cov_ctrl=b.hit.mean(), gap=a.hit.mean() - b.hit.mean(), st_lo=cs[0], st_hi=cs[1],
                          bt_lo=cb[0], bt_hi=cb[1], n_new=len(sa), n_ctrl=len(sb), n_batches=len(ba)))
G = pd.DataFrame(rowsG); G.to_csv(f"{TAB}/newsite_gap_bootstrap.csv", index=False)
ITc = pd.read_csv(f"{TAB}/r2_interval_capped.csv"); TS = pd.read_csv(f"{TAB}/r2_tests.csv")
I90 = ITc[ITc.level == 90]; I9N = {m: RR.INAME[m] for m in ["gbdt", "chronos", "ccov", "sn", "peer"]}
W("tab_cov90.tex", RR.table_by_k(I90, list(I9N), "cov", "Empirical coverage of 90\\% prediction intervals by days of history (nominal 0.90). TimesFM~3.0 returns no quantiles beyond 0.1 and 0.9 and is therefore not included.", "tab:cov90", I9N))
WC = {m: RR.INAME[m] for m in ["chronos", "ccov", "tfm3", "tfm3c", "sn", "peer"]}
W("tab_winkler_tests_full.tex", RR.tests_full_wide(TS, "winkler", "All paired station-level comparisons of 80\\% interval scores. Ratio: mean station interval score of the conformal GBDT intervals divided by that of the comparator, with a 95\\% station bootstrap interval. Share: fraction of stations on which the GBDT has the lower score. $p$: Holm-adjusted over all interval-score comparisons.", "tab:winklertestsfull", WC))
L = [r"\begin{table}[H]", r"\caption{Difference in conformal 80\% coverage of the GBDT between genuinely new stations and mature control stations under the same batch protocol, by days since the onset, with 95\% bootstrap intervals from resampling stations and from resampling commissioning batches (7 per city; 4000 resamples).\label{tab:gap}}", r"\small",
     r"\begin{tabularx}{\textwidth}{llCCCCC}", r"\toprule", r"\textbf{City} & \textbf{Days} & \textbf{Cov. new} & \textbf{Cov. control} & \textbf{Difference} & \textbf{95\% CI (stations)} & \textbf{95\% CI (batches)}\\", r"\midrule"]
for ci, c in enumerate(CITIES):
    for j, (_, r_) in enumerate(G[G.city == c].iterrows()):
        L.append((c if j == 0 else "") + f" & {r_.band} & {r_.cov_new:.3f} & {r_.cov_ctrl:.3f} & {r_.gap:+.3f} & [{r_.st_lo:+.3f}, {r_.st_hi:+.3f}] & [{r_.bt_lo:+.3f}, {r_.bt_hi:+.3f}]\\\\")
    if ci == 0:
        L.append(r"\midrule")
L += [r"\bottomrule", r"\end{tabularx}", r"\end{table}"]; W("tab_gap.tex", "\n".join(L))
nm_ = pd.read_csv(f"{TAB}/nomask_sensitivity.csv"); nm2 = nm_[nm_.set.isin(["main (masked)", "no masking, all stations"])]
L = [r"\begin{table}[H]", r"\begin{adjustwidth}{-\extralength}{0cm}", r"\caption{Sensitivity to outage masking: pooled GBDT and peer-profile hourly RMSE (kWh) and conformal 80\% coverage of the GBDT in the main run (outages masked) and in a rerun without outage masking (all eligible stations).\label{tab:nomask}}", r"\small",
     r"\begin{tabularx}{\fulllength}{lllCCCCCCC}", r"\toprule", r"\textbf{City} & \textbf{Run} & \textbf{Metric} & " + " & ".join(r"\textbf{%s}" % KL[k] for k in KO) + r"\\", r"\midrule"]
for ci, c in enumerate(CITIES):
    first = True
    for setn, lab in [("main (masked)", "Masked"), ("no masking, all stations", "Not masked")]:
        for met, ml in [("gbdt", "RMSE GBDT"), ("peer", "RMSE peer"), ("cov80", "Cov. 80\\%")]:
            vals = [nm2[(nm2.city == c) & (nm2.set == setn) & (nm2.k == k)][met] for k in KO]
            L.append((c if first else "") + " & " + (lab if met == "gbdt" else "") + f" & {ml} & " + " & ".join(f"{float(v.iloc[0]):.3f}" if len(v) and pd.notna(v.iloc[0]) else "--" for v in vals) + r"\\"); first = False
    if ci == 0:
        L.append(r"\midrule")
L += [r"\bottomrule", r"\end{tabularx}", r"\end{adjustwidth}", r"\end{table}"]; W("tab_nomask.tex", "\n".join(L))
print("extras written", flush=True)
