"""Step 10 (revision): mature-station control for the new-station experiment -> results/{city}_control.pkl"""
import os, sys, time
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__))); sys.path.insert(0, ROOT); os.chdir(ROOT)
from evfc import _compat, pipeline as PL, newsite_control as NC
if __name__ == "__main__":
    _compat.ensure_thread_pool()
    ctx = PL.load_context()
    for name in ["boulder", "paloalto"]:
        t = time.time(); lg = []
        city = PL.city_of(ctx, name)
        D = NC.run_city_control(city, ctx["newcand"][name], PL.NEW_CFG[name], seed=0, log=lg.append)
        D.to_pickle(f"results/{name}_control.pkl")
        print("\n".join(lg)); print(name, "control", D.shape, D.station.nunique(), f"{time.time()-t:.1f}s", flush=True)
