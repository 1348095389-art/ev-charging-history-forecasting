#!/usr/bin/env bash
# Step 05 (GPU host, Linux): create an environment for Chronos-2 and run inference on the step-04 inputs.
# Copy chronos_in/ and evfc/ to the GPU host, run this from the package root, then copy chronos_out/ back.
set -euo pipefail
python3 -m venv .venv-chronos
source .venv-chronos/bin/activate
pip install --upgrade pip
pip install torch                      # choose the CUDA build that matches the host
pip install chronos-forecasting==2.3.2 numpy
python scripts/05_chronos_infer.py boulder_pseudo paloalto_pseudo boulder_new paloalto_new
ls -lh chronos_out/
