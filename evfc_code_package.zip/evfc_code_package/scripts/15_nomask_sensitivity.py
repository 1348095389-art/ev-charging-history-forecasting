"""Step 15 (round 2): sensitivity without outage masking. Copies the package to ../evfc_nomask with OUTAGE_DAYS
disabled in evfc/prep.py and reruns steps 02 and 03 (pseudo-new part) there; compare with tables/nomask_sensitivity.csv."""
import os, sys
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__))); sys.path.insert(0, ROOT); os.chdir(ROOT)
import shutil, subprocess
NM = os.path.abspath(os.path.join(ROOT, "..", "evfc_nomask"))
if not os.path.exists(NM):
    for d in ["evfc", "scripts", os.path.join("data", "raw")]:
        shutil.copytree(os.path.join(ROOT, d), os.path.join(NM, d))
p = os.path.join(NM, "evfc", "prep.py"); s = open(p, encoding="utf-8").read()
open(p, "w", encoding="utf-8").write(s.replace("OUTAGE_DAYS = 14", "OUTAGE_DAYS = 10 ** 9  # sensitivity: no outage masking"))
for step in [["scripts/02_prepare.py"], ["scripts/03_experiment.py", "--part", "pseudo"]]:
    subprocess.run([sys.executable] + step, cwd=NM, check=True)
