"""Step 18 (round 3): typography of the manuscript tables: true minus and plus signs for signed numbers, en dashes in
day ranges such as 1--2, and flexible float placement. Usage: python scripts/18_typeset_tables.py [manuscript_dir]"""
import os, re, sys
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__))); os.chdir(ROOT)
MS = sys.argv[1] if len(sys.argv) > 1 else "manuscript"; TD = os.path.join(MS, "tables")
def typeset(s, keep_here=False):
    s = s.replace(r"\begin{table}[H]", r"\begin{table}[!htbp]")
    if keep_here:  # appendix tables stay in place so that the references follow the last one directly
        s = s.replace(r"\begin{table}[!htbp]", r"\begin{table}[H]")
    out = []
    for line in s.split("\n"):
        if "&" in line and not line.lstrip().startswith("\\"):
            cells = line.split("&")
            new = []
            for c in cells:
                c = re.sub(r"^(\s*)(\d{1,2})-(\d{1,2})(\s*(?:\\\\)?\s*)$", r"\1\2--\3\4", c)       # day ranges
                c = re.sub(r"(?<![\w$\-{])-(\d)", r"$-$\1", c)                         # minus sign
                c = re.sub(r"(?<![\w$])\+(\d)", r"$+$\1", c)                           # explicit plus sign
                new.append(c)
            line = "&".join(new)
        out.append(line)
    return "\n".join(out)
if __name__ == "__main__":
    n = 0
    mt = open(os.path.join(MS, "main.tex"), encoding="utf-8").read()
    app = set(re.findall(r"\\input\{tables/([^}]*)\}", mt[mt.find("\\appendixstart"):])) if "\\appendixstart" in mt else set()
    for f in sorted(os.listdir(TD)):
        if f.endswith(".tex"):
            p = os.path.join(TD, f); s = open(p, encoding="utf-8").read(); t = typeset(s, keep_here=f[:-4] in app)
            if t != s:
                open(p, "w", encoding="utf-8").write(t); n += 1
    print("typeset", n, "tables", flush=True)
