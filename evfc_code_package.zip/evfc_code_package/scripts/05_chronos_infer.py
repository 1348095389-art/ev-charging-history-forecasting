"""Step 05 (GPU): zero-shot Chronos-2 inference for every chronos_in/*.npz -> chronos_out/chronos_*.npz.

Requires torch and chronos-forecasting 2.3.2 (model amazon/chronos-2).  The original run used an NVIDIA
DGX Spark (GB10) with CUDA; evfc/chronos_infer.py falls back to CPU (much slower) if CUDA is unavailable.
Usage (from the package root):  python scripts/05_chronos_infer.py [name ...]
with name in boulder_pseudo, paloalto_pseudo, boulder_new, paloalto_new (default: all four).
"""
import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
os.chdir(ROOT)

from evfc import chronos_infer  # noqa: E402  (imports torch and chronos)

if __name__ == "__main__":
    names = sys.argv[1:] or ["boulder_pseudo", "paloalto_pseudo", "boulder_new", "paloalto_new"]
    os.makedirs("chronos_out", exist_ok=True)
    for n in names:
        chronos_infer.main(f"chronos_in/{n}.npz", f"chronos_out/chronos_{n}.npz")
