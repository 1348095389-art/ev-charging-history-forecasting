"""Step 11 (round 2): export the inputs for the GPU models -> gpu/inputs/{city}.npz and gpu/row_keys.pkl.
Requires results/{city}_pseudo.pkl, results/{city}_new.pkl and results/{city}_info.pkl from steps 03 to 06."""
import os, sys
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__))); sys.path.insert(0, ROOT); os.chdir(ROOT)
import pickle
import numpy as np, pandas as pd
from evfc import pipeline as PL

def build(name, city, cfg, info, D, N):
    st=list(city.stations); si={s:i for i,s in enumerate(st)}
    series=np.vstack([city.Y[s].reshape(-1) for s in st]).astype('float32'); H=series.shape[1]
    first=np.array([city.first[s] for s in st],dtype='int32')
    elig=cfg['eligible']; folds=info['folds']; fold_of=np.full(len(st),-1,dtype='int16')
    for f,fs in enumerate(folds):
        for s in fs: fold_of[si[s]]=f
    # pseudo: peer group = training stations of fold f (all except fold f members)
    pg=np.vstack([np.nanmean(series[[i for i in range(len(st)) if fold_of[i]!=f]],axis=0) for f in range(len(folds))]).astype('float32')
    R=D[['station','t','k','k_eff','fold']].drop_duplicates(['station','t','k']).reset_index(drop=True)
    spec=np.column_stack([R.station.map(si),R.t,R.k,R.k_eff,R.fold]).astype('int32')
    P=D.pivot_table(index=['station','t','k'],columns='hour',values='peer',aggfunc='first')
    fut=P.reindex(pd.MultiIndex.from_frame(R[['station','t','k']])).to_numpy().astype('float32')
    # new stations: groups = batches; peers per batch as in newsite.run_batch
    Rn=N[['station','t','k_eff','batch_onset']].drop_duplicates(['station','t']).reset_index(drop=True)
    onsets=sorted(Rn.batch_onset.unique()); gidx={o:i for i,o in enumerate(onsets)}
    pgn=[]
    for o in onsets:
        b0=int((pd.Timestamp(o)-city.days[0]).days)
        peers=[s for s in st if city.first[s]<b0-28 and np.isfinite(city.Y[s][max(0,b0-28):b0]).any()]
        pgn.append(np.nanmean(series[[si[s] for s in peers]],axis=0))
    pgn=np.vstack(pgn).astype('float32')
    specn=np.column_stack([Rn.station.map(si),Rn.t,Rn.k_eff,Rn.batch_onset.map(gidx)]).astype('int32')
    Pn=N.pivot_table(index=['station','t'],columns='hour',values='peer',aggfunc='first')
    futn=Pn.reindex(pd.MultiIndex.from_frame(Rn[['station','t']])).to_numpy().astype('float32')
    di=lambda d: int((pd.Timestamp(d)-city.days[0]).days)
    days=np.array([di(cfg['train_end']),di(cfg['val_start']),di(cfg['val_end']),di(cfg['test_start']),di(cfg['test_end'])],dtype='int32')
    dow0=int(city.days[0].dayofweek)
    np.savez_compressed(f'gpu/inputs/{name}.npz',series=series,first=first,fold_of=fold_of,peer_groups=pg,spec=spec,fut_peer=fut,
        peer_groups_new=pgn,spec_new=specn,fut_peer_new=futn,days=days,dow0=np.int32(dow0))
    print(name,series.shape,'spec',spec.shape,'new',specn.shape,'nan fut',np.isnan(fut).mean().round(4),np.isnan(futn).mean().round(4),'groups',pg.shape,pgn.shape,'days',days,'dow0',dow0)
    return R,Rn

if __name__ == "__main__":
    ctx = PL.load_context(); os.makedirs("gpu/inputs", exist_ok=True)
    keys = {}
    for name, cy, cf in [("boulder", "cityB", "cfgB"), ("paloalto", "cityP", "cfgP")]:
        D = pd.read_pickle(f"results/{name}_pseudo.pkl"); N = pd.read_pickle(f"results/{name}_new.pkl")
        info = pickle.load(open(f"results/{name}_info.pkl", "rb"))
        keys[name] = build(name, ctx[cy], ctx[cf], info, D, N)
    pd.to_pickle(keys, "gpu/row_keys.pkl")
