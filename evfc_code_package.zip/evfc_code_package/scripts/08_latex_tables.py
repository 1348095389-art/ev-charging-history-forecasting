"""Step 08: LaTeX tables paper/tables/tab_*.tex from tables/*.csv and the merged new-station results."""
import os
import sys
import time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
os.chdir(ROOT)

import pandas as pd  # noqa: E402

from evfc import latex as LX  # noqa: E402

if __name__ == "__main__":
    t0 = time.time()
    os.makedirs("paper/tables", exist_ok=True)
    PT = pd.read_csv("tables/point_metrics_pseudo.csv"); IT = pd.read_csv("tables/interval_metrics_pseudo.csv")
    T = pd.read_csv("tables/tests_pseudo.csv"); AB = pd.read_csv("tables/ablation_pseudo.csv")
    NPT = pd.read_csv("tables/point_metrics_new.csv", dtype={"dbin": str})
    NIT = pd.read_csv("tables/interval_metrics_new.csv", dtype={"dbin": str})
    rb = pd.read_csv("tables/rampup_new.csv", dtype={"dbin": str}).set_index(["city", "dbin"])
    S1 = pd.read_csv("tables/data_summary.csv")
    N = {"Boulder": pd.read_pickle("results/boulder_new.pkl"), "Palo Alto": pd.read_pickle("results/paloalto_new.pkl")}
    nst = {c: d.station.nunique() for c, d in N.items()}
    nbatch = {c: d.batch_onset.nunique() for c, d in N.items()}
    LX.write("paper/tables/tab_rmse.tex", LX.tab_point(PT, "RMSE", LX.CAP_RMSE, "tab:rmse"))
    LX.write("paper/tables/tab_dwape.tex", LX.tab_point(PT, "dWAPE", LX.CAP_DWAPE, "tab:dwape"))
    LX.write("paper/tables/tab_mae.tex", LX.tab_point(PT, "MAE", LX.CAP_MAE, "tab:mae"))
    LX.write("paper/tables/tab_tests.tex", LX.tab_tests(T))
    LX.write("paper/tables/tab_cov.tex", LX.tab_cov(IT))
    LX.write("paper/tables/tab_ablation.tex", LX.tab_ablation(AB))
    LX.write("paper/tables/tab_new.tex", LX.tab_new(NPT, NIT, rb, nst))
    LX.write("paper/tables/tab_data.tex", LX.tab_data(S1, nbatch))
    print(sorted(os.listdir("paper/tables")), "new stations", nst, "batches", nbatch)
    print(f"08_latex_tables done in {time.time() - t0:.1f} s")
