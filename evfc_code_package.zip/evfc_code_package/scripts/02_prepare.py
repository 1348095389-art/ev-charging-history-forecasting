"""Step 02: clean raw session data -> hourly station energy (data/*.pkl), station lists and configs."""
import os
import sys
import time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
os.chdir(ROOT)

from evfc import pipeline as PL  # noqa: E402

if __name__ == "__main__":
    t = time.time()
    ctx = PL.prepare_all()
    print("Boulder stations", len(ctx["cityB"].stations), "eligible", len(ctx["cfgB"]["eligible"]),
          "fleet excluded", len(ctx["fleet"]))
    print("Palo Alto stations", len(ctx["cityP"].stations), "eligible", len(ctx["cfgP"]["eligible"]))
    print("genuinely new candidates", {k: len(v) for k, v in ctx["newcand"].items()})
    print(f"02_prepare done in {time.time() - t:.1f} s")
