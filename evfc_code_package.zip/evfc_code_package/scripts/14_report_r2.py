"""Step 14 (round 2): LaTeX tables and Figure 3 of the manuscript from the round-2 result tables.
Usage: python scripts/14_report_r2.py [tables_dir] [manuscript_dir]"""
import os, sys
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__))); sys.path.insert(0, ROOT); os.chdir(ROOT)
import numpy as np, pandas as pd
from evfc import report_r2 as RR
from evfc.figstyle import COL, apply_figure_style, panel_letter
TAB = sys.argv[1] if len(sys.argv) > 1 else "tables"; MS = sys.argv[2] if len(sys.argv) > 2 else "manuscript"
TD = os.path.join(MS, "tables") + os.sep; os.makedirs(TD, exist_ok=True); os.makedirs(os.path.join(MS, "figs"), exist_ok=True)
PTc = pd.read_csv(f"{TAB}/r2_point_capped.csv"); PTu = pd.read_csv(f"{TAB}/r2_point_uncapped.csv")
ITc = pd.read_csv(f"{TAB}/r2_interval_capped.csv"); TS = pd.read_csv(f"{TAB}/r2_tests.csv")
NP = pd.read_csv(f"{TAB}/r2_new_point.csv", dtype={"dbin": str}); NI = pd.read_csv(f"{TAB}/r2_new_interval.csv", dtype={"dbin": str})
W = lambda f, s: open(TD + f, "w", encoding="utf-8").write(s)
mainM=['gbdt','lstm','chronos_qmean','ccov_qmean','tfm3_qmean','tfm3c_qmean','speer','peer','sn','zero']
W('tab_rmse.tex', RR.table_by_k(PTc,mainM,'RMSE','Hourly RMSE (kWh) by days of station history, test year. Foundation models: quantile mean. All forecasts are capped at the largest hourly energy observed in the training period (Section~\\ref{sec:metrics}); the lowest value per column is in bold.','tab:rmse',RR.PNAME,bold_min=True))
W('tab_dwape.tex', RR.table_by_k(PTc,[m for m in mainM if m!='zero'],'dWAPE','Weighted absolute percentage error of station-day energy (daily WAPE) by days of station history, test year; same methods as Table~\\ref{tab:rmse} except the zero forecast, whose daily WAPE is 1 by definition. The lowest value per column is in bold.','tab:dwape',RR.PNAME,bold_min=True))
MAEN={**RR.PNAME,'chronos_qmean':'Chronos-2 (mean)','ccov_qmean':'Chronos-2 + peer cov. (mean)','tfm3_qmean':'TimesFM 3.0 (mean)','tfm3c_qmean':'TimesFM 3.0 + peer cov. (mean)'}
W('tab_mae.tex', RR.table_by_k(PTc,['gbdt','lstm','chronos','chronos_qmean','ccov','tfm3','tfm3c','tfm3c_qmean','speer','peer','sn','zero'],'MAE','Hourly MAE (kWh) by days of station history. Foundation models are shown with their median, which suits the MAE, and, where labelled, their quantile mean; the zero forecast is included because the MAE favours it under intermittent demand.','tab:mae',MAEN))
RC={m:RR.PNAME[m] for m in ['lstm','chronos_qmean','ccov_qmean','tfm3_qmean','tfm3c_qmean','speer','peer','sn']}
W('tab_tests.tex', RR.tests_matrix(TS,list(RC),'rmse','Paired station-level comparison of the pooled GBDT with each method: ratio of mean station RMSE (below 1 favours the GBDT). Two-sided Wilcoxon signed-rank tests across stations, Holm-adjusted over all comparisons in this table; * $p<0.05$, ** $p<0.01$. Bootstrap intervals, shares and exact $p$ values are in Table~\\ref{tab:testsfull}.','tab:tests',RC))
W('tab_tests_full.tex', RR.tests_full_wide(TS,'rmse','All paired station-level RMSE comparisons of the pooled GBDT. Ratio: mean station RMSE of the GBDT divided by that of the comparator, with a 95\\% station bootstrap interval. Share: fraction of stations on which the GBDT has the lower RMSE. $p$: Holm-adjusted over all comparisons in this table.','tab:testsfull',RC))
IN={m:RR.INAME[m] for m in ['gbdt','chronos','ccov','tfm3','tfm3c','sn','peer']}
I80=ITc[ITc.level==80]
W('tab_winkler.tex', RR.table_by_k(I80,list(IN),'winkler','Interval (Winkler) score of 80\\% prediction intervals (kWh, lower is better) by days of history, test year; the lowest value per column is in bold.','tab:winkler',IN,fmt='{:.2f}',bold_min=True))
WC={m:RR.INAME[m] for m in ['chronos','ccov','tfm3','tfm3c','sn','peer']}
# the matrix of interval-score tests duplicated the full table (tab_winkler_tests_full) and was dropped
W('tab_cov.tex', RR.table_by_k(I80,list(IN),'cov','Empirical coverage of 80\\% prediction intervals by days of history, test year (nominal 0.80).','tab:cov',IN))
W('tab_cov_nonzero.tex', RR.table_by_k(I80,list(IN),'cov_nonzero','Coverage of 80\\% prediction intervals on hours with non-zero energy, by days of history.','tab:covnz',IN))
W('tab_cov_full.tex', RR.table_by_k(I80,list(IN),'width','Mean width (kWh) of 80\\% prediction intervals by days of history.','tab:covfull',IN,fmt='{:.2f}'))
W('tab_within5.tex', RR.table_by_k(I80,list(IN),'st_within5','Share of stations whose own 80\\% coverage lies within 5 percentage points of nominal, by days of history.','tab:within5',IN,fmt='{:.2f}'))
W('tab_new.tex', RR.new_table(NP,NI,['gbdt','chronos_qmean','tfm3c_qmean'],'Genuinely new stations over their first 56 days in service (8 stations in Boulder, 25 in Palo Alto), by days in service at the origin. GBDT: pooled GBDT with conformal intervals; Chr.: Chronos-2; TFM+c: TimesFM 3.0 with peer covariates (both quantile mean, native intervals).','tab:new'))
U=PTu[PTu.model.isin(['chronos_qmean','ccov_qmean','tfm3_qmean','tfm3c_qmean'])].merge(PTc[['city','k','model','RMSE']],on=['city','k','model'],suffixes=('_u','_c'))
U2=pd.concat([U.assign(model=U.model+'_u',RMSE=U.RMSE_u),U.assign(model=U.model+'_c',RMSE=U.RMSE_c)])
UN={**{m+'_u':RR.PNAME[m]+', uncapped' for m in ['chronos_qmean','ccov_qmean','tfm3_qmean','tfm3c_qmean']},**{m+'_c':RR.PNAME[m]+', capped' for m in ['chronos_qmean','ccov_qmean','tfm3_qmean','tfm3c_qmean']}}
order_u=[m+s for m in ['chronos_qmean','ccov_qmean','tfm3_qmean','tfm3c_qmean'] for s in ['_u','_c']]
W('tab_uncapped.tex', RR.table_by_k(U2,order_u,'RMSE','Hourly RMSE (kWh) of the foundation-model quantile means without and with the cap at the largest hourly energy of the training period.','tab:uncapped',UN,fmt='{:.3f}'))
RR.fig_history(PTc,os.path.join(MS,'figs','fig3_history'),COL,apply_figure_style,panel_letter)
print('tables and Figure 3 written to', MS)
