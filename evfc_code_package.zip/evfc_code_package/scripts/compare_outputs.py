"""Compare regenerated outputs with a reference copy.

Usage (from the package root):  python scripts/compare_outputs.py <reference_dir> [out.json]
<reference_dir> must contain tables/*.csv and paper/tables/*.tex from a previous run.
For each CSV: same shape, same non-numeric columns, and the maximum absolute difference of numeric columns.
For each .tex: exact equality after normalising line endings, plus a unified diff when they differ.
"""
import difflib
import glob
import json
import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
os.chdir(ROOT)

import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402


def compare_csv(a, b):
    A, B = pd.read_csv(a), pd.read_csv(b)
    r = {"shape_new": list(A.shape), "shape_ref": list(B.shape), "columns_equal": list(A.columns) == list(B.columns)}
    if A.shape != B.shape or not r["columns_equal"]:
        r["max_abs_diff"] = None; return r
    num = [c for c in A.columns if pd.api.types.is_numeric_dtype(A[c]) and pd.api.types.is_numeric_dtype(B[c])]
    oth = [c for c in A.columns if c not in num]
    r["non_numeric_equal"] = bool(all((A[c].astype(str) == B[c].astype(str)).all() for c in oth))
    mx = 0.0; nan_mismatch = 0
    for c in num:
        x, y = A[c].to_numpy(float), B[c].to_numpy(float)
        nan_mismatch += int((np.isnan(x) != np.isnan(y)).sum())
        m = ~(np.isnan(x) | np.isnan(y))
        if m.any():
            mx = max(mx, float(np.max(np.abs(x[m] - y[m]))))
    r["max_abs_diff"] = mx; r["nan_mismatch"] = nan_mismatch
    r["bytes_identical"] = open(a, "rb").read() == open(b, "rb").read()
    return r


def compare_tex(a, b):
    x = open(a, encoding="utf-8").read().replace("\r\n", "\n"); y = open(b, encoding="utf-8").read().replace("\r\n", "\n")
    r = {"identical": x == y, "bytes_identical": open(a, "rb").read() == open(b, "rb").read()}
    if x != y:
        r["diff"] = "".join(difflib.unified_diff(y.splitlines(True), x.splitlines(True), "reference", "regenerated"))
    return r


if __name__ == "__main__":
    ref = sys.argv[1]
    res = {"csv": {}, "tex": {}}
    for f in sorted(glob.glob(os.path.join(ref, "tables", "*.csv"))):
        n = os.path.join("tables", os.path.basename(f))
        res["csv"][os.path.basename(f)] = compare_csv(n, f) if os.path.exists(n) else {"missing": True}
    for f in sorted(glob.glob(os.path.join(ref, "paper", "tables", "*.tex"))):
        n = os.path.join("paper", "tables", os.path.basename(f))
        res["tex"][os.path.basename(f)] = compare_tex(n, f) if os.path.exists(n) else {"missing": True}
    for k, v in res["csv"].items():
        print(f"{k:34s} max_abs_diff={v.get('max_abs_diff')} nan_mismatch={v.get('nan_mismatch')} "
              f"non_numeric_equal={v.get('non_numeric_equal')} bytes_identical={v.get('bytes_identical')}")
    for k, v in res["tex"].items():
        print(f"{k:34s} identical={v.get('identical')} bytes_identical={v.get('bytes_identical')}")
        if v.get("diff"):
            print(v["diff"])
    if len(sys.argv) > 2:
        json.dump(res, open(sys.argv[2], "w"), indent=1)
