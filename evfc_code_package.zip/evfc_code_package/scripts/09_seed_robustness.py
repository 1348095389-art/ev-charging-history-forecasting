"""Step 09 (optional): robustness of the pooled GBDT to the random fold assignment.  Re-runs the cross-fitted
experiment with seeds 1 and 2 (no ablations), combines them with the main run (seed 0, from tables/*.csv) and
writes tables/seed_robustness.csv and paper/tables/tab_seed.tex.  Run after step 06."""
import os
import sys
import time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
os.chdir(ROOT)

import argparse  # noqa: E402

import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402

from evfc import _compat  # noqa: E402
from evfc import pipeline as PL  # noqa: E402
from evfc import run as RN  # noqa: E402

KL = {0: "0", 1: "1", 3: "3", 7: "7", 14: "14", 28: "28", -1: "full"}; KO = [0, 1, 3, 7, 14, 28, -1]

if __name__ == "__main__":
    ap = argparse.ArgumentParser(); ap.add_argument("--n-jobs", type=int, default=8); a = ap.parse_args()
    _compat.ensure_thread_pool()
    t0 = time.time(); ctx = PL.load_context(); rows = []; times = {}
    for seed in (1, 2):
        for city, cfg in ((ctx["cityB"], ctx["cfgB"]), (ctx["cityP"], ctx["cfgP"])):
            t = time.time()
            D, info = RN.run_city(city, cfg, seed=seed, n_jobs=a.n_jobs, ablations=False, log=lambda *x: None)
            for k, g in D.dropna(subset=["y"]).groupby("k"):
                rows.append(dict(seed=seed, city=city.name, k=k, rmse=np.sqrt(np.mean((g.y - g.gbdt) ** 2)),
                                 rmse_peer=np.sqrt(np.mean((g.y - g.peer) ** 2)),
                                 cov80=np.mean((g.y >= g.gbdt_lo80) & (g.y <= g.gbdt_hi80)),
                                 cfg=str(sorted(set(str(v) for v in info["chosen"].values())))))
            times[f"seed{seed}_{city.name}"] = round(time.time() - t, 1); print(seed, city.name, times[f"seed{seed}_{city.name}"], "s", flush=True)
    SEEDS = pd.DataFrame(rows)
    PT = pd.read_csv("tables/point_metrics_pseudo.csv"); IT = pd.read_csv("tables/interval_metrics_pseudo.csv")
    S0 = PT[PT.model == "gbdt"][["city", "k", "RMSE"]].rename(columns={"RMSE": "rmse"}).assign(seed=0, city=lambda d: d.city.str.replace(" ", ""))
    cov0 = IT[IT.model == "gbdt"][["city", "k", "cov80"]].assign(seed=0, city=lambda d: d.city.str.replace(" ", ""))
    ALL = pd.concat([S0.merge(cov0, on=["city", "k", "seed"]), SEEDS[["city", "k", "seed", "rmse", "cov80"]]])
    ALL.to_csv("tables/seed_robustness.csv", index=False)
    L = [r"\begin{table}[H]",
         r"\caption{Robustness of the pooled GBDT to the random assignment of test stations to folds (seed 0 is the main "
         r"run). Hourly RMSE (kWh) by days of history and range of marginal 80\% conformal coverage over 1 to 28 days of "
         r"history.\label{tab:seed}}", r"\small", r"\begin{tabularx}{\textwidth}{llCCCCCCCc}", r"\toprule",
         r"\textbf{City} & \textbf{Seed} & " + " & ".join(r"\textbf{%s}" % KL[k] for k in KO) + r" & \textbf{Cov. 80\%}\\", r"\midrule"]
    for c, cn in [("Boulder", "Boulder"), ("PaloAlto", "Palo Alto")]:
        for s in (0, 1, 2):
            g = ALL[(ALL.city == c) & (ALL.seed == s)].set_index("k"); cv = g.loc[[1, 3, 7, 14, 28], "cov80"]
            L.append((cn if s == 0 else "") + f" & {s} & " + " & ".join(f"{g.rmse[k]:.3f}" for k in KO) + f" & {cv.min():.3f}--{cv.max():.3f}\\\\")
        if c == "Boulder":
            L.append(r"\midrule")
    L += [r"\bottomrule", r"\end{tabularx}", r"\end{table}"]
    os.makedirs("paper/tables", exist_ok=True)
    open("paper/tables/tab_seed.tex", "w", encoding="utf-8").write("\n".join(L))
    W = ALL.pivot_table(index=["city", "k"], columns="seed", values="rmse")
    print("max relative RMSE spread across seeds (%)", (100 * (W.max(1) / W.min(1) - 1)).round(2).to_dict())
    print("timings_s", times, f"total {time.time() - t0:.1f} s")
