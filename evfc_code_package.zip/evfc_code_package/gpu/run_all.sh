#!/usr/bin/env bash
# One-shot GPU job for the WEVJ revision. Safe to rerun: finished outputs are skipped.
set -u
cd "$(dirname "$0")"
OUT="${OUT:-/workspace/wevj_out}"; mkdir -p "$OUT/logs"
P="$OUT/logs/progress.txt"; echo "start $(date -u)" >> "$P"
# 1) environment
if [ ! -f "$OUT/logs/env_ok" ]; then
  pip install -q "chronos-forecasting==2.3.2" "timesfm==3.0.2" > "$OUT/logs/pip.txt" 2>&1 || { echo "PIP FAILED" | tee -a "$P"; exit 1; }
  python - <<'EOF' > "$OUT/logs/env.txt" 2>&1 || { echo "ENV CHECK FAILED (see logs/env.txt)" | tee -a "$P"; exit 1; }
import torch, importlib.metadata as md
assert torch.cuda.is_available(), "no CUDA GPU"
print(torch.__version__, torch.version.cuda, torch.cuda.get_device_name(0))
print({p: md.version(p) for p in ["chronos-forecasting", "timesfm", "transformers", "numpy"]})
EOF
  touch "$OUT/logs/env_ok"
fi
cat "$OUT/logs/env.txt" >> "$P"
# 2) GPU self-check on a few rows of every job type (fails fast, before the long runs)
if [ ! -f "$OUT/logs/smoke_ok" ]; then
  mkdir -p "$OUT/smoke"
  for m in chronos_cov timesfm3 timesfm3_cov; do
    python gpu_fm.py $m inputs/boulder.npz pseudo "$OUT/smoke/$m.npz" 50 > "$OUT/smoke/$m.log" 2>&1 \
      || { echo "SMOKE FAILED $m (see smoke/$m.log)" | tee -a "$P"; exit 1; }
  done
  SMOKE=1 python gpu_lstm.py inputs/boulder.npz "$OUT/smoke/lstm.npz" > "$OUT/smoke/lstm.log" 2>&1 \
      || { echo "SMOKE FAILED lstm (see smoke/lstm.log)" | tee -a "$P"; exit 1; }
  touch "$OUT/logs/smoke_ok"; echo "smoke ok $(date -u)" >> "$P"
fi
# 3) full runs
run() {  # name, script args...
  local name=$1; shift
  if [ -f "$OUT/$name.npz" ]; then echo "skip $name (done)" >> "$P"; return 0; fi
  local t0=$(date +%s)
  if python "$@" "$OUT/$name.tmp.npz" > "$OUT/logs/$name.log" 2>&1; then
    mv "$OUT/$name.tmp.npz" "$OUT/$name.npz"; echo "done $name $(( $(date +%s) - t0 ))s $(date -u)" >> "$P"
  else
    echo "FAILED $name (see logs/$name.log)" | tee -a "$P" >> "$OUT/FAILED.txt"
  fi
}
for c in boulder paloalto; do
  for k in pseudo new; do
    run chronos_cov_${c}_${k}  gpu_fm.py chronos_cov  inputs/$c.npz $k
    run timesfm3_${c}_${k}     gpu_fm.py timesfm3     inputs/$c.npz $k
    run timesfm3_cov_${c}_${k} gpu_fm.py timesfm3_cov inputs/$c.npz $k
  done
done
for c in boulder paloalto; do
  if [ ! -f "$OUT/lstm_$c.npz" ]; then
    t0=$(date +%s)
    if python gpu_lstm.py inputs/$c.npz "$OUT/lstm_$c.tmp.npz" > "$OUT/logs/lstm_$c.log" 2>&1; then
      mv "$OUT/lstm_$c.tmp.npz" "$OUT/lstm_$c.npz"; echo "done lstm_$c $(( $(date +%s) - t0 ))s $(date -u)" >> "$P"
    else echo "FAILED lstm_$c (see logs/lstm_$c.log)" | tee -a "$P" >> "$OUT/FAILED.txt"; fi
  else echo "skip lstm_$c (done)" >> "$P"; fi
done
# 4) package
cd "$OUT" && tar czf /workspace/wevj_out.tar.gz --exclude='*.tmp.npz' . && sha256sum /workspace/wevj_out.tar.gz > /workspace/wevj_out.sha256
n=$(ls "$OUT"/*.npz 2>/dev/null | wc -l)
{ echo "finished $(date -u)"; echo "outputs: $n of 14"; [ -f "$OUT/FAILED.txt" ] && cat "$OUT/FAILED.txt"; } > /workspace/ALL_DONE.txt
cat /workspace/ALL_DONE.txt >> "$P"
