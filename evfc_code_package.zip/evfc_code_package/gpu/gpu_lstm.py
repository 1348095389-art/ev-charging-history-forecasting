"""Global LSTM trained across stations with randomly truncated histories (same protocol as the pooled GBDT).

For each city and outer fold f: train on the stations outside fold f (training period origins, random history
level per sample), choose the number of epochs on the validation period of the same training stations, retrain
from scratch on all origins up to the end of the validation period for that many epochs, then forecast the test
year for the stations of fold f at every history level in the spec. No test-station data, and no data from on
or after the forecast origin, enters any input.

Inputs per hour of a 672-h window: own energy / scale (0 where outside the k-day history or missing), own-availability
mask, peer mean / peer level, sin/cos hour of day, sin/cos day of week. Static: log1p(k days), log scale, log peer
level. Decoder: last hidden state + 24-h peer profile / peer level + 24-h calendar. Output: 24 values x scale.
Usage: python gpu_lstm.py inputs/boulder.npz out/lstm_boulder.npz   (env SMOKE=1 for a tiny CPU test)
"""
import os
import sys
import time
import numpy as np
import torch
import torch.nn as nn

L = 672
LEVELS = [0, 1, 3, 7, 14, 28, -1]
SMOKE = os.environ.get("SMOKE") == "1"
SEEDS = [0] if SMOKE else [0, 1, 2]
MAX_EP = 1 if SMOKE else 30
PATIENCE = 5
BS = 512
DEV = "cuda" if (torch.cuda.is_available() and os.environ.get("FORCE_CPU") != "1") else "cpu"


class Net(nn.Module):
    def __init__(self, h=64):
        super().__init__()
        self.lstm = nn.LSTM(7, h, num_layers=2, batch_first=True, dropout=0.1)
        self.head = nn.Sequential(nn.Linear(h + 24 + 96 + 3, 128), nn.ReLU(), nn.Linear(128, 24))

    def forward(self, x, fut, stat):
        _, (hn, _) = self.lstm(x)
        z = torch.cat([hn[-1], fut, stat], dim=1)
        return nn.functional.softplus(self.head(z))


class City:
    def __init__(self, d):
        self.Y = torch.tensor(d["series"], device=DEV)                     # (n, H) NaN = missing
        self.first = d["first"].astype(np.int64)
        self.fold_of = d["fold_of"]
        self.pg = torch.tensor(np.nan_to_num(d["peer_groups"], nan=0.0), device=DEV)  # (F, H)
        self.days = d["days"]; self.dow0 = int(d["dow0"])
        n, H = self.Y.shape; self.H = H
        v = torch.nan_to_num(self.Y, nan=0.0); c = (~torch.isnan(self.Y)).float()
        z = torch.zeros(n, 1, device=DEV)
        self.cs = torch.cat([z, v.cumsum(1)], 1); self.cc = torch.cat([z, c.cumsum(1)], 1)
        hh = torch.arange(H + 48, device=DEV)
        hod = (hh % 24).float() * 2 * np.pi / 24; dow = ((self.dow0 + hh // 24) % 7).float() * 2 * np.pi / 7
        self.cal = torch.stack([hod.sin(), hod.cos(), dow.sin(), dow.cos()], 1)  # (H+48, 4)

    def batch(self, s, t, ke, g):
        """s,t,ke,g: LongTensors (B,). Returns model inputs and normalised target."""
        B = len(s); end = t * 24
        idx = end[:, None] - L + torch.arange(L, device=DEV)[None, :]          # (B, L)
        valid_idx = idx >= 0; idc = idx.clamp(min=0)
        own = self.Y[s[:, None], idc]
        hist_start = torch.maximum((t - ke) * 24, torch.as_tensor(self.first, device=DEV)[s] * 24)
        avail = valid_idx & (idx >= hist_start[:, None]) & ~torch.isnan(own)
        # scale over the whole available k-day history (not only the window)
        a = hist_start.clamp(max=end); ssum = self.cs[s, end] - self.cs[s, a]; scnt = self.cc[s, end] - self.cc[s, a]
        peer = self.pg[g[:, None], idc] * valid_idx
        plev = (peer.sum(1) / valid_idx.sum(1).clamp(min=1)).clamp(min=0.05)
        scale = torch.where(scnt > 0, ssum / scnt.clamp(min=1), plev).clamp(min=0.05)
        ownn = torch.where(avail, own / scale[:, None], torch.zeros_like(own))
        cal = self.cal[idc]
        x = torch.cat([ownn[..., None], avail.float()[..., None], (peer / plev[:, None])[..., None], cal], 2)
        # future peer profile: hour-of-week mean of the peer series over the previous 4 weeks
        fidx = end[:, None] + torch.arange(24, device=DEV)[None, :]
        fp = torch.stack([self.pg[g[:, None], (fidx - 168 * w).clamp(min=0)] for w in range(1, 5)], 0).mean(0)
        fut = torch.cat([fp / plev[:, None], self.cal[fidx].reshape(B, 96)], 1)
        stat = torch.stack([torch.log1p(ke.float()), scale.log(), plev.log()], 1)
        yt = self.Y[s[:, None], fidx.clamp(max=self.H - 1)]
        return x, fut, stat, scale, yt


def samples(city, stations, t_lo, t_hi, stride, rng):
    out = []
    for si in stations:
        f = city.first[si]
        for t in range(max(t_lo, f, 28), t_hi + 1, stride):
            k = LEVELS[rng.integers(len(LEVELS))]
            ke = (t - f) if k == -1 else min(k, t - f)
            out.append((si, t, ke))
    a = np.array(out, dtype=np.int64)
    # drop targets that are entirely missing
    Y = city.Y.cpu().numpy()
    keep = np.array([np.isfinite(Y[s, t * 24:t * 24 + 24]).any() for s, t, _ in a])
    return a[keep]


def run_epoch(city, net, opt, S, g, train):
    net.train(train); tot = 0.0; cnt = 0.0
    perm = np.random.permutation(len(S)) if train else np.arange(len(S))
    for b in range(0, len(S), BS):
        ii = perm[b:b + BS]
        s, t, ke = (torch.as_tensor(S[ii, j], device=DEV) for j in range(3))
        gg = torch.full_like(s, g)
        x, fut, stat, scale, yt = city.batch(s, t, ke, gg)
        m = ~torch.isnan(yt); ytn = torch.nan_to_num(yt / scale[:, None])
        with torch.set_grad_enabled(train):
            p = net(x, fut, stat)
            loss = (((p - ytn) ** 2) * m).sum() / m.sum().clamp(min=1)
            if train:
                opt.zero_grad(); loss.backward(); nn.utils.clip_grad_norm_(net.parameters(), 1.0); opt.step()
        e = (((p * scale[:, None] - torch.nan_to_num(yt)) ** 2) * m).sum().item()
        tot += e; cnt += m.sum().item()
    return np.sqrt(tot / max(cnt, 1))


def fit(city, S, g, epochs, seed, Sval=None):
    torch.manual_seed(seed); np.random.seed(seed)
    net = Net().to(DEV); opt = torch.optim.Adam(net.parameters(), lr=1e-3)
    best, best_ep, hist = np.inf, 0, []
    for ep in range(1, epochs + 1):
        run_epoch(city, net, opt, S, g, True)
        if Sval is not None:
            v = run_epoch(city, net, opt, Sval, g, False); hist.append(v)
            if v < best - 1e-4: best, best_ep = v, ep
            elif ep - best_ep >= PATIENCE: break
    return net, best_ep, hist


def predict(city, net, spec, g):
    net.eval(); out = np.zeros((len(spec), 24), dtype=np.float32)
    with torch.no_grad():
        for b in range(0, len(spec), 2048):
            sp = spec[b:b + 2048]
            s, t, ke = (torch.as_tensor(sp[:, j], device=DEV) for j in (0, 1, 3))
            x, fut, stat, scale, _ = city.batch(s, t, ke, torch.full_like(s, g))
            out[b:b + 2048] = (net(x, fut, stat) * scale[:, None]).cpu().numpy()
    return out


def main(inp, outp):
    d = np.load(inp); city = City(d); spec = d["spec"].astype(np.int64)
    tr_end, v0, v1 = (int(x) for x in d["days"][:3])
    F = int(d["peer_groups"].shape[0]); n_st = len(city.first)
    pred = np.full((len(SEEDS), len(spec), 24), np.nan, dtype=np.float32); log = []
    folds = [0] if SMOKE else range(F)
    t0 = time.time()
    for si_, seed in enumerate(SEEDS):
        for f in folds:
            rng = np.random.default_rng(1000 * seed + f)
            tr_st = [i for i in range(n_st) if city.fold_of[i] != f]
            S1 = samples(city, tr_st, 28, tr_end, 2, rng)
            Sv = samples(city, tr_st, v0, v1, 1, rng)
            if SMOKE:
                S1, Sv = S1[:2000], Sv[:500]
            _, best_ep, hist = fit(city, S1, f, MAX_EP, seed, Sv)
            best_ep = max(best_ep, 1)
            S2 = samples(city, tr_st, 28, v1, 2, rng)
            if SMOKE:
                S2 = S2[:2000]
            net, _, _ = fit(city, S2, f, best_ep, seed)
            rows = np.flatnonzero(spec[:, 4] == f)
            if SMOKE:
                rows = rows[:500]
            pred[si_, rows] = predict(city, net, spec[rows], f)
            log.append(dict(seed=seed, fold=f, n_train=len(S1), n_val=len(Sv), best_epoch=best_ep,
                            val_rmse=[round(float(h), 4) for h in hist], sec=round(time.time() - t0, 1)))
            print(log[-1], flush=True)
    np.savez_compressed(outp, pred=pred, seeds=np.array(SEEDS), log=np.array(repr(log)))
    print("done", inp, round(time.time() - t0, 1), "s", flush=True)


if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2])
