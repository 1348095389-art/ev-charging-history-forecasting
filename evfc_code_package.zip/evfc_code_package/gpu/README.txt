WEVJ revision GPU job (one pod, one run)

Contents: gpu_fm.py (Chronos-2 with peer covariates; TimesFM 3.0 univariate and with peer covariates),
gpu_lstm.py (global LSTM, 5 station folds x 3 seeds per city), inputs/boulder.npz, inputs/paloalto.npz, run_all.sh.
Run:   cd /workspace/wevj_gpu && nohup bash run_all.sh > /workspace/run_all.out 2>&1 &
Watch: cat /workspace/wevj_out/logs/progress.txt
Done when /workspace/ALL_DONE.txt exists ("outputs: 14 of 14"). Result: /workspace/wevj_out.tar.gz (+ .sha256).
Rerunning run_all.sh resumes and skips finished outputs.
