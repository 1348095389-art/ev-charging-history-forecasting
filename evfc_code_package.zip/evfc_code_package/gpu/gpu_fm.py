"""Zero-shot foundation-model forecasts for the limited-history contexts.

mode 'chronos_cov': Chronos-2 (amazon/chronos-2) with peer covariates. The input window is the 2048 h before the
    origin. The target keeps only the station's own values inside its k-day history (NaN elsewhere, so k = 0 is
    possible). Past covariate 'peer' = mean hourly energy of the training-fold peer stations (pseudo-new) or of the
    stations in service before the batch onset (genuinely new) over the same window; future covariate 'peer' = the
    24-h peer profile used by the peer baseline. Everything is known at the forecast origin.
mode 'timesfm3' / 'timesfm3_cov': TimesFM 3.0 (google/timesfm-3.0-pytorch) on exactly the same own-history contexts
    as the univariate Chronos-2 run (last min(k*24, 2048) h); the _cov variant adds the peer mean over the same window
    and the 24-h peer profile as a past-and-future covariate. Contexts with no observed value are skipped (NaN).
Usage: python gpu_fm.py {chronos_cov|timesfm3|timesfm3_cov} inputs/boulder.npz {pseudo|new} out/file.npz [n_rows_for_smoke_test]
Output npz: q (n, 24, nq) quantiles, mean (n, 24), ql (levels; for TimesFM 'mean' is its point forecast).
"""
import os
import sys
import time
import numpy as np
import torch

CTX = 2048
QL = [0.05, 0.1, 0.25, 0.5, 0.75, 0.9, 0.95]
DEV = "cuda" if (torch.cuda.is_available() and os.environ.get("FORCE_CPU") != "1") else "cpu"


def load(inp, kind):
    d = np.load(inp)
    if kind == "pseudo":
        sp = d["spec"]; si, t, ke, g = sp[:, 0], sp[:, 1], sp[:, 3], sp[:, 4]
        pg, fut = d["peer_groups"], d["fut_peer"]
    else:
        sp = d["spec_new"]; si, t, ke, g = sp[:, 0], sp[:, 1], sp[:, 2], sp[:, 3]
        pg, fut = d["peer_groups_new"], d["fut_peer_new"]
    return d["series"], pg, fut, si.astype(int), t.astype(int), ke.astype(int), g.astype(int)


def run_chronos_cov(series, pg, fut, si, t, ke, g, rows, bs=256):
    from chronos import BaseChronosPipeline
    pipe = BaseChronosPipeline.from_pretrained("amazon/chronos-2", device_map=DEV)
    n = len(si); Q = np.full((n, 24, len(QL)), np.nan, np.float32); M = np.full((n, 24), np.nan, np.float32)
    pgz = np.nan_to_num(pg, nan=0.0).astype(np.float32)

    def item(i):
        end = t[i] * 24; a = max(0, end - CTX)
        y = series[si[i], a:end].astype(np.float32).copy()
        cut = (t[i] - ke[i]) * 24
        if cut > a:
            y[:max(0, cut - a)] = np.nan
        return {"target": y, "past_covariates": {"peer": pgz[g[i], a:end]},
                "future_covariates": {"peer": fut[i].astype(np.float32)}}

    def put(ids, q, m):
        q = torch.stack([x.squeeze(0) for x in q]) if isinstance(q, list) else q
        m = torch.stack([x.squeeze(0) for x in m]) if isinstance(m, list) else m
        Q[ids] = np.clip(q.float().cpu().numpy().reshape(len(ids), 24, len(QL)), 0, None)
        M[ids] = np.clip(m.float().cpu().numpy().reshape(len(ids), 24), 0, None)

    t0 = time.time(); fails = 0
    for b in range(0, len(rows), bs):
        ids = rows[b:b + bs]
        try:
            q, m = pipe.predict_quantiles([item(i) for i in ids], prediction_length=24, quantile_levels=QL)
            put(ids, q, m)
        except Exception as e:  # retry one by one so a single bad context does not drop a batch
            print("batch failed, retrying singly:", str(e)[:160], flush=True)
            for i in ids:
                try:
                    q, m = pipe.predict_quantiles([item(i)], prediction_length=24, quantile_levels=QL); put([i], q, m)
                except Exception:
                    fails += 1
        if (b // bs) % 40 == 0:
            print(f"{b}/{len(rows)} {time.time() - t0:.1f}s fails={fails}", flush=True)
    return Q, M, np.array(QL), fails


def run_timesfm3(series, pg, fut, si, t, ke, g, rows, cov, chunk=1024):
    """TimesFM 3.0 (google/timesfm-3.0-pytorch). Context = the station's own last min(k*24, 2048) h (k = 0 skipped).
    cov=True adds the peer mean over the same window plus the 24-h peer profile as a past-and-future covariate."""
    from timesfm import TimesFM3Forecaster
    fc = TimesFM3Forecaster.from_pretrained("google/timesfm-3.0-pytorch", device=DEV)
    n = len(si); Q = np.full((n, 24, 9), np.nan, np.float32); M = np.full((n, 24), np.nan, np.float32)
    pgz = np.nan_to_num(pg, nan=0.0).astype(np.float32)
    ok = []
    for i in rows:
        if ke[i] <= 0:
            continue
        a = max((t[i] - ke[i]) * 24, t[i] * 24 - CTX)
        if np.isfinite(series[si[i], a:t[i] * 24]).any():
            ok.append(i)
    t0 = time.time()
    for b in range(0, len(ok), chunk):
        ids = ok[b:b + chunk]; ctxs, covs = [], []
        for i in ids:
            a = max((t[i] - ke[i]) * 24, t[i] * 24 - CTX); e = t[i] * 24
            ctxs.append(series[si[i], a:e].astype(np.float32))
            if cov:
                covs.append(np.concatenate([pgz[g[i], a:e], fut[i].astype(np.float32)])[None, :])
        outs = list(fc.predict_batch(ctxs, horizon=24, past_future_covariates=covs if cov else None,
                                     return_quantiles=True, make_positive=True))
        for i, o in zip(ids, outs):
            f = np.asarray(o.forecast, dtype=np.float32).reshape(-1)[-24:]
            q = np.asarray(o.quantiles, dtype=np.float32)
            q = q.reshape(-1, q.shape[-2], q.shape[-1])[0] if q.ndim > 2 else q
            q = q[:24, :9] if q.shape[-1] >= 9 else q.T[:24, :9]
            M[i] = np.clip(f, 0, None); Q[i] = np.clip(q, 0, None)
        if b == 0:
            print("timesfm3 output shapes forecast", np.asarray(outs[0].forecast).shape, "quantiles",
                  np.asarray(outs[0].quantiles).shape, flush=True)
        print(f"{b}/{len(ok)} {time.time() - t0:.1f}s", flush=True)
    return Q, M, np.round(np.arange(0.1, 0.91, 0.1), 2), len(rows) - len(ok)


if __name__ == "__main__":
    mode, inp, kind, outp = sys.argv[1:5]
    series, pg, fut, si, t, ke, g = load(inp, kind)
    rows = np.arange(len(si))
    if len(sys.argv) > 5:  # smoke test on a spread of rows
        rows = np.unique(np.linspace(0, len(si) - 1, int(sys.argv[5])).astype(int))
    t0 = time.time()
    if mode == "chronos_cov":
        Q, M, ql, fails = run_chronos_cov(series, pg, fut, si, t, ke, g, rows)
    elif mode in ("timesfm3", "timesfm3_cov"):
        Q, M, ql, fails = run_timesfm3(series, pg, fut, si, t, ke, g, rows, cov=(mode == "timesfm3_cov"))
    else:
        raise SystemExit("unknown mode " + mode)
    np.savez_compressed(outp, q=Q, mean=M, ql=ql, rows=rows)
    print("done", mode, inp, kind, "rows", len(rows), "skipped/failed", fails, f"{time.time() - t0:.1f}s", "device", DEV,
          "finite mean share", float(np.isfinite(M[rows]).all(1).mean()), flush=True)
