"""Per-city leakage-safe experiment: station-disjoint 5-fold cross-fitting, temporal train/val/test."""
import itertools
import numpy as np
import pandas as pd
from concurrent.futures import ThreadPoolExecutor
from . import exp as E

GRID = [dict(loss=l, leaves=n, lr=0.05, iters=400) for l, n in itertools.product(["squared_error", "poisson"], [15, 31])]


def _pmap(fn, calls, n_jobs=1):
    """Ordered map of fn(*args, **kw) over calls = [(args, kw), ...].  n_jobs > 1 uses threads
    (HistGradientBoosting releases the GIL); results are identical to the sequential loop."""
    if n_jobs <= 1:
        return [fn(*a, **kw) for a, kw in calls]
    with ThreadPoolExecutor(max_workers=n_jobs) as ex:
        return list(ex.map(lambda c: fn(*c[0], **c[1]), calls))


def day_index(city, date):
    return int((pd.Timestamp(date) - city.days[0]).days)


def _fit_predict(city, train_st, pred_st, tr_orig, pr_orig, cfg, seed, ks_pred, normalize=True, drop_k=False, drop=()):
    rng = np.random.default_rng(seed)
    peers = E.PeerCache(city, train_st)
    Xtr, ytr, dtr = E.make_matrix(city, train_st, tr_orig, E.K_LEVELS, peers, rng=rng, normalize=normalize, sample_k=True)
    model = E.fit_gbdt(Xtr, ytr, dtr.scale.to_numpy(), cfg, normalize=normalize, drop_k=drop_k, seed=seed, drop=drop)
    Xp, yp, dp = E.make_matrix(city, pred_st, pr_orig, ks_pred, peers, normalize=normalize)
    dp["y"] = yp
    dp["gbdt"] = E.predict_gbdt(model, Xp, dp.scale.to_numpy(), normalize=normalize, drop_k=drop_k, drop=drop)
    return dp


def run_city(city, cfg, n_folds=5, seed=0, n_jobs=1, train_stride=2, ablations=True, log=print):
    """cfg: dict with train_end, val_start, val_end, test_start, test_end (dates), eligible (list), pool (list)."""
    tr_end, v0, v1 = day_index(city, cfg["train_end"]), day_index(city, cfg["val_start"]), day_index(city, cfg["val_end"])
    t0, t1 = day_index(city, cfg["test_start"]), day_index(city, cfg["test_end"])
    eligible = list(cfg["eligible"]); pool = list(cfg["pool"])
    rng = np.random.default_rng(seed)
    perm = rng.permutation(len(eligible))
    folds = [[eligible[i] for i in perm[f::n_folds]] for f in range(n_folds)]
    others = [s for s in pool if s not in eligible]        # training-only stations (e.g. decommissioned)
    tr_orig_inner = list(range(28, tr_end + 1, train_stride))
    tr_orig_outer = list(range(28, v1 + 1, train_stride))
    val_orig = list(range(v0, v1 + 1)); test_orig = list(range(t0, t1 + 1))

    # ---- inner fits: for each outer fold f and inner fold g != f, every config
    jobs = []
    for f in range(n_folds):
        for g in range(n_folds):
            if g == f:
                continue
            train_st = [s for h in range(n_folds) if h not in (f, g) for s in folds[h]] + others
            for ci, c in enumerate(GRID):
                jobs.append((f, g, ci, train_st, folds[g], c))
    log(f"[{city.name}] inner fits: {len(jobs)}")
    res = _pmap(_fit_predict, [((city, tst, pst, tr_orig_inner, val_orig, c, seed, E.K_LEVELS), {})
                               for (_, _, _, tst, pst, c) in jobs], n_jobs)
    inner = {}
    for (f, g, ci, tst, *_), dp in zip(jobs, res):
        dp = dp.copy(); dp["g"] = g
        dp["sn"], dp["peer"] = E.baseline_preds(city, dp, E.PeerCache(city, tst))
        inner.setdefault((f, ci), []).append(dp)
    chosen, cal = {}, {}
    for f in range(n_folds):
        scores = []
        for ci in range(len(GRID)):
            d = pd.concat(inner[(f, ci)], ignore_index=True)
            scores.append(E.rmse(d.y.to_numpy(), d.gbdt.to_numpy()))
        ci = int(np.nanargmin(scores)); chosen[f] = ci
        cal[f] = pd.concat(inner[(f, ci)], ignore_index=True)
        log(f"[{city.name}] fold {f}: val RMSE by cfg {np.round(scores, 4)} -> {GRID[ci]}")

    # ---- outer fits (main model + ablations)
    variants = [("gbdt", dict())]
    if ablations:
        variants += [("gbdt_nok", dict(drop_k=True)), ("gbdt_nonorm", dict(normalize=False)), ("gbdt_nopeer", dict(drop=("peer_shape", "peer_ratio")))]
    ojobs = []
    for f in range(n_folds):
        train_st = [s for h in range(n_folds) if h != f for s in folds[h]] + others
        for name, kw in variants:
            ojobs.append((f, name, train_st, kw))
    log(f"[{city.name}] outer fits: {len(ojobs)}")
    ores = _pmap(_fit_predict, [((city, tst, folds[f], tr_orig_outer, test_orig, GRID[chosen[f]], seed, E.K_LEVELS), kw)
                                for (f, name, tst, kw) in ojobs], n_jobs)
    out = []
    for f in range(n_folds):
        parts = {name: dp for (ff, name, _, _), dp in zip(ojobs, ores) if ff == f}
        d = parts["gbdt"].copy()
        for name in parts:
            if name != "gbdt":
                d[name] = parts[name]["gbdt"].to_numpy()
        train_st = [s for h in range(n_folds) if h != f for s in folds[h]] + others
        peers = E.PeerCache(city, train_st)
        d["sn"], d["peer"] = E.baseline_preds(city, d, peers)
        # conformal calibration from inner out-of-fold validation residuals (stations not in fold f)
        c = cal[f]
        for col in ["gbdt", "sn", "peer"]:
            q = E.conformal_quantiles(c, col)
            for a in (0.2, 0.1):
                lo, hi = E.apply_intervals(d, col, q, a)
                d[f"{col}_lo{int((1 - a) * 100)}"] = lo; d[f"{col}_hi{int((1 - a) * 100)}"] = hi
        d["fold"] = f
        out.append(d)
    D = pd.concat(out, ignore_index=True)
    D["city"] = city.name
    D["date"] = city.days[D.t.to_numpy()]
    return D, {"folds": folds, "chosen": {f: GRID[c] for f, c in chosen.items()}}
