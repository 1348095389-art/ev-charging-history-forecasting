"""Matplotlib style helpers used for the paper figures (rcParams ladder, panel letters, fixed colours)."""
import matplotlib as mpl
import matplotlib.pyplot as plt

COL = {"gbdt": "#1f4e9c", "chronos_qmean": "#d9822b", "chronos": "#e8b27a", "peer": "#5a9e6f", "sn": "#8c6bb1", "zero": "#9a9a9a"}
LAB = {"gbdt": "Pooled GBDT", "chronos_qmean": "Chronos-2 (mean)", "chronos": "Chronos-2 (median)", "peer": "Peer profile",
       "sn": "Seasonal naive", "zero": "Zero forecast"}
ICOL = {"gbdt": COL["gbdt"], "sn": COL["sn"], "peer": COL["peer"], "chronos": COL["chronos_qmean"]}
ILAB = {"gbdt": "Pooled GBDT + conformal", "sn": "Seasonal naive + conformal", "peer": "Peer profile + conformal",
        "chronos": "Chronos-2 native quantiles"}
STY = {"gbdt": dict(lw=2.0, marker="o", ms=4, zorder=5), "chronos_qmean": dict(lw=1.4, marker="s", ms=3.5),
       "chronos": dict(lw=1.0, ls="--", marker="s", ms=3, mfc="white"), "peer": dict(lw=1.0, ls="-", marker=None),
       "sn": dict(lw=1.0, marker="^", ms=3.5), "zero": dict(lw=0.9, ls=":", marker=None)}


def apply_figure_style(*, frame="open", font=None, sizes=(8, 7, 6), grid=False):
    """Set rcParams: font-size ladder (base, secondary, tick), open frame, outward ticks, 300-dpi tight saves,
    Type-42 fonts in PDF."""
    if frame not in ("open", "boxed", "none"):
        raise ValueError(f"frame must be 'open'|'boxed'|'none', got {frame!r}")
    base, secondary, tick = sizes
    boxed = frame == "boxed"
    rc = {
        "font.family": "sans-serif", "font.size": base, "axes.labelsize": base, "axes.titlesize": base,
        "legend.fontsize": secondary, "xtick.labelsize": tick, "ytick.labelsize": tick, "axes.linewidth": 0.6,
        "xtick.direction": "out", "ytick.direction": "out", "xtick.major.size": 3, "ytick.major.size": 3,
        "xtick.major.width": 0.6, "ytick.major.width": 0.6,
        "axes.spines.top": boxed, "axes.spines.right": boxed,
        "axes.spines.left": frame != "none", "axes.spines.bottom": frame != "none",
        "axes.grid": bool(grid), "legend.frameon": False, "figure.dpi": 200, "savefig.dpi": 300, "savefig.bbox": "tight",
        "axes.titleweight": "normal", "axes.titlelocation": "left", "axes.labelweight": "normal",
        "lines.linewidth": 1.2, "patch.linewidth": 0.6, "pdf.fonttype": 42, "ps.fonttype": 42,
    }
    if font:
        rc["font.sans-serif"] = [font, "DejaVu Sans"]
    mpl.rcParams.update(rc)


def panel_letter(ax, letter, dx=-0.18, dy=1.02, case="lower", fontsize=None):
    """Bold panel letter outside the top-left corner of the axes."""
    if fontsize is None:
        fontsize = plt.rcParams.get("font.size", 8) + 1
    s = letter.lower() if case == "lower" else letter.upper()
    ax.text(dx, dy, s, transform=ax.transAxes, fontweight="bold", fontsize=fontsize, va="bottom", ha="left")
