"""Round-2 LaTeX tables and the history figure (capped results, all models)."""
import numpy as np
import pandas as pd

KO = [0, 1, 3, 7, 14, 28, -1]
KL = {0: "0", 1: "1", 3: "3", 7: "7", 14: "14", 28: "28", -1: "full"}
CITIES = ["Boulder", "Palo Alto"]
NEW_ORDER = ["0", "1-2", "3-6", "7-13", "14-27", "28-55"]
PNAME = {"gbdt": "Pooled GBDT", "lstm": "Global LSTM", "chronos_qmean": "Chronos-2", "ccov_qmean": "Chronos-2 + peer cov.",
         "tfm3_qmean": "TimesFM 3.0", "tfm3c_qmean": "TimesFM 3.0 + peer cov.", "speer": "Scaled peer profile",
         "peer": "Peer profile", "sn": "Seasonal naive", "zero": "Zero forecast",
         "chronos": "Chronos-2 (median)", "ccov": "Chronos-2 + peer cov. (median)", "tfm3": "TimesFM 3.0 (median)",
         "tfm3c": "TimesFM 3.0 + peer cov. (median)"}
INAME = {"gbdt": "GBDT + conformal", "chronos": "Chronos-2", "ccov": "Chronos-2 + peer cov.", "tfm3": "TimesFM 3.0",
         "tfm3c": "TimesFM 3.0 + peer cov.", "sn": "Seasonal naive + conformal", "peer": "Peer profile + conformal"}


def _num(x, fmt):
    return fmt.format(x) if x is not None and np.isfinite(x) else "--"


def table_by_k(df, models, val, caption, label, names, fmt="{:.3f}", model_col="model", bold_min=False):
    L = [r"\begin{table}[H]", r"\begin{adjustwidth}{-\extralength}{0cm}", r"\caption{" + caption + r"\label{" + label + "}}", r"\small",
         r"\begin{tabularx}{\fulllength}{llCCCCCCC}", r"\toprule",
         r"\textbf{City} & \textbf{Method} & " + " & ".join(r"\textbf{%s}" % KL[k] for k in KO) + r"\\", r"\midrule"]
    for ci, c in enumerate(CITIES):
        sub = df[df.city == c]
        mins = {k: sub[(sub[model_col].isin(models)) & (sub.k == k)][val].min() for k in KO}
        for mi, m in enumerate(models):
            cells = []
            for k in KO:
                x = sub[(sub[model_col] == m) & (sub.k == k)][val]
                v = float(x.iloc[0]) if len(x) else np.nan
                s = _num(v, fmt)
                if bold_min and np.isfinite(v) and s == _num(mins[k], fmt):  # ties at the printed precision are all bold
                    s = r"\textbf{" + s + "}"
                cells.append(s)
            L.append((c if mi == 0 else "") + " & " + names[m] + " & " + " & ".join(cells) + r"\\")
        if ci == 0:
            L.append(r"\midrule")
    L += [r"\bottomrule", r"\end{tabularx}", r"\end{adjustwidth}", r"\end{table}"]
    return "\n".join(L)


def tests_matrix(TS, comps, metric, caption, label, names):
    """Compact matrix: rows comparator, columns history level; cell = ratio with Holm-adjusted significance stars."""
    L = [r"\begin{table}[H]", r"\begin{adjustwidth}{-\extralength}{0cm}", r"\caption{" + caption + r"\label{" + label + "}}", r"\small",
         r"\begin{tabularx}{\fulllength}{llCCCCCCC}", r"\toprule",
         r"\textbf{City} & \textbf{GBDT vs.} & " + " & ".join(r"\textbf{%s}" % KL[k] for k in KO) + r"\\", r"\midrule"]
    t = TS[TS.metric == metric]
    for ci, c in enumerate(CITIES):
        for mi, m in enumerate(comps):
            cells = []
            for k in KO:
                x = t[(t.city == c) & (t.comparator == m) & (t.k == k)]
                if not len(x):
                    cells.append("--"); continue
                r = x.iloc[0]; star = "**" if r.p_holm < 0.01 else ("*" if r.p_holm < 0.05 else "")
                cells.append(f"{r.ratio:.3f}{star}")
            L.append((c if mi == 0 else "") + " & " + names[m] + " & " + " & ".join(cells) + r"\\")
        if ci == 0:
            L.append(r"\midrule")
    L += [r"\bottomrule", r"\end{tabularx}", r"\end{adjustwidth}", r"\end{table}"]
    return "\n".join(L)


def tests_full(TS, metric, caption, label, names):
    t = TS[TS.metric == metric].copy(); t["o"] = t.k.map({k: i for i, k in enumerate(KO)})
    L = [r"\begin{table}[H]", r"\caption{" + caption + r"\label{" + label + "}}", r"\footnotesize",
         r"\begin{tabularx}{\textwidth}{llcCCC}", r"\toprule",
         r"\textbf{City} & \textbf{GBDT vs.} & \textbf{Days} & \textbf{Ratio [95\% CI]} & \textbf{Share} & \textbf{$p$ (Holm)}\\", r"\midrule"]
    for ci, c in enumerate(CITIES):
        first = True
        for m in names:
            sub = t[(t.city == c) & (t.comparator == m)].sort_values("o")
            for j, (_, r) in enumerate(sub.iterrows()):
                p = "$<$0.001" if r.p_holm < 0.001 else f"{r.p_holm:.3f}"
                L.append((c if first else "") + " & " + (names[m] if j == 0 else "") +
                         f" & {KL[int(r.k)]} & {r.ratio:.3f} [{r.ratio_lo:.3f}, {r.ratio_hi:.3f}] & {r.share_ref_better:.2f} & {p}" + r"\\")
                first = False
        if ci == 0:
            L.append(r"\midrule")
    L += [r"\bottomrule", r"\end{tabularx}", r"\end{table}"]
    return "\n".join(L)


def new_table(NP, NI, models, caption, label):
    L = [r"\begin{table}[H]", r"\begin{adjustwidth}{-\extralength}{0cm}", r"\caption{" + caption + r"\label{" + label + "}}", r"\small",
         r"\begin{tabularx}{\fulllength}{ll" + "C" * (3 * len(models)) + "}", r"\toprule",
         r"\textbf{City} & \textbf{Days} & \multicolumn{%d}{c}{\textbf{RMSE (kWh)}} & \multicolumn{%d}{c}{\textbf{dWAPE}} & \multicolumn{%d}{c}{\textbf{Cov. 80\%%}}\\" % ((len(models),) * 3)]
    n = len(models)
    L.append(r"\cmidrule(lr){3-%d}\cmidrule(lr){%d-%d}\cmidrule(lr){%d-%d}" % (2 + n, 3 + n, 2 + 2 * n, 3 + 2 * n, 2 + 3 * n))
    short = {"gbdt": "GBDT", "chronos_qmean": "Chr.", "tfm3c_qmean": "TFM+c", "tfm3_qmean": "TFM", "ccov_qmean": "Chr.+c"}
    L.append(r" & & " + " & ".join([short[m] for m in models] * 3) + r"\\"); L.append(r"\midrule")
    imap = {"gbdt": "gbdt", "chronos_qmean": "chronos", "tfm3c_qmean": "tfm3c", "tfm3_qmean": "tfm3", "ccov_qmean": "ccov"}
    for ci, c in enumerate(CITIES):
        for bi, b in enumerate(NEW_ORDER):
            cells = []
            for col in ("RMSE", "dWAPE"):
                for m in models:
                    x = NP[(NP.city == c) & (NP.model == m) & (NP.dbin == b)][col]
                    cells.append(_num(float(x.iloc[0]), "{:.3f}") if len(x) and b != "0" or (len(x) and m == "gbdt") else "--")
            for m in models:
                x = NI[(NI.city == c) & (NI.model == imap[m]) & (NI.dbin == b) & (NI.level == 80)]["cov"]
                cells.append(_num(float(x.iloc[0]), "{:.3f}") if len(x) and (b != "0" or m == "gbdt") else "--")
            L.append((c if bi == 0 else "") + f" & {b} & " + " & ".join(cells) + r"\\")
        if ci == 0:
            L.append(r"\midrule")
    L += [r"\bottomrule", r"\end{tabularx}", r"\end{adjustwidth}", r"\end{table}"]
    return "\n".join(L)


def fig_history(PTc, path_stem, COL, apply_style, panel_letter):
    import matplotlib.pyplot as plt
    apply_style(sizes=(8, 7, 6))
    models = ["gbdt", "lstm", "chronos_qmean", "tfm3_qmean", "tfm3c_qmean", "speer", "peer", "sn", "zero"]
    col = dict(COL); col.update({"lstm": "#e7298a", "tfm3_qmean": "#e41a1c", "tfm3c_qmean": "#99000d", "speer": "#4d9221"})
    sty = {"gbdt": dict(lw=2.0, marker="o", ms=4, zorder=5), "lstm": dict(lw=1.3, marker="D", ms=3),
           "chronos_qmean": dict(lw=1.3, marker="s", ms=3.5), "tfm3_qmean": dict(lw=1.0, ls="--", marker="P", ms=3.5, mfc="white"),
           "tfm3c_qmean": dict(lw=1.3, marker="P", ms=3.5), "speer": dict(lw=1.0, ls="-.", marker=None),
           "peer": dict(lw=1.0, marker=None), "sn": dict(lw=1.0, marker="^", ms=3.5), "zero": dict(lw=0.9, ls=":", marker=None)}
    fig, axes = plt.subplots(2, 2, figsize=(7.2, 5.4), sharex=True, gridspec_kw=dict(hspace=0.25, wspace=0.24))
    x = np.arange(len(KO))
    for j, c in enumerate(CITIES):
        p = PTc[PTc.city == c]
        for i, (val, ttl, yl) in enumerate([("RMSE", "hourly RMSE vs days of history", "RMSE, kWh (lower is better)"),
                                            ("dWAPE", "station-day energy error", "Daily WAPE (lower is better)")]):
            ax = axes[i, j]
            for m in models:
                if val == "dWAPE" and m == "zero":
                    continue
                pm = p[p.model == m].set_index("k").reindex(KO)
                ax.plot(x, pm[val], color=col[m], label=PNAME[m], **sty[m])
            ax.set_title(f"{c}: {ttl}", loc="left"); ax.set_ylabel(yl); ax.margins(x=0.04, y=0.06)
            if i == 1:
                ax.set_xticks(x); ax.set_xticklabels([KL[k] for k in KO]); ax.set_xlabel("Days of station history available")
    h, l = axes[0, 0].get_legend_handles_labels()
    fig.legend(h, l, loc="lower center", ncol=5, frameon=False, fontsize=6, bbox_to_anchor=(0.5, -0.05))
    for a, lt in zip(axes.flat, "abcd"):
        panel_letter(a, lt)
    fig.savefig(path_stem + ".png", dpi=300, bbox_inches="tight"); fig.savefig(path_stem + ".pdf", bbox_inches="tight")
    return fig


def tests_full_wide(TS, metric, caption, label, names):
    t=TS[TS.metric==metric]
    L=[r"\begin{table}[H]", r"\caption{"+caption+r"\label{"+label+"}}", r"\scriptsize", r"\setlength{\tabcolsep}{3pt}",
       r"\begin{tabularx}{\textwidth}{lcCccCcc}", r"\toprule",
       r" & & \multicolumn{3}{c}{\textbf{Boulder}} & \multicolumn{3}{c}{\textbf{Palo Alto}}\\", r"\cmidrule(lr){3-5}\cmidrule(lr){6-8}",
       r"\textbf{GBDT vs.} & \textbf{Days} & \textbf{Ratio [95\% CI]} & \textbf{Share} & \textbf{$p$} & \textbf{Ratio [95\% CI]} & \textbf{Share} & \textbf{$p$}\\", r"\midrule"]
    for mi,m in enumerate(names):
        first=True
        for k in KO:
            cells=[]
            for c in CITIES:
                s=t[(t.city==c)&(t.comparator==m)&(t.k==k)]
                if len(s)==0: cells.append(None); continue
                r_=s.iloc[0]; p="$<$0.001" if r_.p_holm<0.001 else f"{r_.p_holm:.3f}"
                cells.append(f"{r_.ratio:.3f} [{r_.ratio_lo:.3f}, {r_.ratio_hi:.3f}] & {r_.share_ref_better:.2f} & {p}")
            if all(x is None for x in cells): continue
            L.append((names[m] if first else "")+f" & {KL[k]} & "+" & ".join(x if x else "-- & -- & --" for x in cells)+r"\\"); first=False
        if mi<len(names)-1: L.append(r"\midrule")
    L+=[r"\bottomrule", r"\end{tabularx}", r"\end{table}"]; return "\n".join(L)
