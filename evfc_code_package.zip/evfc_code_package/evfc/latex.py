"""LaTeX table writers for paper/tables/*.tex (MDPI template: table[H] + tabularx + booktabs)."""
import numpy as np
import pandas as pd

from .evaluate import KLAB
from .pipeline import KORD, NEW_ORDER

MOD = ["gbdt", "chronos_qmean", "chronos", "peer", "sn", "zero"]
MODN = {"gbdt": "Pooled GBDT", "chronos_qmean": "Chronos-2, mean", "chronos": "Chronos-2, median", "peer": "Peer profile",
        "sn": "Seasonal naive", "zero": "Zero forecast"}
CMP = {"peer": "Peer profile", "sn": "Seasonal naive", "chronos_qmean": "Chronos-2, mean"}
IMN = {"gbdt": "GBDT + conformal", "sn": "Seasonal naive + conformal", "chronos": "Chronos-2 native quantiles"}
ABN = {"gbdt": "Full model", "gbdt_nok": "No days-of-history feature", "gbdt_nonorm": "No scale normalisation",
       "gbdt_nopeer": "No peer features"}
CITIES = ["Boulder", "Palo Alto"]


def f3(x):
    return "--" if pd.isna(x) else f"{x:.3f}"


def write(path, L):
    # text mode: the reference files were written on Windows (CRLF line ends, no final newline)
    with open(path, "w", encoding="utf-8") as f:
        f.write("\n".join(L))


def _k_header(spec="llCCCCCCC"):
    return [r"\small", r"\begin{tabularx}{\textwidth}{" + spec + "}", r"\toprule"]


def tab_point(PT, metric, cap, label, models=MOD):
    L = [r"\begin{table}[H]", r"\caption{" + cap + r"\label{" + label + r"}}"] + _k_header() + [
        r"\textbf{City} & \textbf{Model} & \multicolumn{7}{c}{\textbf{Days of history available}}\\", r"\cmidrule{3-9}",
        r" & & 0 & 1 & 3 & 7 & 14 & 28 & full\\", r"\midrule"]
    for c in CITIES:
        p = PT[PT.city == c]
        for i, m in enumerate([mm for mm in models if not (metric == "dWAPE" and mm == "zero")]):
            row = p[p.model == m].set_index("k").reindex(KORD)[metric]
            best = {k: p[(p.k == k) & (p.model != "zero")][metric].min() for k in KORD}
            vals = [(r"\textbf{" + f3(v) + "}") if (not pd.isna(v) and m != "zero" and np.isclose(v, best[k])) else f3(v)
                    for k, v in zip(KORD, row)]
            L.append((c if i == 0 else "") + " & " + MODN[m] + " & " + " & ".join(vals) + r"\\")
        L.append(r"\midrule" if c == "Boulder" else r"\bottomrule")
    return L + [r"\end{tabularx}", r"\end{table}"]


CAP_RMSE = ("Hourly root mean squared error (kWh per station-hour) on the test year, by days of station history available at "
            "the forecast origin. Bold: lowest value among forecasting methods in each column. Chronos-2 is not defined "
            "without history.")
CAP_DWAPE = ("Weighted absolute percentage error of station-day energy (sum of the 24 hourly forecasts), by days of history. "
             "The zero forecast has a value of 1 by construction and is omitted. Bold: lowest value in each column.")
CAP_MAE = ("Hourly mean absolute error (kWh). Because most station-hours are zero, the MAE-optimal point forecast is close to "
           r"zero and the zero forecast is competitive (Section~\ref{sec:metrics}). Bold: lowest value among forecasting "
           "methods other than the zero forecast.")


def tab_tests(T):
    L = [r"\begin{table}[H]",
         r"\caption{Paired station-level comparison of the pooled GBDT with each comparator. Ratio: mean station RMSE of the "
         r"GBDT divided by that of the comparator (below 1 favours the GBDT), with a 95\% station bootstrap interval. Share: "
         r"fraction of stations on which the GBDT has the lower RMSE. $p$: two-sided Wilcoxon signed-rank test across "
         r"stations, Holm-adjusted over all " + str(len(T)) + r" comparisons.\label{tab:tests}}"] + _k_header("llcCCC") + [
        r"\textbf{City} & \textbf{Comparator} & \textbf{Days} & \textbf{Ratio [95\% CI]} & \textbf{Share} & "
        r"\textbf{$p$ (Holm)}\\", r"\midrule"]
    for c in CITIES:
        first = True
        for m in ["peer", "sn", "chronos_qmean"]:
            firstm = True
            for k in [0, 1, 7, 28, -1]:
                r = T[(T.city == c) & (T.comparator == m) & (T.k == k)]
                if r.empty:
                    continue
                r = r.iloc[0]; pv = "$<$0.001" if r.p_holm < 0.001 else f"{r.p_holm:.3f}"
                L.append((c if first else "") + " & " + (CMP[m] if firstm else "") +
                         f" & {KLAB[k]} & {r.rmse_ratio:.3f} [{r.ratio_lo:.3f}, {r.ratio_hi:.3f}] & {r.share_ref_better:.2f} & {pv}" + r"\\")
                first = False; firstm = False
        L.append(r"\midrule" if c == "Boulder" else r"\bottomrule")
    return L + [r"\end{tabularx}", r"\end{table}"]


def tab_cov(IT):
    L = [r"\begin{table}[H]",
         r"\caption{Empirical coverage and mean width (kWh) of 80\% and 90\% prediction intervals on the test year, for "
         r"selected days of history. Within $\pm$5: share of stations whose own 80\% coverage lies within 5 percentage points "
         r"of the nominal level.\label{tab:cov}}"] + _k_header("llcCCCCC") + [
        r"\textbf{City} & \textbf{Method} & \textbf{Days} & \textbf{Cov. 80\%} & \textbf{Width 80\%} & \textbf{Cov. 90\%} & "
        r"\textbf{Width 90\%} & \textbf{Within $\pm$5}\\", r"\midrule"]
    for c in CITIES:
        first = True
        for m in ["gbdt", "sn", "chronos"]:
            firstm = True
            for k in [0, 1, 7, 28, -1]:
                r = IT[(IT.city == c) & (IT.model == m) & (IT.k == k)]
                if r.empty:
                    continue
                r = r.iloc[0]
                L.append((c if first else "") + " & " + (IMN[m] if firstm else "") +
                         f" & {KLAB[k]} & {r.cov80:.3f} & {r.width80:.2f} & {r.cov90:.3f} & {r.width90:.2f} & {r.st_within5_80:.2f}" + r"\\")
                first = False; firstm = False
        L.append(r"\midrule" if c == "Boulder" else r"\bottomrule")
    return L + [r"\end{tabularx}", r"\end{table}"]


def tab_ablation(AB):
    L = [r"\begin{table}[H]",
         r"\caption{Ablation of the pooled GBDT: hourly RMSE (kWh) with the days-of-history feature removed, without scale "
         r"normalisation, and without the two peer-profile features.\label{tab:ablation}}"] + _k_header() + [
        r"\textbf{City} & \textbf{Variant} & 0 & 1 & 3 & 7 & 14 & 28 & full\\", r"\midrule"]
    for c in CITIES:
        a = AB[AB.city == c].set_index("k").reindex(KORD)
        for i, m in enumerate(ABN):
            L.append((c if i == 0 else "") + " & " + ABN[m] + " & " + " & ".join(f3(v) for v in a[m]) + r"\\")
        L.append(r"\midrule" if c == "Boulder" else r"\bottomrule")
    return L + [r"\end{tabularx}", r"\end{table}"]


def tab_new(NPT, NIT, rb, nst):
    L = [r"\begin{table}[H]",
         r"\caption{Genuinely new stations: accuracy and interval coverage over the first 56 days in service "
         f"({nst['Boulder']} stations in Boulder, {nst['Palo Alto']} in Palo Alto). Days: days in service at the forecast "
         r"origin. Ratio: observed mean demand divided by the peer-profile mean. dWAPE: station-day energy WAPE. Cov.: "
         r"empirical coverage of 80\% intervals (conformal for the GBDT, native quantiles for Chronos-2).\label{tab:new}}"
         ] + _k_header() + [
        r"\textbf{City} & \textbf{Days} & \textbf{Ratio} & \multicolumn{2}{c}{\textbf{RMSE (kWh)}} & "
        r"\multicolumn{2}{c}{\textbf{dWAPE}} & \multicolumn{2}{c}{\textbf{Cov. 80\%}}\\",
        r"\cmidrule(lr){4-5}\cmidrule(lr){6-7}\cmidrule(lr){8-9}",
        r" & & & GBDT & Chronos-2 & GBDT & Chronos-2 & GBDT & Chronos-2\\", r"\midrule"]
    for c in CITIES:
        p = NPT[NPT.city == c]; it = NIT[NIT.city == c]; r = rb.loc[c]

        def pv(m, v, b):
            x = p[(p.model == m) & (p.dbin == b)][v]; return x.iloc[0] if len(x) else np.nan

        def iv(m, b):
            x = it[(it.model == m) & (it.dbin == b)]["cov80"]; return x.iloc[0] if len(x) else np.nan
        for i, b in enumerate(NEW_ORDER):
            vals = [f"{r.loc[b, 'ratio_obs_to_peer']:.2f}", f3(pv("gbdt", "RMSE", b)), f3(pv("chronos_qmean", "RMSE", b)),
                    f3(pv("gbdt", "dWAPE", b)), f3(pv("chronos_qmean", "dWAPE", b)), f3(iv("gbdt", b)), f3(iv("chronos", b))]
            L.append((c if i == 0 else "") + f" & {b} & " + " & ".join(vals) + r"\\")
        L.append(r"\midrule" if c == "Boulder" else r"\bottomrule")
    return L + [r"\end{tabularx}", r"\end{table}"]


def tab_data(S1, n_batches):
    s = S1.set_index("city")
    return [r"\begin{table}[H]",
            r"\caption{Datasets after cleaning. Sessions and energy refer to the stations and period used in this study. "
            r"Zero share and mean demand refer to eligible stations in the test year.\label{tab:data}}"] + _k_header("lCC") + [
        r"\textbf{Item} & \textbf{Boulder, CO, USA} & \textbf{Palo Alto, CA, USA}\\", r"\midrule",
        r"Licence & CC0 1.0 & ODC Public Domain (PDDL)\\",
        f"Raw records & {int(s.loc['Boulder', 'raw_rows']):,} & {int(s.loc['Palo Alto', 'raw_rows']):,}" + r"\\",
        f"Sessions used & {int(s.loc['Boulder', 'sessions_used']):,} & {int(s.loc['Palo Alto', 'sessions_used']):,}" + r"\\",
        f"Energy used (MWh) & {s.loc['Boulder', 'energy_used_MWh']:.1f} & {s.loc['Palo Alto', 'energy_used_MWh']:.1f}" + r"\\",
        r"Period used & 2018-01 to 2023-11 & 2011-07 to 2019-12\\",
        f"Stations & {int(s.loc['Boulder', 'stations_used'])} & {int(s.loc['Palo Alto', 'stations_used'])}" + r"\\",
        f"Eligible test stations & {int(s.loc['Boulder', 'eligible_test'])} & {int(s.loc['Palo Alto', 'eligible_test'])}" + r"\\",
        f"Genuinely new stations evaluated & {int(s.loc['Boulder', 'genuinely_new'])} ({n_batches['Boulder']} batches) & "
        f"{int(s.loc['Palo Alto', 'genuinely_new'])} ({n_batches['Palo Alto']} batches)" + r"\\",
        r"Training / validation / test & to 2022-08 / 2022-09 to 11 / 2022-12 to 2023-11 & to 2018-09 / 2018-10 to 12 / "
        r"2019-01 to 12\\",
        f"Zero station-hours, test (\\%) & {100 * s.loc['Boulder', 'test_hours_zero_share']:.1f} & "
        f"{100 * s.loc['Palo Alto', 'test_hours_zero_share']:.1f}" + r"\\",
        f"Mean demand, test (kWh/h) & {s.loc['Boulder', 'test_mean_kWh_per_h']:.2f} & {s.loc['Palo Alto', 'test_mean_kWh_per_h']:.2f}" + r"\\",
        f"Hours flagged as outage (\\%) & {100 * s.loc['Boulder', 'outage_hour_share']:.2f} & "
        f"{100 * s.loc['Palo Alto', 'outage_hour_share']:.2f}" + r"\\",
        r"\bottomrule", r"\end{tabularx}", r"\end{table}"]
