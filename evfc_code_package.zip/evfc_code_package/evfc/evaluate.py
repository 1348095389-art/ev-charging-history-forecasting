"""Metrics tables, per-station coverage, Wilcoxon + Holm tests, station bootstrap CIs."""
import numpy as np
import pandas as pd
from scipy.stats import wilcoxon
from . import exp as E

POINT = {"gbdt": "Pooled GBDT", "chronos_qmean": "Chronos-2 (mean)", "chronos": "Chronos-2 (median)",
         "sn": "Seasonal naive", "peer": "Peer profile", "zero": "Zero forecast"}
INTERVAL = {"gbdt": "Pooled GBDT + conformal", "sn": "Seasonal naive + conformal", "peer": "Peer profile + conformal",
            "chronos": "Chronos-2 native quantiles"}
KLAB = {0: "0", 1: "1", 3: "3", 7: "7", 14: "14", 28: "28", -1: "full"}


def coverage(g, m, lv):
    lo, hi = g[f"{m}_lo{lv}"], g[f"{m}_hi{lv}"]
    ok = g.y.notna() & lo.notna()
    return float(((g.y >= lo) & (g.y <= hi))[ok].mean()) if ok.any() else np.nan, float((hi - lo)[ok].mean()) if ok.any() else np.nan


def point_table(D, group="k"):
    rows = []
    for k, g in D.groupby(group):
        for m in POINT:
            if m not in g or g[m].isna().all():
                continue
            rows.append({group: k, "model": m, "RMSE": E.rmse(g.y.values, g[m].values), "MAE": E.mae(g.y.values, g[m].values),
                         "dWAPE": E.daily_wape(g, m)})
    return pd.DataFrame(rows)


def interval_table(D, group="k"):
    rows = []
    for k, g in D.groupby(group):
        for m in INTERVAL:
            if f"{m}_lo80" not in g or g[f"{m}_lo80"].isna().all():
                continue
            r = {group: k, "model": m}
            for lv in (80, 90):
                c, w = coverage(g, m, lv)
                r[f"cov{lv}"], r[f"width{lv}"] = c, w
                # per-station coverage
                ps = g.groupby("station").apply(lambda h: coverage(h, m, lv)[0], include_groups=False)
                r[f"st_within5_{lv}"] = float((ps.sub(lv / 100).abs() <= 0.05).mean())
                r[f"st_min_{lv}"] = float(ps.min()); r[f"st_q10_{lv}"] = float(ps.quantile(0.1))
            rows.append(r)
    return pd.DataFrame(rows)


def per_station_rmse(D, models, group="k"):
    rows = []
    for (k, s), g in D.groupby([group, "station"]):
        r = {group: k, "station": s}
        for m in models:
            r[m] = E.rmse(g.y.values, g[m].values) if m in g and g[m].notna().any() else np.nan
        rows.append(r)
    return pd.DataFrame(rows)


def holm(p):
    p = np.asarray(p, float); n = np.sum(~np.isnan(p)); order = np.argsort(np.where(np.isnan(p), np.inf, p))
    adj = np.full_like(p, np.nan); run = 0.0
    for i, j in enumerate(order):
        if np.isnan(p[j]):
            continue
        run = max(run, min(1.0, (n - i) * p[j])); adj[j] = run
    return adj


def tests(PS, ref="gbdt", comps=("chronos_qmean", "sn", "peer"), group="k", city_col="city", n_boot=2000, seed=0):
    rng = np.random.default_rng(seed)
    rows = []
    for (c, k), g in PS.groupby([city_col, group]):
        for m in comps:
            d = g[[ref, m]].dropna()
            if len(d) < 6:
                continue
            diff = (d[ref] - d[m]).to_numpy()
            p = wilcoxon(d[ref], d[m]).pvalue if np.any(diff != 0) else 1.0
            ratio = d[ref].mean() / d[m].mean()
            bs = []
            for _ in range(n_boot):
                i = rng.integers(0, len(d), len(d)); bs.append(d[ref].to_numpy()[i].mean() / d[m].to_numpy()[i].mean())
            rows.append({city_col: c, group: k, "comparator": m, "n_stations": len(d), "median_diff": float(np.median(diff)),
                         "share_ref_better": float((diff < 0).mean()), "rmse_ratio": ratio,
                         "ratio_lo": float(np.quantile(bs, 0.025)), "ratio_hi": float(np.quantile(bs, 0.975)), "p": p})
    T = pd.DataFrame(rows)
    T["p_holm"] = holm(T.p.to_numpy())
    return T
