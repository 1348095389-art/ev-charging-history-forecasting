"""Limited-history day-ahead station forecasting: features, models, conformal intervals, evaluation.

Conventions
-----------
Y[s] : array (n_days, 24) of hourly kWh for station s (NaN = outside commissioning window or outage).
Forecast origin t (day index): forecasts for day t, hours 0..23, issued at 00:00 of day t, using
only data from days < t.  History level k: the target station's own history is restricted to
days [t-k, t) (k = 'full' -> all days since commissioning).  Peer information comes only from
training-fold stations and only from days < t.
"""
import numpy as np
import pandas as pd
from sklearn.ensemble import HistGradientBoostingRegressor

K_LEVELS = [0, 1, 3, 7, 14, 28, "full"]
PEER_WIN = 28
S_FLOOR = 0.05


# ----------------------------------------------------------------------------- data containers
class City:
    def __init__(self, name, H, days=None):
        """H: hourly DataFrame (DatetimeIndex hourly, columns stations)."""
        self.name = name
        H = H.copy()
        H.index = pd.DatetimeIndex(H.index)
        self.days = pd.date_range(H.index[0].normalize(), H.index[-1].normalize(), freq="D")
        H = H.reindex(pd.date_range(self.days[0], self.days[-1] + pd.Timedelta(hours=23), freq="h"))
        self.stations = list(H.columns)
        self.Y = {s: H[s].to_numpy().reshape(len(self.days), 24) for s in self.stations}
        self.dow = self.days.dayofweek.to_numpy()
        self.month = self.days.month.to_numpy()
        # commissioning day index = first day with any non-NaN value
        self.first = {s: int(np.argmax(~np.isnan(self.Y[s]).all(1))) for s in self.stations}
        # cumulative sums for O(1) window statistics
        self._cum = {}
        for s in self.stations:
            y = self.Y[s]
            v = np.nan_to_num(y)
            c = (~np.isnan(y)).astype(float)
            nz = (np.nan_to_num(y) > 0).astype(float)
            dsum = np.vstack([np.zeros((1, 24)), np.cumsum(v, 0)])
            dcnt = np.vstack([np.zeros((1, 24)), np.cumsum(c, 0)])
            dnz = np.vstack([np.zeros((1, 24)), np.cumsum(nz, 0)])
            wsum = np.zeros((len(self.days) + 1, 7, 24))
            wcnt = np.zeros_like(wsum)
            for j in range(7):
                m = (self.dow == j)[:, None]
                wsum[1:, j] = np.cumsum(v * m, 0)
                wcnt[1:, j] = np.cumsum(c * m, 0)
            self._cum[s] = (dsum, dcnt, dnz, wsum, wcnt)

    def window(self, s, a, b):
        """Hour-of-day profile mean, hour-of-week profile mean, overall mean, active share over days [a,b)."""
        dsum, dcnt, dnz, wsum, wcnt = self._cum[s]
        S = dsum[b] - dsum[a]; C = dcnt[b] - dcnt[a]; NZ = dnz[b] - dnz[a]
        WS = wsum[b] - wsum[a]; WC = wcnt[b] - wcnt[a]
        with np.errstate(invalid="ignore", divide="ignore"):
            prof = S / C
            wprof = WS / WC
            mean = S.sum() / C.sum() if C.sum() > 0 else np.nan
            act = NZ.sum() / C.sum() if C.sum() > 0 else np.nan
        return prof, wprof, mean, act, C.sum() / 24.0


def peer_stats(city, peers, t, win=PEER_WIN):
    """Per-station-average hour-of-week profile and level of peer stations over days [t-win, t)."""
    a = max(0, t - win)
    WS = np.zeros((7, 24)); WC = np.zeros((7, 24))
    for s in peers:
        _, _, _, wsum, wcnt = city._cum[s]
        WS += wsum[t] - wsum[a]; WC += wcnt[t] - wcnt[a]
    with np.errstate(invalid="ignore", divide="ignore"):
        prof = WS / WC
        level = WS.sum() / WC.sum() if WC.sum() > 0 else np.nan
    return prof, level


# ----------------------------------------------------------------------------- features
FEATS = ["hour", "dow", "weekend", "month", "log_kdays", "log_scale", "prev_h", "prev_18", "prev_19",
         "prev_20", "prev_21", "prev_22", "prev_23", "prev_total", "week_h", "prof_h", "wprof_h",
         "active", "peer_shape", "peer_ratio"]


def build_rows(city, s, t, k, peer_prof, peer_level, normalize=True):
    """Return (X (24 x F), y (24,), scale, k_eff) for station s, origin t, history level k."""
    first = city.first[s]
    age = t - first
    if age < 0:
        return None
    k_eff = age if k == "full" else min(k, age)
    a = t - k_eff
    if k_eff > 0:
        prof, wprof, mean, act, ndays = city.window(s, a, t)
    else:
        prof, wprof, mean, act, ndays = np.full(24, np.nan), np.full((7, 24), np.nan), np.nan, np.nan, 0.0
    pl = peer_level if np.isfinite(peer_level) else S_FLOOR
    if not np.isfinite(mean):
        scale = max(pl, S_FLOOR)
    else:
        scale = max(mean, 0.1 * pl, S_FLOOR)
    if not normalize:
        scale_div = 1.0
    else:
        scale_div = scale
    y = city.Y[s][t]
    d = city.dow[t]
    X = np.full((24, len(FEATS)), np.nan)
    X[:, 0] = np.arange(24)
    X[:, 1] = d
    X[:, 2] = float(d >= 5)
    X[:, 3] = city.month[t]
    X[:, 4] = np.log1p(k_eff)
    X[:, 5] = np.log(scale)
    if k_eff >= 1:
        prev = city.Y[s][t - 1]
        X[:, 6] = prev / scale_div
        X[:, 7:13] = prev[18:24] / scale_div
        X[:, 13] = np.nansum(prev) / 24.0 / scale_div if np.isfinite(prev).any() else np.nan
        X[:, 15] = prof / scale_div
        X[:, 17] = act
    if k_eff >= 7:
        X[:, 14] = city.Y[s][t - 7] / scale_div
    if k_eff >= 14:
        X[:, 16] = wprof[d] / scale_div
    with np.errstate(invalid="ignore", divide="ignore"):
        X[:, 18] = peer_prof[d] / pl
        X[:, 19] = pl / scale
    return X, y, scale, k_eff


def make_matrix(city, stations, origins, ks, peers_for, rng=None, normalize=True, sample_k=False):
    """Stack feature rows. peers_for: function(t) -> (peer_prof, peer_level).
    If sample_k, each (station, origin) gets one k drawn from ks; otherwise every k in ks."""
    Xs, ys, meta = [], [], []
    for t in origins:
        pp, pl = peers_for(t)
        for s in stations:
            if t - city.first[s] < 0:
                continue
            klist = [ks[rng.integers(len(ks))]] if sample_k else ks
            for k in klist:
                r = build_rows(city, s, t, k, pp, pl, normalize)
                if r is None:
                    continue
                X, y, sc, ke = r
                Xs.append(X); ys.append(y)
                meta.append(np.column_stack([np.full(24, t), np.arange(24), np.full(24, sc), np.full(24, ke),
                                             np.full(24, -1 if k == "full" else k)]))
                meta[-1] = (s, meta[-1])
    if not Xs:
        return None
    X = np.vstack(Xs); y = np.concatenate(ys)
    st = np.concatenate([[m[0]] * 24 for m in meta])
    M = np.vstack([m[1] for m in meta])
    df = pd.DataFrame({"station": st, "t": M[:, 0].astype(int), "hour": M[:, 1].astype(int), "scale": M[:, 2],
                       "k_eff": M[:, 3], "k": M[:, 4].astype(int)})
    return X, y, df


class PeerCache:
    def __init__(self, city, peers):
        self.city, self.peers, self.c = city, list(peers), {}

    def __call__(self, t):
        if t not in self.c:
            self.c[t] = peer_stats(self.city, self.peers, t)
        return self.c[t]


# ----------------------------------------------------------------------------- models
def fit_gbdt(X, y, scale, cfg, normalize=True, drop_k=False, seed=0, drop=()):
    m = ~np.isnan(y)
    Xf = X[m].copy()
    if drop_k:
        Xf[:, FEATS.index("log_kdays")] = 0.0
    for f in drop:
        Xf[:, FEATS.index(f)] = 0.0
    tgt = y[m] / (scale[m] if normalize else 1.0)
    model = HistGradientBoostingRegressor(loss=cfg["loss"], max_leaf_nodes=cfg["leaves"], learning_rate=cfg["lr"],
                                          max_iter=cfg["iters"], min_samples_leaf=cfg.get("min_leaf", 50),
                                          l2_regularization=1.0, early_stopping=False, random_state=seed,
                                          categorical_features=None)
    model.fit(Xf, tgt)
    return model


def predict_gbdt(model, X, scale, normalize=True, drop_k=False, drop=()):
    Xf = X.copy()
    if drop_k:
        Xf[:, FEATS.index("log_kdays")] = 0.0
    for f in drop:
        Xf[:, FEATS.index(f)] = 0.0
    p = model.predict(Xf) * (scale if normalize else 1.0)
    return np.maximum(p, 0.0)


def baseline_preds(city, df, peers_for):
    """Seasonal naive (t-1 day for 1<=k<7, t-7 days for k>=7; NaN for k=0) and peer profile."""
    sn = np.full(len(df), np.nan); pp = np.full(len(df), np.nan)
    for (s, t), g in df.groupby(["station", "t"], sort=False):
        prof, lvl = peers_for(t)
        d = city.dow[t]
        idx = g.index.to_numpy()
        pp[idx] = prof[d][g.hour.to_numpy()]
        ke = g.k_eff.to_numpy()
        h = g.hour.to_numpy()
        lag1 = city.Y[s][t - 1][h] if t >= 1 else np.nan
        lag7 = city.Y[s][t - 7][h] if t >= 7 else np.nan
        sn[idx] = np.where(ke >= 7, lag7, np.where(ke >= 1, lag1, np.nan))
    return sn, pp


# ----------------------------------------------------------------------------- conformal
def hblock(hour):
    return hour // 6


def conformal_quantiles(df_cal, pred_col, alphas=(0.2, 0.1)):
    """Mondrian split-conformal quantiles of |y - yhat| / scale per (k, horizon block)."""
    d = df_cal.dropna(subset=["y", pred_col]).copy()
    d["score"] = (d.y - d[pred_col]).abs() / d.scale
    d["blk"] = hblock(d.hour)
    out = {}
    for (k, b), g in d.groupby(["k", "blk"]):
        sc = np.sort(g.score.to_numpy()); n = len(sc)
        for a in alphas:
            r = int(np.ceil((n + 1) * (1 - a)))
            out[(k, b, a)] = sc[min(r, n) - 1] if n > 0 else np.nan
    return out


def apply_intervals(df, pred_col, q, alpha):
    blk = hblock(df.hour.to_numpy())
    qq = np.array([q.get((k, b, alpha), np.nan) for k, b in zip(df.k.to_numpy(), blk)])
    lo = np.maximum(df[pred_col].to_numpy() - qq * df.scale.to_numpy(), 0.0)
    hi = df[pred_col].to_numpy() + qq * df.scale.to_numpy()
    return lo, hi


# ----------------------------------------------------------------------------- metrics
def wape(y, p):
    m = ~(np.isnan(y) | np.isnan(p))
    den = np.abs(y[m]).sum()
    return np.abs(y[m] - p[m]).sum() / den if den > 0 else np.nan


def rmse(y, p):
    m = ~(np.isnan(y) | np.isnan(p))
    return float(np.sqrt(np.mean((y[m] - p[m]) ** 2))) if m.any() else np.nan


def mae(y, p):
    m = ~(np.isnan(y) | np.isnan(p))
    return float(np.mean(np.abs(y[m] - p[m]))) if m.any() else np.nan


def daily_wape(df, col):
    """WAPE of station-day energy totals (sum of the 24 hourly forecasts); days with missing hours dropped."""
    d = df[["station", "t", "y", col]].copy()
    ok = d.groupby(["station", "t"])[["y", col]].transform(lambda x: x.notna().all())
    d = d[ok.all(axis=1)]
    g = d.groupby(["station", "t"])[["y", col]].sum()
    den = g.y.sum()
    return float((g[col] - g.y).abs().sum() / den) if den > 0 else np.nan
