"""Work-around for sandboxed Windows hosts where creating named pipes is denied (PermissionError WinError 5).

scikit-learn's HistGradientBoosting bins features with joblib's *threading* backend, which builds a
multiprocessing.pool.ThreadPool; that pool creates a pipe and fails on such hosts.  ensure_thread_pool() probes
ThreadPool once and, only if it cannot be created, makes joblib's ThreadingBackend use an equivalent pool built on
concurrent.futures (no pipes).  The computations and their results are unchanged.  On normal hosts this is a no-op.
"""
from concurrent.futures import ThreadPoolExecutor


class _Job:
    def __init__(self, fut):
        self._f = fut

    def get(self, timeout=None):
        return self._f.result(timeout)

    def ready(self):
        return self._f.done()


class _FuturesPool:
    def __init__(self, n):
        self._ex = ThreadPoolExecutor(max_workers=n)

    def apply_async(self, func, args=(), kwds=None, callback=None, error_callback=None):
        fut = self._ex.submit(func, *args, **(kwds or {}))

        def done(f):
            exc = f.exception()
            if exc is None:
                if callback is not None:
                    callback(f.result())
            elif error_callback is not None:
                error_callback(exc)
        fut.add_done_callback(done)
        return _Job(fut)

    def close(self):
        pass

    def terminate(self):
        self._ex.shutdown(wait=True)

    def join(self):
        pass


def ensure_thread_pool():
    """Return True if the fallback pool was installed."""
    try:
        from multiprocessing.pool import ThreadPool
        p = ThreadPool(1); p.close(); p.join()
        return False
    except PermissionError:
        from joblib import _parallel_backends as jb

        def _get_pool(self):
            if self._pool is None:
                self._pool = _FuturesPool(self._n_jobs)
            return self._pool
        jb.ThreadingBackend._get_pool = _get_pool
        return True
