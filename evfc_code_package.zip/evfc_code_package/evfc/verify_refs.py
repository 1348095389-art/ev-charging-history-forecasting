"""Verify candidate references against Crossref (DOIs) and arXiv (ids); write refs_verified.json."""
import json
import re
import sys
import time
import requests

DOIS = [
    "10.3390/wevj16020088", "10.3390/wevj16030150", "10.3390/wevj16050265", "10.3390/wevj17020071",
    "10.3390/wevj17030111", "10.3390/wevj17070336", "10.3390/wevj17070367", "10.3390/wevj17090443",
    "10.3390/wevj17090479", "10.3390/wevj17010037", "10.3390/wevj17100537", "10.3390/en14082233",
    "10.1038/s41597-025-05584-7", "10.1038/s41597-025-04874-4", "10.3390/en19020378",
    "10.1007/978-3-031-06649-8", "10.1080/01621459.2017.1307116", "10.1016/j.ijforecast.2006.03.001",
    "10.1198/jasa.2011.r10138", "10.1214/aos/1013203451", "10.1016/j.ijforecast.2021.03.004",
    "10.1016/j.ijforecast.2021.11.013", "10.2307/3001968", "10.1145/3307772.3328313", "10.3390/en14051487",
    "10.1016/j.apenergy.2020.116337", "10.1109/ACCESS.2020.2965621", "10.1016/j.ijforecast.2015.12.004",
    "10.1016/j.ijforecast.2019.05.008",
]
ARXIV = ["2403.07815", "2510.15821", "2409.11862", "2510.26910", "2505.06657", "2610.13588", "2602.24238",
         "1905.03222", "2106.00170"]
SEARCH = [
    "Machine learning approaches to short-term EV charging demand prediction: Applicability and geographical transferability",
    "Risk-aware peak-load profile forecasting for new electric vehicle fast-charging stations without historical data",
    "Forecasting the EV charging load based on customer profile or station measurement",
    "Scikit-learn: Machine Learning in Python",
    "LightGBM: A Highly Efficient Gradient Boosting Decision Tree",
    "A simple sequentially rejective multiple test procedure",
]


def crossref(doi):
    r = requests.get(f"https://api.crossref.org/works/{doi}", timeout=30)
    if r.status_code != 200:
        return {"doi": doi, "ok": False, "status": r.status_code}
    m = r.json()["message"]
    au = [f"{a.get('family', '')}, {a.get('given', '')}".strip(", ") for a in m.get("author", [])]
    yr = (m.get("issued", {}).get("date-parts") or [[None]])[0][0]
    return {"doi": doi, "ok": True, "title": (m.get("title") or [""])[0], "venue": (m.get("container-title") or [""])[0],
            "year": yr, "volume": m.get("volume"), "issue": m.get("issue"), "page": m.get("page"),
            "article_number": m.get("article-number"), "authors": au, "type": m.get("type")}


def arxiv(aid):
    r = requests.get(f"https://export.arxiv.org/api/query?id_list={aid}", timeout=30)
    t = r.text
    ent = t.split("<entry>")[1] if "<entry>" in t else ""
    title = re.sub(r"\s+", " ", re.search(r"<title>(.*?)</title>", ent, re.S).group(1)).strip() if ent else ""
    au = re.findall(r"<name>(.*?)</name>", ent)
    pub = re.search(r"<published>(\d{4})", ent)
    return {"arxiv": aid, "ok": bool(title) and "Error" not in title, "title": title, "authors": au,
            "year": int(pub.group(1)) if pub else None}


def search(q):
    r = requests.get("https://api.crossref.org/works", params={"query.bibliographic": q, "rows": 3}, timeout=30)
    items = r.json()["message"]["items"]
    return {"query": q, "hits": [{"doi": i.get("DOI"), "title": (i.get("title") or [""])[0],
                                   "venue": (i.get("container-title") or [""])[0],
                                   "year": (i.get("issued", {}).get("date-parts") or [[None]])[0][0]} for i in items]}


if __name__ == "__main__":
    out = {"crossref": [], "arxiv": [], "search": []}
    for d in DOIS:
        try:
            out["crossref"].append(crossref(d))
        except Exception as e:
            out["crossref"].append({"doi": d, "ok": False, "err": str(e)[:100]})
        time.sleep(0.2)
    for a in ARXIV:
        try:
            out["arxiv"].append(arxiv(a))
        except Exception as e:
            out["arxiv"].append({"arxiv": a, "ok": False, "err": str(e)[:100]})
        time.sleep(3)
    for q in SEARCH:
        try:
            out["search"].append(search(q))
        except Exception as e:
            out["search"].append({"query": q, "err": str(e)[:100]})
    json.dump(out, open(sys.argv[1] if len(sys.argv) > 1 else "refs_verified.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print("done", sum(x.get("ok", False) for x in out["crossref"]), "/", len(DOIS), "dois;",
          sum(x.get("ok", False) for x in out["arxiv"]), "/", len(ARXIV), "arxiv")
