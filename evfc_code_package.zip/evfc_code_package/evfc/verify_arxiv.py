import json, sys, time
from verify_refs import arxiv  # noqa: E402

IDS = sys.argv[2:]
out = []
for a in IDS:
    for attempt in range(3):
        try:
            r = arxiv(a)
            if r["ok"]:
                break
        except Exception as e:
            r = {"arxiv": a, "ok": False, "err": str(e)[:100]}
        time.sleep(8)
    out.append(r)
    time.sleep(6)
json.dump(out, open(sys.argv[1], "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print("done", sum(x["ok"] for x in out), "/", len(out))
