"""Pipeline glue shared by the scripts in scripts/.

Everything here was extracted from the original interactive session (final versions of each step) so
that the scripts can be run from a clean process.  Paths are relative to the package root.
"""
import os
import pickle

import numpy as np
import pandas as pd

from . import exp as E
from . import newsite as NS
from . import prep as P
from . import run as RN

RAW_BOULDER = "data/raw/boulder_ev_sessions.csv.gz"
RAW_PALOALTO = "data/raw/paloalto_ev_sessions.csv"

# Boulder fleet / maintenance chargers (not public) are excluded from the study
FLEET_PATTERNS = ("FLT MNT", "MSC E", "OSMP FLEET")

BOULDER_SPAN = ("2018-01-01", "2023-12-01")      # hourly grid [t0, t1)
PALOALTO_SPAN = ("2011-07-29", "2021-01-01")
PALOALTO_END = "2019-12-31 23:00"                # last hour used in the study
PALOALTO_COMMISSIONED_BY = "2018-09-30"          # stations commissioned after the training period are not used

CFG_B = dict(train_end="2022-08-31", val_start="2022-09-01", val_end="2022-11-30",
             test_start="2022-12-01", test_end="2023-11-30")
CFG_P = dict(train_end="2018-09-30", val_start="2018-10-01", val_end="2018-12-31",
             test_start="2019-01-01", test_end="2019-12-31")
# GBDT configuration of the genuinely-new-station experiment (most frequently chosen config per city)
NEW_CFG = {"boulder": dict(loss="poisson", leaves=15, lr=0.05, iters=400),
           "paloalto": dict(loss="poisson", leaves=31, lr=0.05, iters=400)}

NEW_BINS = [(0, 0), (1, 2), (3, 6), (7, 13), (14, 27), (28, 55)]
NEW_ORDER = ["0", "1-2", "3-6", "7-13", "14-27", "28-55"]
KORD = [0, 1, 3, 7, 14, 28, -1]
KLB = ["0", "1", "3", "7", "14", "28", "full"]
CITY_NAMES = {"boulder": "Boulder", "paloalto": "Palo Alto"}


# ----------------------------------------------------------------------------- step 02: preparation
def prepare_all(log=print):
    """Clean both raw session files, build hourly station matrices and write data/*.pkl."""
    os.makedirs("data", exist_ok=True)
    # Boulder
    raw = P.load_boulder(RAW_BOULDER)
    cl, logB = P.clean_sessions(raw)
    H = P.sessions_to_hourly(cl, *BOULDER_SPAN)
    win = P.station_windows(cl)
    Hw, fl = P.apply_windows_and_outages(H, win)
    log(f"Boulder cleaning {logB}; hourly {Hw.shape}")
    # Palo Alto
    rawP = P.load_paloalto(RAW_PALOALTO)
    clP, logP = P.clean_sessions(rawP)
    HP = P.sessions_to_hourly(clP, *PALOALTO_SPAN)
    winP = P.station_windows(clP)
    HPw, flP = P.apply_windows_and_outages(HP, winP)
    log(f"Palo Alto cleaning {logP}; hourly {HPw.shape}")
    Hw.to_pickle("data/boulder_hourly.pkl")
    HPw.to_pickle("data/paloalto_hourly.pkl")
    cl.to_pickle("data/boulder_sessions_clean.pkl")
    clP.to_pickle("data/paloalto_sessions_clean.pkl")
    pd.to_pickle({"boulder": logB, "paloalto": logP}, "data/cleaning_logs.pkl")
    pd.to_pickle({"boulder": float(fl.values.mean()), "paloalto": float(flP.values.mean())}, "data/outage_share.pkl")
    winP.to_pickle("data/paloalto_windows.pkl")
    ctx = load_context()
    setup = {"fleet": ctx["fleet"], "eligible": {"boulder": ctx["cfgB"]["eligible"], "paloalto": ctx["cfgP"]["eligible"]},
             "newcand": ctx["newcand"], "stations": {"boulder": ctx["cityB"].stations, "paloalto": ctx["cityP"].stations}}
    pd.to_pickle(setup, "data/setup.pkl")
    return ctx


def new_candidates(city, min_start_days=180):
    """Genuinely new stations: commissioned >= 180 days after the data start, with >= 80% of their first
    56 days observed."""
    out = []
    for s in city.stations:
        f = city.first[s]
        if f >= min_start_days and f + NS.HORIZON_DAYS <= len(city.days) and \
                np.isfinite(city.Y[s][f:f + NS.HORIZON_DAYS]).all(1).mean() > 0.8:
            out.append(s)
    return out


def load_context():
    """Rebuild City objects, eligibility lists, configs and new-station candidates from data/*.pkl."""
    Hw = pd.read_pickle("data/boulder_hourly.pkl")
    HPw = pd.read_pickle("data/paloalto_hourly.pkl")
    winP = pd.read_pickle("data/paloalto_windows.pkl")
    # Boulder: drop fleet chargers
    fleet = [s for s in Hw.columns if any(x in s for x in FLEET_PATTERNS)]
    Hb = Hw.drop(columns=fleet)
    cityB = E.City("Boulder", Hb)
    first = {s: cityB.days[cityB.first[s]] for s in cityB.stations}
    a, b = RN.day_index(cityB, CFG_B["test_start"]), RN.day_index(cityB, CFG_B["test_end"]) + 1
    act_test = {s: np.isfinite(cityB.Y[s][a:b]).all(1).mean() for s in cityB.stations}
    eligB = [s for s in cityB.stations
             if first[s] <= pd.Timestamp(CFG_B["test_start"]) - pd.Timedelta(days=180) and act_test[s] >= 0.5]
    cfgB = dict(CFG_B, eligible=eligB, pool=list(cityB.stations))
    # Palo Alto: study period to 2019-12-31, stations commissioned by the end of the training period
    HPc = HPw.loc[:PALOALTO_END]
    HPc = HPc.loc[:, [c for c in HPc.columns if winP.loc[c, "first"] <= pd.Timestamp(PALOALTO_COMMISSIONED_BY)]]
    cityP = E.City("PaloAlto", HPc)
    fP = {s: cityP.days[cityP.first[s]] for s in cityP.stations}
    a0, a1 = RN.day_index(cityP, CFG_P["test_start"]), RN.day_index(cityP, CFG_P["test_end"]) + 1
    actP = {s: np.isfinite(cityP.Y[s][a0:a1]).all(1).mean() for s in cityP.stations}
    eligP = [s for s in cityP.stations if fP[s] <= pd.Timestamp("2018-07-05") and actP[s] >= 0.5]
    cfgP = dict(CFG_P, eligible=eligP, pool=list(cityP.stations))
    # candidate genuinely new stations (Palo Alto candidates are screened on all stations to 2019-12-31)
    cityP_full = E.City("PaloAlto", HPw.loc[:, [c for c in HPw.columns
                                               if winP.loc[c, "first"] <= pd.Timestamp("2019-12-31")]].loc[:PALOALTO_END])
    newcand = {"boulder": new_candidates(cityB), "paloalto": new_candidates(cityP_full)}
    assert set(newcand["paloalto"]) <= set(cityP.stations)
    return dict(Hw=Hw, Hb=Hb, HPw=HPw, HPc=HPc, winP=winP, fleet=fleet, cityB=cityB, cityP=cityP,
                cfgB=cfgB, cfgP=cfgP, newcand=newcand)


def city_of(ctx, name):
    return ctx["cityB"] if name == "boulder" else ctx["cityP"]


# ----------------------------------------------------------------------------- step 04: Chronos-2 inputs
def chronos_inputs(ctx, D_pseudo, outdir="chronos_in"):
    """Write <city>_pseudo.npz and <city>_new.npz (series + spec [station_idx, origin_day, k_eff]) and meta.pkl.
    D_pseudo: dict name -> cross-fitted result frame from step 03 (row order defines the pseudo spec order)."""
    os.makedirs(outdir, exist_ok=True)
    meta = {}
    for name in ("boulder", "paloalto"):
        city = city_of(ctx, name)
        st_idx = {s: i for i, s in enumerate(city.stations)}
        series = np.vstack([city.Y[s].reshape(-1) for s in city.stations]).astype("float32")
        D = D_pseudo[name]
        ps = D[D.k != 0][["station", "t", "k_eff", "k"]].drop_duplicates(["station", "t", "k"])
        spec_p = np.column_stack([ps.station.map(st_idx).values, ps.t.values, ps.k_eff.values.astype(int)]).astype("int32")
        np.savez_compressed(f"{outdir}/{name}_pseudo.npz", series=series, spec=spec_p)
        nc = [(st_idx[s], t, t - city.first[s]) for s in ctx["newcand"][name]
              for t in range(city.first[s], city.first[s] + NS.HORIZON_DAYS)]
        np.savez_compressed(f"{outdir}/{name}_new.npz", series=series, spec=np.array(nc, dtype="int32"))
        meta[name] = dict(stations=city.stations, pseudo=ps.reset_index(drop=True),
                          new=pd.DataFrame(nc, columns=["si", "t", "k_eff"]))
    with open(f"{outdir}/meta.pkl", "wb") as f:
        pickle.dump(meta, f)
    return meta


# ----------------------------------------------------------------------------- step 06: merge Chronos outputs
QMEAN_W = np.array([.075, .1, .2, .25, .2, .1, .075])   # weights of QL = [.05,.1,.25,.5,.75,.9,.95]


def _spec_frame(meta, ctx, name, kind):
    if kind == "pseudo":
        sp = meta[name]["pseudo"].copy(); keys = ["station", "t", "k"]
    else:
        city = city_of(ctx, name)
        sp = meta[name]["new"].copy(); sp["station"] = [city.stations[i] for i in sp.si]; keys = ["station", "t"]
    sp["row"] = np.arange(len(sp))
    return sp, keys


def merge_ch(D, meta, ctx, name, kind, hp="chronos_out/"):
    """Attach Chronos-2 mean / median / 80% and 90% quantile bounds to the result rows."""
    z = np.load(hp + f"chronos_{name}_{kind}.npz"); Q, Mn, ql = z["q"], z["mean"], list(z["ql"])
    sp, keys = _spec_frame(meta, ctx, name, kind)
    assert len(sp) == len(Q), (name, kind, len(sp), len(Q))
    m = D[keys + ["hour"]].merge(sp[keys + ["row"]], on=keys, how="left")
    r = m.row.to_numpy(); ok = ~np.isnan(r); ri = r[ok].astype(int); h = m.hour.to_numpy()[ok]
    for col, arr in [("chronos", Mn[:, :]), ("chronos_med", Q[:, :, ql.index(0.5)]), ("chronos_lo80", Q[:, :, ql.index(0.1)]),
                     ("chronos_hi80", Q[:, :, ql.index(0.9)]), ("chronos_lo90", Q[:, :, ql.index(0.05)]),
                     ("chronos_hi90", Q[:, :, ql.index(0.95)])]:
        v = np.full(len(D), np.nan); v[np.flatnonzero(ok)] = arr[ri, h]; D[col] = v
    return D


def add_qmean(D, meta, ctx, name, kind, hp="chronos_out/"):
    """Chronos-2 'mean' point forecast used in the paper: weighted average of the 7 native quantiles."""
    z = np.load(hp + f"chronos_{name}_{kind}.npz"); Q = z["q"]; QM = (Q * QMEAN_W).sum(-1)
    sp, keys = _spec_frame(meta, ctx, name, kind)
    m = D[keys + ["hour"]].merge(sp[keys + ["row"]], on=keys, how="left"); r = m.row.to_numpy(); ok = ~np.isnan(r)
    v = np.full(len(D), np.nan); v[np.flatnonzero(ok)] = QM[r[ok].astype(int), m.hour.to_numpy()[ok]]; D["chronos_qmean"] = v
    return D


def ctx_valid(city, s, t, ke):
    c = city.Y[s][max(0, t - ke):t].reshape(-1)[-2048:]
    return int(np.isfinite(c).sum())


def apply_fallback(D, city):
    """Contexts with no finite value (station entirely in outage over its window) fall back to the peer profile."""
    key = D[["station", "t", "k_eff"]].drop_duplicates()
    key["nvalid"] = [ctx_valid(city, s, int(t), int(k)) for s, t, k in key.itertuples(index=False)]
    D = D.drop(columns=[c for c in ["nvalid"] if c in D]).merge(key, on=["station", "t", "k_eff"], how="left")
    fb = (D.nvalid == 0) & (D.k_eff > 0)
    src = {"chronos": "peer", "chronos_med": "peer", "chronos_qmean": "peer", "chronos_lo80": "peer_lo80",
           "chronos_hi80": "peer_hi80", "chronos_lo90": "peer_lo90", "chronos_hi90": "peer_hi90"}
    for col in ["chronos", "chronos_med", "chronos_qmean", "chronos_lo80", "chronos_hi80", "chronos_lo90", "chronos_hi90"]:
        D.loc[fb, col] = D.loc[fb, src[col]]
    D["ctx_fallback"] = fb
    return D


def dbin(d):
    for a, b in NEW_BINS:
        if a <= d <= b:
            return f"{a}-{b}" if a != b else "0"


# ----------------------------------------------------------------------------- evaluation helpers
def boot_rmse(D, models, nb=1000, seed=0):
    """Pooled hourly RMSE per k with a 95% station-bootstrap interval."""
    rng = np.random.default_rng(seed); out = []
    for k, g in D.groupby("k"):
        agg = {}
        for m in models:
            e = (g[m] - g.y) ** 2; ok = e.notna()
            agg[m] = pd.DataFrame({"s": g.station[ok], "e": e[ok]}).groupby("s").e.agg(["sum", "count"])
        stations = agg["gbdt"].index.to_numpy()
        for m in models:
            st = agg[m].reindex(stations).fillna(0); S = st["sum"].to_numpy(); C = st["count"].to_numpy()
            if C.sum() == 0:
                continue
            bs = []
            for _ in range(nb):
                i = rng.integers(0, len(S), len(S)); bs.append(np.sqrt(S[i].sum() / max(C[i].sum(), 1)))
            out.append(dict(k=k, model=m, rmse=np.sqrt(S.sum() / C.sum()), lo=np.quantile(bs, .025), hi=np.quantile(bs, .975)))
    return pd.DataFrame(out)


def data_summary(ctx):
    cl = pd.read_pickle("data/boulder_sessions_clean.pkl"); clP = pd.read_pickle("data/paloalto_sessions_clean.pkl")
    logs = pd.read_pickle("data/cleaning_logs.pkl"); outage = pd.read_pickle("data/outage_share.pkl")
    cityB, cityP, cfgB, cfgP = ctx["cityB"], ctx["cityP"], ctx["cfgB"], ctx["cfgP"]

    def summ(name, clean, log, city, cfg, elig_, newc):
        a, b = RN.day_index(city, cfg["test_start"]), RN.day_index(city, cfg["test_end"]) + 1
        Yt = np.concatenate([city.Y[s][a:b].reshape(-1) for s in elig_]); Yt = Yt[np.isfinite(Yt)]
        return dict(city=name, raw_rows=log["raw"], sessions_kept=log["after_dupes"], energy_MWh=round(clean.energy.sum() / 1000, 1),
                    first=str(clean.start.min().date()), last=str(clean.start.max().date()), stations_used=len(city.stations),
                    eligible_test=len(elig_), genuinely_new=len(newc), test_hours_zero_share=round(float((Yt == 0).mean()), 3),
                    test_mean_kWh_per_h=round(float(Yt.mean()), 3), outage_hour_share=None)

    S1 = pd.DataFrame([summ("Boulder", cl, logs["boulder"], cityB, cfgB, cfgB["eligible"], ctx["newcand"]["boulder"]),
                       summ("Palo Alto", clP, logs["paloalto"], cityP, cfgP, cfgP["eligible"], ctx["newcand"]["paloalto"])])
    S1.loc[0, "outage_hour_share"] = round(outage["boulder"], 4); S1.loc[1, "outage_hour_share"] = round(outage["paloalto"], 4)
    nf = cl[~cl.station.isin(ctx["fleet"])]
    S1.loc[0, "sessions_used"] = len(nf); S1.loc[0, "energy_used_MWh"] = round(nf.energy.sum() / 1000, 1)
    nfP = clP[clP.station.isin(cityP.stations) & (clP.start < "2020-01-01")]
    S1.loc[1, "sessions_used"] = len(nfP); S1.loc[1, "energy_used_MWh"] = round(nfP.energy.sum() / 1000, 1)
    return S1
