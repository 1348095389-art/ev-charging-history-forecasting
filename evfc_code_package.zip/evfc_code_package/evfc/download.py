"""Download public EV charging session datasets used in the study (run once)."""
import os
import shutil
import sys
import requests

SOURCES = {
    # City of Boulder, CO: Electric Vehicle Charging Station Data (CC0 1.0), ArcGIS Hub id 95992b3938be4622b07f0b05eba95d4c_0
    "boulder_ev_sessions.csv.gz": "https://opendata.arcgis.com/api/v3/datasets/95992b3938be4622b07f0b05eba95d4c_0/downloads/data?format=csv&spatialRefId=4326",
    # City of Palo Alto, CA: Electric Vehicle Charging Station Usage (July 2011 - Dec 2020), ChargePoint Data CY20Q4.csv
    "paloalto_ev_sessions.csv": "https://data.paloalto.gov/datasets/194693-electric-vehicle-charging-station-usage-july-2011-dec-2020.download/",
}


def fetch(name, url, outdir="data/raw"):
    os.makedirs(outdir, exist_ok=True)
    dst = os.path.join(outdir, name)
    with requests.get(url, stream=True, timeout=900, allow_redirects=True) as r:
        print(name, r.status_code, [h.status_code for h in r.history], r.headers.get("content-type"))
        r.raise_for_status()
        with open(dst, "wb") as o:
            shutil.copyfileobj(r.raw, o, length=1 << 20)
    print(dst, os.path.getsize(dst))


if __name__ == "__main__":
    names = sys.argv[1:] or list(SOURCES)
    for n in names:
        try:
            fetch(n, SOURCES[n])
        except Exception as e:  # report and continue
            print("ERR", n, type(e).__name__, str(e)[:300])
