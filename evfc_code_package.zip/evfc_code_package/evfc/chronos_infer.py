"""Zero-shot Chronos-2 day-ahead forecasts for limited-history contexts.

Input npz (one per city): series float32 (n_stations, n_hours) hourly kWh with NaN for missing,
spec int32 (n, 3) columns [station_idx, origin_day, k_eff].  The context for spec i is
series[station, (origin_day - k_eff)*24 : origin_day*24], truncated to the most recent MAX_CTX hours.
k_eff = 0 specs are skipped (no context).  Output npz: q (n, 24, len(QL)) and mean (n, 24); NaN where skipped.
"""
import sys
import time
import numpy as np
import torch
from chronos import BaseChronosPipeline

QL = [0.05, 0.1, 0.25, 0.5, 0.75, 0.9, 0.95]
MAX_CTX = 2048
BATCH = 256


def main(inp, out):
    d = np.load(inp)
    series, spec = d["series"], d["spec"]
    n = len(spec)
    Q = np.full((n, 24, len(QL)), np.nan, dtype=np.float32)
    M = np.full((n, 24), np.nan, dtype=np.float32)
    dev = "cpu"
    try:
        torch.zeros(1).cuda(); dev = "cuda"
    except Exception as e:  # GB10 unified memory may be exhausted by other services
        print("CUDA unavailable, using CPU:", str(e)[:120])
        torch.set_num_threads(20)
    print("device", dev, flush=True)
    pipe = BaseChronosPipeline.from_pretrained("amazon/chronos-2", device_map=dev)
    idx = [i for i in range(n) if spec[i, 2] > 0]
    # sort by context length to reduce padding
    idx.sort(key=lambda i: min(spec[i, 2] * 24, MAX_CTX))
    t0 = time.time()
    for b in range(0, len(idx), BATCH):
        ids = idx[b:b + BATCH]
        ctx = []
        for i in ids:
            s, t, k = spec[i]
            a = max((t - k) * 24, t * 24 - MAX_CTX)
            ctx.append(torch.tensor(series[s, a:t * 24], dtype=torch.float32))
        q, m = pipe.predict_quantiles(ctx, prediction_length=24, quantile_levels=QL)
        q = torch.stack([x.squeeze(0) for x in q]) if isinstance(q, list) else q
        m = torch.stack([x.squeeze(0) for x in m]) if isinstance(m, list) else m
        Q[ids] = np.clip(q.float().cpu().numpy().reshape(len(ids), 24, len(QL)), 0, None)
        M[ids] = np.clip(m.float().cpu().numpy().reshape(len(ids), 24), 0, None)
        if b % (BATCH * 40) == 0:
            print(f"{b}/{len(idx)} {time.time() - t0:.1f}s", flush=True)
    np.savez_compressed(out, q=Q, mean=M, ql=np.array(QL))
    print("done", n, f"{time.time() - t0:.1f}s")


if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2])
