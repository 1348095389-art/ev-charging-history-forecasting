"""Control for the genuinely-new-station experiment (reviewer request).

Same batch protocol as newsite.run_batch (training only on stations in service before the batch onset, origins
before the onset, conformal calibration by 3-fold cross-fitting among the training stations on the CAL_DAYS days
before the onset), but the forecast targets are MATURE stations held out from training, observed over the same
56 days after the onset, with their history truncated to the days since the onset (k = d). If the coverage gap seen
on genuinely new stations were caused by the protocol (short calibration window, few peers, season), it would also
appear here; if it is caused by the demand ramp-up of new stations, it should not.
"""
import numpy as np
import pandas as pd
from . import exp as E
from . import newsite as NS

MATURE_DAYS = 180


def _fit(city, train_st, b0, cfg, seed, stride, rng):
    pc = E.PeerCache(city, train_st)
    X, y, d = E.make_matrix(city, train_st, list(range(28, b0, stride)), E.K_LEVELS, pc, rng=rng, sample_k=True)
    return E.fit_gbdt(X, y, d.scale.to_numpy(), cfg, seed=seed), pc


def _calibrate(city, train_st, b0, cfg, seed, stride, rng):
    perm = rng.permutation(len(train_st)); folds = [[train_st[i] for i in perm[f::3]] for f in range(3)]
    cal = []
    for f in range(3):
        trs = [s for g in range(3) if g != f for s in folds[g]]
        if not trs or not folds[f]:
            continue
        pcf = E.PeerCache(city, trs)
        Xc, yc, dc = E.make_matrix(city, trs, list(range(28, b0 - NS.CAL_DAYS, stride)), E.K_LEVELS, pcf, rng=rng, sample_k=True)
        mf = E.fit_gbdt(Xc, yc, dc.scale.to_numpy(), cfg, seed=seed)
        r = E.make_matrix(city, folds[f], list(range(b0 - NS.CAL_DAYS, b0)), NS.K_CAL, pcf)
        if r is None:
            continue
        Xv, yv, dv = r
        dv["y"] = yv; dv["gbdt"] = E.predict_gbdt(mf, Xv, dv.scale.to_numpy())
        dv["sn"], dv["peer"] = E.baseline_preds(city, dv, pcf)
        cal.append(dv)
    return pd.concat(cal, ignore_index=True)


def run_batch_control(city, b0, cfg, seed=0, stride=1, min_peers=4):
    peers = [s for s in city.stations if city.first[s] < b0 - 28 and np.isfinite(city.Y[s][max(0, b0 - 28):b0]).any()]
    H = NS.HORIZON_DAYS
    ctrl = [s for s in peers if city.first[s] <= b0 - MATURE_DAYS and b0 + H <= len(city.days)
            and np.isfinite(city.Y[s][b0:b0 + H]).all(1).mean() > 0.8]
    if len(peers) < min_peers + 3 or len(ctrl) < 3:
        return None
    rng = np.random.default_rng(seed)
    perm = rng.permutation(len(ctrl)); cfolds = [[ctrl[i] for i in perm[f::3]] for f in range(3)]
    out = []
    for f in range(3):
        held = cfolds[f]
        train_st = [s for s in peers if s not in held]
        model, pc = _fit(city, train_st, b0, cfg, seed, stride, rng)
        parts = []
        for dd in range(H):
            r = E.make_matrix(city, held, [b0 + dd], [dd], pc)
            if r is None:
                continue
            Xp, yp, dp = r
            dp["y"] = yp; dp["gbdt"] = E.predict_gbdt(model, Xp, dp.scale.to_numpy())
            parts.append(dp)
        D = pd.concat(parts, ignore_index=True)
        D["sn"], D["peer"] = E.baseline_preds(city, D, pc)
        D["days_in_service"] = (D.t - b0).astype(int)
        D["k"] = NS.k_bin(D.k_eff.to_numpy())
        C = _calibrate(city, train_st, b0, cfg, seed, stride, rng)
        for col in ["gbdt", "sn", "peer"]:
            q = E.conformal_quantiles(C, col)
            for a in (0.2, 0.1):
                lo, hi = E.apply_intervals(D, col, q, a)
                D[f"{col}_lo{int((1 - a) * 100)}"] = lo; D[f"{col}_hi{int((1 - a) * 100)}"] = hi
        D["ctrl_fold"] = f
        out.append(D)
    D = pd.concat(out, ignore_index=True)
    D["batch_onset"] = city.days[b0]; D["n_peers"] = len(peers); D["n_ctrl"] = len(ctrl)
    return D


def run_city_control(city, candidates, cfg, seed=0, log=print):
    res = []
    for b0, st in NS.batches(city, candidates):
        D = run_batch_control(city, b0, cfg, seed=seed)
        log(f"[{city.name}] control batch {city.days[b0].date()} -> {'skipped' if D is None else (D.station.nunique(), len(D))}")
        if D is not None:
            res.append(D)
    D = pd.concat(res, ignore_index=True)
    D["city"] = city.name; D["date"] = city.days[D.t.to_numpy()]
    return D
