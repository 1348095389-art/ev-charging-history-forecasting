"""Session-level public EV charging data -> hourly station energy (kWh).

Each cleaned session's energy is spread uniformly over its charging interval
[start, start + charging_time] and allocated to hourly bins in proportion to
overlap. Hours outside a station's commissioning window are NaN, not zero.
"""
import numpy as np
import pandas as pd

MAX_CHARGE_H = 48.0      # sessions with longer charging time are dropped
MAX_AVG_KW = 25.0        # implied average power above this is implausible for these L2 networks
OUTAGE_DAYS = 14         # runs of >= this many consecutive zero-energy days are flagged as outage


def _to_hours(s):
    """Parse 'h:mm:ss' (hours may exceed 24) or timedelta-like strings to float hours."""
    td = pd.to_timedelta(s, errors="coerce")
    return td.dt.total_seconds() / 3600.0


def clean_sessions(df):
    """df columns: station, start (datetime), charge_h (float), energy (kWh). Returns cleaned df and a log."""
    log = {"raw": len(df)}
    df = df.dropna(subset=["station", "start", "charge_h", "energy"]).copy()
    log["after_missing"] = len(df)
    df = df[(df.energy > 0) & (df.charge_h > 0)]
    log["after_nonpositive"] = len(df)
    df = df[df.charge_h <= MAX_CHARGE_H]
    log["after_long"] = len(df)
    df = df[(df.energy / df.charge_h) <= MAX_AVG_KW]
    log["after_power"] = len(df)
    key = ["station", "start", "energy_key"] if "energy_key" in df.columns else ["station", "start", "energy"]
    df = df.drop_duplicates(subset=key)
    log["after_dupes"] = len(df)
    return df.sort_values("start").reset_index(drop=True), log


def sessions_to_hourly(df, t0=None, t1=None):
    """Allocate session energy to hourly bins. Returns wide DataFrame (hour x station)."""
    t0 = pd.Timestamp(t0) if t0 is not None else df.start.min().floor("h")
    t1 = pd.Timestamp(t1) if t1 is not None else (df.start + pd.to_timedelta(df.charge_h, unit="h")).max().ceil("h")
    idx = pd.date_range(t0, t1, freq="h", inclusive="left")
    stations = sorted(df.station.unique())
    col = {s: i for i, s in enumerate(stations)}
    out = np.zeros((len(idx), len(stations)))
    st = ((df.start - t0) / pd.Timedelta(hours=1)).to_numpy()
    en = st + df.charge_h.to_numpy()
    rate = df.energy.to_numpy() / df.charge_h.to_numpy()
    cj = df.station.map(col).to_numpy()
    for a, b, r, j in zip(st, en, rate, cj):
        h0, h1 = int(np.floor(a)), int(np.ceil(b))
        for h in range(max(h0, 0), min(h1, len(idx))):
            ov = min(b, h + 1) - max(a, h)
            if ov > 0:
                out[h, j] += r * ov
    return pd.DataFrame(out, index=idx, columns=stations)


def station_windows(df):
    g = df.groupby("station").start
    return pd.DataFrame({"first": g.min(), "last": g.max(), "n_sessions": g.size()})


def apply_windows_and_outages(H, win):
    """Set hours before commissioning / after last session to NaN; flag long zero runs as outages (NaN)."""
    H = H.copy()
    flags = pd.DataFrame(False, index=H.index, columns=H.columns)
    for s in H.columns:
        f, l = win.loc[s, "first"].floor("D"), win.loc[s, "last"].ceil("D")
        H.loc[(H.index < f) | (H.index >= l), s] = np.nan
        daily = H[s].resample("D").sum(min_count=1)
        z = (daily == 0).astype(int).to_numpy()
        edges = np.flatnonzero(np.diff(np.r_[0, z, 0]))
        for a, b in zip(edges[::2], edges[1::2]):
            if b - a >= OUTAGE_DAYS:
                d0, d1 = daily.index[a], daily.index[b - 1] + pd.Timedelta(days=1)
                m = (H.index >= d0) & (H.index < d1)
                flags.loc[m, s] = True
                H.loc[m, s] = np.nan
    return H, flags


def load_boulder(path):
    b = pd.read_csv(path, compression="infer")
    st = pd.to_datetime(b["Start_Date___Time"], format="%m/%d/%Y %H:%M", errors="coerce")
    iso = st.isna()
    st[iso] = pd.to_datetime(b.loc[iso, "Start_Date___Time"], format="%Y-%m-%d %H:%M:%S", errors="coerce")
    # Jun-Aug 2023 sessions appear twice, once per timestamp format (minutes vs seconds); round to the minute
    # so that the de-duplication step recognises them.
    st = st.dt.floor("min")
    name = b["Station_Name"].astype(str).str.strip()
    # The same physical chargers were renamed from 'COMM VITALITY / X' to 'MUNICIPAL SC / X' in spring 2023.
    name = name.str.replace(r"^MUNICIPAL SC / ", "COMM VITALITY / ", regex=True)
    # 'BOULDERJUNCTION / JUNCTION ST1' continues 'BOULDER / JUNCTION ST1' (2019-08-07 -> 2019-08-08).
    name = name.replace({"BOULDERJUNCTION / JUNCTION ST1": "BOULDER / JUNCTION ST1"})
    df = pd.DataFrame({"station": name, "start": st,
                       "charge_h": _to_hours(b["Charging_Time__hh_mm_ss_"]),
                       "energy": pd.to_numeric(b["Energy__kWh_"], errors="coerce")})
    return df


def load_paloalto(path):
    p = pd.read_csv(path, low_memory=False)
    st = pd.to_datetime(p["Start Date"], format="mixed", errors="coerce")
    df = pd.DataFrame({"station": p["Station Name"].astype(str).str.strip(), "start": st,
                       "charge_h": _to_hours(p["Charging Time (hh:mm:ss)"]),
                       "energy": pd.to_numeric(p["Energy (kWh)"], errors="coerce"),
                       "port": p["Port Number"]})
    # sessions are recorded per port; the dedupe key must include the port
    df["energy_key"] = df["energy"].round(6).astype(str) + "_" + df["port"].astype(str)
    return df
