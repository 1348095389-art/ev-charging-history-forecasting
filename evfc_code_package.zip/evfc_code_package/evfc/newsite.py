"""Realism check on genuinely new stations (real commissioning dates).

For each commissioning batch (onsets within BATCH_GAP days), a pooled model is trained on the stations
already in service before the batch onset, using only days before the onset.  Conformal quantiles are
calibrated by 3-fold station cross-fitting among those peers on the CAL_DAYS days before the onset,
using truncated histories.  New stations are then forecast for their first HORIZON_DAYS days in service,
with the history available on each day (k_eff = days since commissioning).
"""
import numpy as np
import pandas as pd
from . import exp as E

BATCH_GAP = 14
HORIZON_DAYS = 56
CAL_DAYS = 90
K_CAL = [0, 1, 3, 7, 14, 28]


def k_bin(k_eff):
    k_eff = np.asarray(k_eff)
    out = np.zeros_like(k_eff)
    for k in K_CAL:
        out = np.where(k_eff >= k, k, out)
    return out


def batches(city, candidates):
    on = sorted((city.first[s], s) for s in candidates)
    groups, cur = [], []
    for t, s in on:
        if cur and t - cur[0][0] > BATCH_GAP:
            groups.append(cur); cur = []
        cur.append((t, s))
    if cur:
        groups.append(cur)
    return [(g[0][0], [s for _, s in g]) for g in groups]


def run_batch(city, b0, new_st, cfg, seed=0, stride=1, min_peers=4):
    peers = [s for s in city.stations if city.first[s] < b0 - 28 and np.isfinite(city.Y[s][max(0, b0 - 28):b0]).any()]
    if len(peers) < min_peers:
        return None
    rng = np.random.default_rng(seed)
    # main model: peers, origins before onset
    pc = E.PeerCache(city, peers)
    tr = list(range(28, b0, stride))
    X, y, d = E.make_matrix(city, peers, tr, E.K_LEVELS, pc, rng=rng, sample_k=True)
    model = E.fit_gbdt(X, y, d.scale.to_numpy(), cfg, seed=seed)
    # predictions for new stations, first HORIZON_DAYS days, full (= since commissioning) history
    out = []
    for s in new_st:
        t0 = city.first[s]
        orig = [t for t in range(t0, min(t0 + HORIZON_DAYS, len(city.days)))]
        r = E.make_matrix(city, [s], orig, ["full"], pc)
        if r is None:
            continue
        Xp, yp, dp = r
        dp["y"] = yp
        dp["gbdt"] = E.predict_gbdt(model, Xp, dp.scale.to_numpy())
        out.append(dp)
    D = pd.concat(out, ignore_index=True)
    D["sn"], D["peer"] = E.baseline_preds(city, D, pc)
    D["days_in_service"] = D.k_eff.astype(int)
    D["k"] = k_bin(D.k_eff.to_numpy())
    # conformal calibration among peers (3-fold), days [b0-CAL_DAYS, b0)
    perm = rng.permutation(len(peers)); folds = [[peers[i] for i in perm[f::3]] for f in range(3)]
    cal = []
    for f in range(3):
        trs = [s for g in range(3) if g != f for s in folds[g]]
        if not trs:
            continue
        pcf = E.PeerCache(city, trs)
        Xc, yc, dc = E.make_matrix(city, trs, list(range(28, b0 - CAL_DAYS, stride)), E.K_LEVELS, pcf, rng=rng, sample_k=True)
        mf = E.fit_gbdt(Xc, yc, dc.scale.to_numpy(), cfg, seed=seed)
        r = E.make_matrix(city, folds[f], list(range(b0 - CAL_DAYS, b0)), K_CAL, pcf)
        if r is None:
            continue
        Xv, yv, dv = r
        dv["y"] = yv
        dv["gbdt"] = E.predict_gbdt(mf, Xv, dv.scale.to_numpy())
        dv["sn"], dv["peer"] = E.baseline_preds(city, dv, pcf)
        cal.append(dv)
    C = pd.concat(cal, ignore_index=True)
    for col in ["gbdt", "sn", "peer"]:
        q = E.conformal_quantiles(C, col)
        for a in (0.2, 0.1):
            lo, hi = E.apply_intervals(D, col, q, a)
            D[f"{col}_lo{int((1 - a) * 100)}"] = lo; D[f"{col}_hi{int((1 - a) * 100)}"] = hi
    D["batch_onset"] = city.days[b0]
    D["n_peers"] = len(peers)
    return D


def run_city_new(city, candidates, cfg, seed=0, log=print):
    res = []
    for b0, st in batches(city, candidates):
        D = run_batch(city, b0, st, cfg, seed=seed)
        log(f"[{city.name}] batch {city.days[b0].date()} new={len(st)} -> {'skipped (too few peers)' if D is None else len(D)}")
        if D is not None:
            res.append(D)
    D = pd.concat(res, ignore_index=True)
    D["city"] = city.name
    D["date"] = city.days[D.t.to_numpy()]
    return D
