"""Round-2 evaluation: adds the global LSTM, Chronos-2 with peer covariates, TimesFM 3.0 (univariate and with peer
covariates) and the scaled peer profile; applies the physical-plausibility cap; computes Winkler scores and tests."""
import numpy as np
import pandas as pd
from scipy.stats import wilcoxon
from . import exp as E
from .evaluate import holm, KLAB

POINT = {"gbdt": "Pooled GBDT", "lstm": "Global LSTM", "chronos_qmean": "Chronos-2 (mean)", "chronos": "Chronos-2 (median)",
         "ccov_qmean": "Chronos-2 + peer cov. (mean)", "ccov": "Chronos-2 + peer cov. (median)",
         "tfm3_qmean": "TimesFM 3.0 (mean)", "tfm3": "TimesFM 3.0 (median)",
         "tfm3c_qmean": "TimesFM 3.0 + peer cov. (mean)", "tfm3c": "TimesFM 3.0 + peer cov. (median)",
         "speer": "Scaled peer profile", "peer": "Peer profile", "sn": "Seasonal naive", "zero": "Zero forecast"}
INTERVAL = {"gbdt": "GBDT + conformal", "sn": "Seasonal naive + conformal", "peer": "Peer profile + conformal",
            "chronos": "Chronos-2 (native)", "ccov": "Chronos-2 + peer cov. (native)", "tfm3": "TimesFM 3.0 (native)",
            "tfm3c": "TimesFM 3.0 + peer cov. (native)"}
NON_FORECAST = {"station", "t", "hour", "scale", "k_eff", "k", "y", "fold", "city", "date", "nvalid", "days_in_service",
                "batch_onset", "n_peers", "sp_ratio", "ctrl_fold", "n_ctrl"}


def train_cap(city, train_end):
    """Largest hourly energy observed at any station in the training period (known at forecast time)."""
    te = int((pd.Timestamp(train_end) - city.days[0]).days) + 1
    return float(np.nanmax(np.vstack([city.Y[s][:te].reshape(-1) for s in city.stations])))


def apply_cap(D, cap):
    D = D.copy()
    for c in D.columns:
        if c in NON_FORECAST or not pd.api.types.is_float_dtype(D[c]) or c.endswith("_fb"):
            continue
        D[c] = D[c].clip(upper=cap)
    return D


def add_scaled_peer(D, series, peer_groups, stations, group_col="fold"):
    si = {s: i for i, s in enumerate(stations)}
    v = np.nan_to_num(series); c = np.isfinite(series).astype(float)
    cs = np.concatenate([np.zeros((len(stations), 1)), v.cumsum(1)], 1); cc = np.concatenate([np.zeros((len(stations), 1)), c.cumsum(1)], 1)
    pv = np.nan_to_num(peer_groups); pc = np.isfinite(peer_groups).astype(float)
    ps = np.concatenate([np.zeros((len(peer_groups), 1)), pv.cumsum(1)], 1); pcc = np.concatenate([np.zeros((len(peer_groups), 1)), pc.cumsum(1)], 1)
    R = D[["station", "t", "k", "k_eff", group_col]].drop_duplicates(["station", "t", "k"]).copy()
    i = R.station.map(si).to_numpy(); e = R.t.to_numpy() * 24; a = ((R.t - R.k_eff).to_numpy() * 24).astype(int)
    f = R[group_col].to_numpy().astype(int)
    own = (cs[i, e] - cs[i, a]) / np.maximum(cc[i, e] - cc[i, a], 1); n_own = cc[i, e] - cc[i, a]
    pm = (ps[f, e] - ps[f, a]) / np.maximum(pcc[f, e] - pcc[f, a], 1)
    R["sp_ratio"] = np.where((n_own > 0) & (pm > 0), own / np.where(pm > 0, pm, 1), 1.0)
    D = D.drop(columns=[x for x in ["sp_ratio", "speer"] if x in D]).merge(R[["station", "t", "k", "sp_ratio"]], on=["station", "t", "k"], how="left")
    D["speer"] = D.peer * D.sp_ratio
    return D


def point_table(D, group="k"):
    rows = []
    for k, g in D.groupby(group):
        for m in POINT:
            if m not in g or g[m].isna().all():
                continue
            rows.append({group: k, "model": m, "RMSE": E.rmse(g.y.values, g[m].values), "MAE": E.mae(g.y.values, g[m].values),
                         "dWAPE": E.daily_wape(g, m)})
    return pd.DataFrame(rows)


def winkler(y, lo, hi, a):
    return (hi - lo) + (2 / a) * np.maximum(lo - y, 0) + (2 / a) * np.maximum(y - hi, 0)


def interval_table(D, group="k"):
    rows = []
    for k, g in D.groupby(group):
        g = g[g.y.notna()]
        for m in INTERVAL:
            for lv, a in ((80, 0.2), (90, 0.1)):
                lo, hi = f"{m}_lo{lv}", f"{m}_hi{lv}"
                if lo not in g or g[lo].isna().all():
                    continue
                h = g[g[lo].notna() & g[hi].notna()]
                inside = (h.y >= h[lo]) & (h.y <= h[hi])
                pst = inside.groupby(h.station).mean()
                rows.append({group: k, "model": m, "level": lv, "cov": float(inside.mean()), "width": float((h[hi] - h[lo]).mean()),
                             "winkler": float(winkler(h.y, h[lo], h[hi], a).mean()), "cov_nonzero": float(inside[h.y > 0].mean()),
                             "st_within5": float(((pst - lv / 100).abs() <= 0.05).mean())})
    return pd.DataFrame(rows)


def station_tests(D, comps, ref="gbdt", metric="rmse", level=80, n_boot=2000, seed=0, city=None):
    """Paired station-level comparison of ref with each comparator at each history level (Wilcoxon, bootstrap ratio)."""
    rng = np.random.default_rng(seed); rows = []
    for k, g in D[D.y.notna()].groupby("k"):
        for m in comps:
            if metric == "rmse":
                if m not in g or g[m].isna().all():
                    continue
                s = g.groupby("station").apply(lambda h: pd.Series({"r": E.rmse(h.y.values, h[ref].values), "c": E.rmse(h.y.values, h[m].values)}), include_groups=False)
            else:
                a = 1 - level / 100
                if f"{m}_lo{level}" not in g or g[f"{m}_lo{level}"].isna().all():
                    continue
                h0 = g[g[f"{m}_lo{level}"].notna()].copy()
                h0["wr"] = winkler(h0.y, h0[f"{ref}_lo{level}"], h0[f"{ref}_hi{level}"], a)
                h0["wc"] = winkler(h0.y, h0[f"{m}_lo{level}"], h0[f"{m}_hi{level}"], a)
                s = h0.groupby("station")[["wr", "wc"]].mean().rename(columns={"wr": "r", "wc": "c"})
            s = s.dropna()
            if len(s) < 6:
                continue
            diff = (s.r - s.c).to_numpy()
            p = wilcoxon(s.r, s.c).pvalue if np.any(diff != 0) else 1.0
            bs = []
            for _ in range(n_boot):
                i = rng.integers(0, len(s), len(s)); bs.append(s.r.to_numpy()[i].mean() / s.c.to_numpy()[i].mean())
            rows.append({"city": city, "k": k, "metric": metric, "comparator": m, "n_stations": len(s), "ratio": float(s.r.mean() / s.c.mean()),
                         "ratio_lo": float(np.quantile(bs, 0.025)), "ratio_hi": float(np.quantile(bs, 0.975)),
                         "share_ref_better": float((diff < 0).mean()), "p": float(p)})
    return pd.DataFrame(rows)
